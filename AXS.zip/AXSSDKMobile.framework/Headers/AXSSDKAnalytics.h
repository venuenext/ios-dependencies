//
//  AXSSDKAnalytics.h
//  AXSSDKMobile
//
//  Created by Dennis Padilla on 7/6/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AXSSDKAnalytics : NSObject

/**
 *  Shared instance of the analytics class
 *
 *  @return class object
 */
+ (nonnull AXSSDKAnalytics *)analytics;

/**
 *  Make a request to the AXS platform to track page views
 *
 *  @param page The page that was visited
 */
-(void)trackPageView:(nullable NSString *)page;

/**
 *  Make a request to the AXS platform to track an action inside of a page
 *
 *  @param page   The page where the action occurred
 *  @param action The action that occurred.
 *  @param label  The label of the action
 */
-(void)trackActionForPage:(nullable NSString *)page action:(nullable NSString *)action label:(nullable NSString *)label;


/**
 Make a request to the AXS platform to track an action inside of a page

 @param page The page where the action occurred
 @param action The action that occurred.
 @param label  The label of the action
 @param contextData contextData dictionary of data
 */
- (void)trackActionForPage:(nullable NSString *)page action:(nullable NSString *)action label:(nullable NSString *)label contextData:(nullable NSDictionary *)contextData;


/**
 Track a page with custom omniture context data

 @param page page name
 @param contextData dictionary of data
 */
- (void)trackPage:(nullable NSString *)page contextData:(nullable NSDictionary *)contextData;

- (void)takeScreenshot;

@end
