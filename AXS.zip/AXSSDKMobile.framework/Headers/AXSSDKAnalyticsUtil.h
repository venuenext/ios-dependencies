//
//  AXSSDKAnalyticsUtil.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 12/20/16.
//  Copyright © 2016 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AXSSDKFSEvent, AXSSDKOrder, AXSSDKEvent;

@interface AXSSDKAnalyticsUtil : NSObject

+ (nonnull NSDictionary *)contextEvents:(nullable NSArray *)events;

+ (nonnull NSDictionary *)contextDataForPageLoad:(nullable NSString *)pageName pageType:(nullable NSString *)pageType;
+ (nonnull NSDictionary *)contextDataForPageLoad:(nullable NSString *)pageName pageType:(nullable NSString *)pageType section:(nullable NSString *)section contentType:(nullable NSString *)contentType;
+ (nonnull NSDictionary *)contextDataForEvent:(nonnull AXSSDKEvent *)event;
+ (nonnull NSDictionary *)contextDataForFSEvent:(nonnull AXSSDKFSEvent *)event;
+ (nonnull NSDictionary *)contextDataProductsWithEventName:(nullable NSString *)eventName;
+ (nonnull NSDictionary *)contextDataProductsWithEventName:(nullable NSString *)eventName ticketQty:(nullable NSString *)qty totalCost:(nullable NSString *)totalCost;
+ (nonnull NSDictionary *)contextDataWithPushPermission:(BOOL)push locationPermission:(BOOL)location bluetoothPermission:(BOOL)bluetooth;
+ (nonnull NSDictionary *)contextDataProductsWithMyEvents:(nullable NSArray<AXSSDKOrder *> *)myEvents;


@end
