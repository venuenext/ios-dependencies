//
//  AXSSDKConfigs.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 4/8/16.
//  Copyright © 2016 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AXSSDKConfigs : NSObject

/**
 *  Help Center URL
 *
 *  @return URL
 */
+ (NSString *)helpCenterURL;

+ (NSString *)aboutAXSURL;

+ (NSNumber *)flashSeatsSiteSkinId;

+ (NSString *)facebookAuthURL;
+ (NSString *)blizzardAuthURL;
+ (NSString *)blizzardAuthRedirectURL;

+ (NSString *)hostForAxsCom;

/**
 * Returns system locale. E.g. en-US, en-UK
 */
+ (NSString *)localeCode;

/**
 Returns device locale
 
 @return US, UK, SE
 */
+ (NSString *)localeCountryCode;
+ (BOOL)isLocaleCountryEU;
+ (BOOL)isLocaleCountryFlashEnabled;
+ (NSNumber *)axsApiRegionId;

/**
 Check if a region ID is enabled for sale balance management

 @param regionId region ID
 @return bool
 */
+ (BOOL)isSaleBalanceEnabledRegion:(NSNumber *)regionId;

@end
