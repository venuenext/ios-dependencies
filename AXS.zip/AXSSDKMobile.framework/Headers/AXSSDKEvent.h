//
//  AXSSDKEvent.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 7/7/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AXSSDKEventProtocol.h"

@class AXSSDKProduct, AXSSDKVenue;

/**
 *  Represents an event
 */
@interface AXSSDKEvent : NSManagedObject <AXSSDKEventProtocol>

@property (nullable, nonatomic, retain) NSDate * doorDate;
@property (nullable, nonatomic, retain) NSDate * doorDateLocal;
@property (nullable, nonatomic, retain) NSDate * endDate;
@property (nullable, nonatomic, retain) NSString * eventId;
@property (nullable, nonatomic, retain) NSString * eventImageUrl;
@property (nullable, nonatomic, retain) NSNumber * dateOnly;
@property (nullable, nonatomic, retain) NSDate * startDate;
@property (nullable, nonatomic, retain) NSDate * startDateLocal;
@property (nullable, nonatomic, retain) NSString * title;
@property (nullable, nonatomic, retain) NSString * additionalDates;
@property (nullable, nonatomic, retain) NSSet *products;
@property (nullable, nonatomic, retain) AXSSDKVenue *venue;
@property (nullable, nonatomic, retain) NSString *eventDescription;
@property (nullable, nonatomic, retain) NSNumber *isEventStub;

@property (nullable, nonatomic, retain) NSString * venueTimezoneName;
@property (nullable, nonatomic, retain) NSString * venueTimezoneAbbr;
@property (nullable, nonatomic, retain) NSString * venueCity;
@property (nullable, nonatomic, retain) NSString * venueState;
@property (nullable, nonatomic, retain) NSString * venueName;

@end

@interface AXSSDKEvent (CoreDataGeneratedAccessors)

- (void)addProductsObject:(nonnull AXSSDKProduct *)value;
- (void)removeProductsObject:(nonnull AXSSDKProduct *)value;
- (void)addProducts:(nonnull NSSet *)values;
- (void)removeProducts:(nonnull NSSet *)values;

@end
