//
//  AXSSDKEventProtocol.h
//  AXSSDKMobile
//
//  Created by Panda on 7/9/17.
//  Copyright © 2017 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AXSSDKEventProtocol

@property (nullable, nonatomic, retain) NSString * eventId;
@property (nullable, nonatomic, retain) NSString * eventImageUrl;
@property (nullable, nonatomic, retain) NSNumber * dateOnly;
@property (nullable, nonatomic, retain) NSDate * startDate;
@property (nullable, nonatomic, retain) NSDate * endDate;
@property (nullable, nonatomic, retain) NSDate * startDateLocal;
@property (nullable, nonatomic, retain) NSDate * doorDate;
@property (nullable, nonatomic, retain) NSDate * doorDateLocal;
@property (nullable, nonatomic, retain) NSString * title;
@property (nullable, nonatomic, retain) NSString * venueTimezoneName;
@property (nullable, nonatomic, retain) NSString * venueTimezoneAbbr;
@property (nullable, nonatomic, retain) NSString * venueCity;
@property (nullable, nonatomic, retain) NSString * venueState;
@property (nullable, nonatomic, retain) NSString * venueName;
@property (nullable, nonatomic, retain) NSString * eventDescription;
@property (nullable, nonatomic, retain) NSNumber *isEventStub;


@end
