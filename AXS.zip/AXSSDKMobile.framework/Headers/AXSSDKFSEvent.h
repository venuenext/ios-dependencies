//
//  AXSSDKFSEvent.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 11/24/15.
//  Copyright © 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AXSSDKEventProtocol.h"

@class AXSSDKFSTicket;
@class AXSSDKFSOrder;
@class AXSSDKFSMPOffer;

/**
 *  Represents a FlashSeats event
 */
@interface AXSSDKFSEvent : NSManagedObject <AXSSDKEventProtocol>

// Insert code here to declare functionality of your managed object subclass
@property (nullable, nonatomic, copy) NSString *city;
@property (nullable, nonatomic, retain) NSString *eventId;
@property (nullable, nonatomic, retain) NSString *eventImageUrl;
@property (nullable, nonatomic, copy) NSDate *eventLocalStartDateTime;
@property (nullable, nonatomic, copy) NSNumber *eventOwnerId;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, retain) NSNumber *dateOnly;
@property (nullable, nonatomic, copy) NSDate *startDateTime;
@property (nullable, nonatomic, retain) NSDate *endDate;
@property (nullable, nonatomic, retain) NSDate *doorDate;
@property (nullable, nonatomic, retain) NSDate *doorDateLocal;
@property (nullable, nonatomic, copy) NSString *state;
@property (nullable, nonatomic, copy) NSString *timeZoneAbbr;
@property (nullable, nonatomic, retain) NSString *venueName;
@property (nullable, nonatomic, copy) NSString *categoryIds;
@property (nullable, nonatomic, retain) AXSSDKFSMPOffer *offer;
@property (nullable, nonatomic, retain) NSSet<AXSSDKFSOrder *> *orders;
@property (nullable, nonatomic, retain) NSString *eventDescription;
@property (nullable, nonatomic, retain) NSNumber *isEventStub;

@property (nullable, nonatomic, retain) NSDate * startDate;
@property (nullable, nonatomic, retain) NSDate * startDateLocal;
@property (nullable, nonatomic, retain) NSString * title;
@property (nullable, nonatomic, retain) NSString * venueTimezoneName;
@property (nullable, nonatomic, retain) NSString * venueTimezoneAbbr;
@property (nullable, nonatomic, retain) NSString * venueCity;
@property (nullable, nonatomic, retain) NSString * venueState;

@end

@interface AXSSDKFSEvent (CoreDataGeneratedAccessors)
- (void)addOrdersObject:(nonnull AXSSDKFSOrder *)value;
- (void)removeOrdersObject:(nonnull AXSSDKFSOrder *)value;
- (void)addOrders:(nonnull NSSet<AXSSDKFSOrder *> *)values;
- (void)removeOrders:(nonnull NSSet<AXSSDKFSOrder *> *)values;
@end

