//
//  AXSSDKFSMobileId.h
//  AXSSDKMobileIDUI
//
//  Created by Wilson Lei on 11/11/15.
//  Copyright © 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;

@class AXSSDKOrder;

@interface AXSSDKFSMobileId : NSObject

/**
 Generate FlashSeats Mobile ID QR code. Require user to be login first.

 @return QR code
 */
+ (nullable UIImage *)createMobileIdImage;


/**
 Generate FlashSeats Mobile ID QR code using member ID and mobile ID

 @param memberId Flash member ID
 @param mobileId Flash mobile ID
 @return QR code image
 */
+ (nullable UIImage *)createMobileIdImageWithMemberId:(nonnull NSString *)memberId mobileId:(nonnull NSString *)mobileId;


/**
 Generate FlashSeats Mobile ID QR code using AXSSDKOrder which returns from AXSSDKOrderHistoryManage class fetchOrderHistoryForPage method

 @param order AXSSDKOrder object
 @return QR code image
 */
+ (nullable UIImage *)createMobileIdImageWithOrder:(nonnull AXSSDKOrder *)order;

@end
