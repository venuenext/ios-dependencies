//
//  AXSSDKFSOrder.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 1/8/16.
//  Copyright © 2016 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AXSSDKOrderProtocol.h"

@class AXSSDKFSEvent, AXSSDKFSTicket;



/**
 *  Represents a FlashSeats user order
 */
@interface AXSSDKFSOrder : NSManagedObject <AXSSDKOrderProtocol>

@property (nullable, nonatomic, retain) NSString *orderId;
@property (nullable, nonatomic, retain) NSString *flashSeatsMemberId;
@property (nullable, nonatomic, retain) NSString *flashSeatsMobileId;
@property (nullable, nonatomic, retain) NSNumber *isHidden;
@property (nullable, nonatomic, retain) NSNumber *regionId;
@property (nullable, nonatomic, retain) NSString *currencyCode;
@property (nullable, nonatomic, retain) AXSSDKFSEvent *event;
@property (nullable, nonatomic, retain) NSSet<AXSSDKFSTicket *> *tickets;

@property (nullable, nonatomic, retain) NSString *flashEventConfigId;
@property (nullable, nonatomic, retain) NSString *ticketingSystem;
@property (nonatomic, assign, readonly) AXSSDKTicketingSystemType ticketingSystemType;

- (nullable id<AXSSDKEventProtocol>) orderEvent;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)allTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTicketsCanSell;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTicketsCanTransfer;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableAndRedeemedTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)transferedTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)listedTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableAndListedTickets;

@end

@interface AXSSDKFSOrder (CoreDataGeneratedAccessors)

- (void)addTicketsObject:(nonnull AXSSDKFSTicket *)value;
- (void)removeTicketsObject:(nonnull AXSSDKFSTicket *)value;
- (void)addTickets:(nonnull NSSet<AXSSDKFSTicket *> *)values;
- (void)removeTickets:(nonnull NSSet<AXSSDKFSTicket *> *)values;

@end

