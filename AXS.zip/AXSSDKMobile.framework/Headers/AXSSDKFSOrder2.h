//
//  AXSSDKFSOrder2.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 3/15/16.
//  Copyright © 2016 AXS. All rights reserved.
//

#import "AXSSDKFSOrder.h"
#import "AXSSDKSettings.h"

@interface AXSSDKFSOrder2 : NSObject

@property (nullable, nonatomic, strong) AXSSDKFSOrder *order;
@property (nullable, nonatomic, strong) NSString *forwardedEmail;
@property (nonatomic, assign) AXSSDKFSTicketState forwardedTicketState;
@property (nullable, nonatomic, strong) NSDate *forwardedDate;

- (nullable NSSet *)transferedTicketsForEmail;

@end
