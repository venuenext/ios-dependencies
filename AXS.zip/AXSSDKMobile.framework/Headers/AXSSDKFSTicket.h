//
//  AXSSDKFSTicket.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 11/24/15.
//  Copyright © 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AXSSDKTicketProtocol.h"

@class AXSSDKFSEvent;
@class AXSSDKFSOrder;
@class AXSSDKFSTicketListing;



/**
 *  Represents a FlashSeats user ticket
 */
@interface AXSSDKFSTicket : NSManagedObject <AXSSDKTicketProtocol>

// Insert code here to declare functionality of your managed object subclass

@property (nullable, nonatomic, retain) NSNumber *canSell;
@property (nullable, nonatomic, retain) NSNumber *canTransfer;
@property (nullable, nonatomic, retain) NSString *externalSeatInfo;
@property (nullable, nonatomic, retain) NSString *forwardedActionId;
@property (nullable, nonatomic, retain) NSDate *forwardedDate;
@property (nullable, nonatomic, retain) NSString *forwardedEmail;
@property (nullable, nonatomic, retain) NSString *forwardedFirstName;
@property (nullable, nonatomic, retain) NSString *forwardedLastName;
@property (nullable, nonatomic, retain) NSString *forwardedMessage;
@property (nullable, nonatomic, retain) NSString *row;
@property (nullable, nonatomic, retain) NSString *seat;
@property (nullable, nonatomic, retain) NSString *section;
@property (nullable, nonatomic, retain) NSString *ticketId;
@property (nullable, nonatomic, retain) NSString *axsTicketId;
@property (nullable, nonatomic, retain) NSNumber *ticketState;
@property (nullable, nonatomic, retain) AXSSDKFSOrder *order;
@property (nullable, nonatomic, retain) AXSSDKFSTicketListing *listing;
@property (nullable, nonatomic, retain) NSNumber *minAskPrice;
@property (nullable, nonatomic, retain) NSNumber *maxAskPrice;
@property (nullable, nonatomic, retain) NSString *seatNeighborhood;
@property (nullable, nonatomic, retain) NSString *externalSeatInfo1;
@property (nullable, nonatomic, retain) NSString *externalSeatInfo2;
@property (nullable, nonatomic, retain) NSString *priceCodePrintDescription;
@property (nullable, nonatomic, retain) NSString *seatAttributes;

@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSNumber *isETicket;
@property (nullable, nonatomic, retain) NSNumber *isFlashSeat;
@property (nullable, nonatomic, retain) NSNumber *isGeneralAdmission;
@property (nullable, nonatomic, retain) NSNumber *barcodeStatusId;
@property (nullable, nonatomic, retain) NSString *flashTicketId;
@property (nullable, nonatomic, assign) NSString *rowPrintDescription;
@property (nullable, nonatomic, assign) NSString *sectionPrintDescription;

@end
