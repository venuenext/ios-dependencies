//
//  AXSSDKOrder.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 6/23/17.
//  Copyright © 2017 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AXSSDKOrderProtocol.h"

@class AXSSDKFSOrder, AXSSDKProduct;

@interface AXSSDKOrder : NSManagedObject <AXSSDKOrderProtocol>

@property (nullable, nonatomic, copy) NSNumber *isHidden;
@property (nullable, nonatomic, copy) NSNumber *isMultiDay;
@property (nullable, nonatomic, copy) NSDate *orderDate;
@property (nullable, nonatomic, retain) NSString *orderId;
@property (nullable, nonatomic, copy) NSString *orderNumber;
@property (nullable, nonatomic, copy) NSString *orderStatus;
@property (nullable, nonatomic, retain) NSString *ticketingSystem;
@property (nullable, nonatomic, retain) NSString *currencyCode;
@property (nullable, nonatomic, copy) NSNumber *totalPrice;
@property (nullable, nonatomic, copy) NSNumber *userId;
@property (nullable, nonatomic, retain) NSString *flashEventConfigId;
@property (nullable, nonatomic, retain) NSNumber *regionId;
@property (nullable, nonatomic, retain) AXSSDKFSOrder *flashSeatsOrder;
@property (nullable, nonatomic, retain) NSSet<AXSSDKProduct *> *products;

@property (nullable, nonatomic, retain) NSString *flashSeatsMemberId;
@property (nullable, nonatomic, retain) NSString *flashSeatsMobileId;
@property (nonatomic, assign, readonly) AXSSDKTicketingSystemType ticketingSystemType;
@property (nullable, nonatomic, assign, readonly) NSString *ticketingSystemContextId;

@end

@interface AXSSDKOrder (CoreDataGeneratedAccessors)

- (void)addProductsObject:(nonnull AXSSDKProduct *)value;
- (void)removeProductsObject:(nonnull AXSSDKProduct *)value;
- (void)addProducts:(nonnull NSSet<AXSSDKProduct *> *)values;
- (void)removeProducts:(nonnull NSSet<AXSSDKProduct *> *)values;

- (nullable id<AXSSDKEventProtocol>) orderEvent;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)allTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)sharedTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)transferredTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTicketsCanTransfer;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableAndListedTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)listedTickets;

@end
