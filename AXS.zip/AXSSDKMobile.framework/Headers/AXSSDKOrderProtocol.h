//
//  AXSSDKOrderProtocol.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 7/27/18.
//  Copyright © 2018 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AXSSDKEventProtocol.h"
#import "AXSSDKTicketProtocol.h"

typedef enum : NSUInteger {
    AXSSDKTicketingSystemTypeOutbox = 0,
    AXSSDKTicketingSystemTypeVeritix,
    AXSSDKTicketingSystemTypeFlash,
    AXSSDKTicketingSystemTypeUnknown
} AXSSDKTicketingSystemType;

@protocol AXSSDKOrderProtocol

@property (nullable, nonatomic, retain) NSString *orderId;
@property (nullable, nonatomic, retain) NSNumber *regionId;
@property (nullable, nonatomic, retain) NSString *currencyCode;
@property (nullable, nonatomic, retain) NSString *flashEventConfigId;
@property (nullable, nonatomic, retain) NSString *flashSeatsMemberId;
@property (nullable, nonatomic, retain) NSString *flashSeatsMobileId;
@property (nullable, nonatomic, retain) NSString *ticketingSystem;
@property (nonatomic, assign, readonly) AXSSDKTicketingSystemType ticketingSystemType;
@property (nullable, nonatomic, readonly) NSString *ticketingSystemContextId;

- (nullable id<AXSSDKEventProtocol>) orderEvent;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)allTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTicketsCanSell;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableTicketsCanTransfer;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)availableAndListedTickets;
- (nullable NSSet<id<AXSSDKTicketProtocol>> *)listedTickets;

@end
