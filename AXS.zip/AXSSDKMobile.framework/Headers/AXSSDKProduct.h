//
//  AXSSDKProduct.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 7/6/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class AXSSDKEvent, AXSSDKOrder, AXSSDKTicket;

/**
 *  Represents a product
 */
@interface AXSSDKProduct : NSManagedObject

@property (nullable, nonatomic, retain) NSString * productCode;
@property (nullable, nonatomic, retain) NSNumber * mobileTicketsEnabled;
@property (nullable, nonatomic, retain) NSString * mobileTicketsEnabledMessage;
@property (nullable, nonatomic, retain) NSString * productId;
@property (nullable, nonatomic, retain) NSString * zoneId;
@property (nullable, nonatomic, retain) NSSet *orders;
@property (nullable, nonatomic, retain) NSSet *events;
@property (nullable, nonatomic, retain) NSSet *tickets;
@end

@interface AXSSDKProduct (CoreDataGeneratedAccessors)

- (void)addOrdersObject:(nonnull AXSSDKOrder *)value;
- (void)removeOrdersObject:(nonnull AXSSDKOrder *)value;
- (void)addOrders:(nonnull NSSet *)values;
- (void)removeOrders:(nonnull NSSet *)values;

- (void)addEventsObject:(nonnull AXSSDKEvent *)value;
- (void)removeEventsObject:(nonnull AXSSDKEvent *)value;
- (void)addEvents:(nonnull NSSet *)values;
- (void)removeEvents:(nonnull NSSet *)values;

- (void)addTicketsObject:(nonnull AXSSDKTicket *)value;
- (void)removeTicketsObject:(nonnull AXSSDKTicket *)value;
- (void)addTickets:(nonnull NSSet *)values;
- (void)removeTickets:(nonnull NSSet *)values;

@end
