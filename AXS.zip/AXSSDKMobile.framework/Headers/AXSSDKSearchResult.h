//
//  AXSSDKSearchResult.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 6/20/18.
//  Copyright © 2018 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AXSSDKModel.h"

typedef enum : NSUInteger {
    AXSSDKSearchResultCategoryUnknown,
    AXSSDKSearchResultCategoryEvent,
    AXSSDKSearchResultCategoryPerformer,
    AXSSDKSearchResultCategoryArticle,
} AXSSDKSearchResultCategory;

@interface AXSSDKSearchResult : AXSSDKModel

@property (nullable, nonatomic, strong) NSString *resultId;
@property (nullable, nonatomic, strong) NSString *label;
@property (nullable, nonatomic, strong) NSString *detail;
@property (nonatomic, assign) AXSSDKSearchResultCategory category;

@end
