//
//  AXSSDKSettings.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 5/13/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define AXSSDKUserLogoutNotification @"AXSSDKUserLogoutNotification"
#define AXSSDKUserLoginNotification @"AXSSDKUserLoginNotification"
#define AXSSDKSeeAllOffersNotification @"AXSSDKSeeAllOffersNotification"
#define AXSSDKThemeUpdateNotification @"AXSSDKThemeUpdateNotification"

/**
 Social login options for Sign in screen.

 - AXSSDKSocialLoginOptionFacebook: Facebook login
 - AXSSDKSocialLoginOptionBlizzard: Blizzard/Battle.net login
 */
typedef NS_OPTIONS(NSInteger, AXSSDKSocialLoginOption){
    AXSSDKSocialLoginOptionFacebook = 1 << 0,
    AXSSDKSocialLoginOptionBlizzard = 1 << 1
};

typedef enum : NSUInteger {
    AXSSDKFSTicketStateUnknown = 0,
    AXSSDKFSTicketStateAvailable = 1,
    AXSSDKFSTicketStateListed = 2,
    AXSSDKFSTicketStateReceived = 3,
    AXSSDKFSTicketStateForwarded = 4,
    AXSSDKFSTicketStateRedeemed = 5
} AXSSDKFSTicketState;

typedef enum : NSUInteger {
    AXSSDKBarcodeStatusUnknown = 0,
    AXSSDKBarcodeStatusAvailable = 1,
    AXSSDKBarcodeStatusForwarded = 2,
    AXSSDKBarcodeStatusReceived = 3,
    AXSSDKBarcodeStatusRevoked = 4,
    AXSSDKBarcodeStatusFSForwarded = 12,
    AXSSDKBarcodeStatusFSReceived = 13,
    AXSSDKBarcodeStatusFSRedeemed = 14,
    AXSSDKBarcodeStatusFSListed = 15
} AXSSDKBarcodeStatus;

typedef enum : NSUInteger {
    /**
     *  The development environment.
     */
    AXSSDKTargetAPIDevelopment,
    /**
     *  The QA "Integration" environment. Usually referred to as "QA"
     */
    AXSSDKTargetAPIQAIntegration,
    /**
     *  The stage environment. Usually matches production data.
     */
    AXSSDKTargetAPIStaging,
    /**
     *  The production AXS environment.
     */
    AXSSDKTargetAPIProduction
} AXSSDKTargetAPI;

typedef enum : NSUInteger {
    AXSSDKTargetAPITypeWeb,
    AXSSDKTargetAPITypeIdentity,
    AXSSDKTargetAPITypeReport,
    AXSSDKTargetAPITypeProximity,
    AXSSDKTargetAPITypeNotification,
    AXSSDKTargetAPITypeUser,
    AXSSDKTargetAPITypeOAuth,
    AXSSDKTargetAPITypeVeritix,
    AXSSDKTargetAPITypeFlashSeat,
    AXSSDKTargetAPITypeTeleSign,
    AXSSDKTargetAPITypeWeb2,
    AXSSDKTargetAPITypeWeb2_1,
    AXSSDKTargetAPITypeFacebookGraph,
    AXSSDKTargetAPITypeAXSCom,
    AXSSDKTargetAPITypeUserLogin,
    AXSSDKTargetAPITypeUnified,
    AXSSDKTargetAPITypeEventBatch
} AXSSDKTargetAPIType;


@interface AXSSDKSettings : NSObject

/**
 *  Returns the global shared settings.
 *
 *  @return AXSSDKSettings
 */
+ (AXSSDKSettings *)sharedInstance;

/**
 *  Sets client Id and secret. The method should be called in didFinishLaunchingWithOptions delegate.
 *
 *  @param partnerClientId partner client ID
 *  @param clientId        client ID
 *  @param clientSecret    client Secret
 */
+ (void)setPartnerClientId:(NSString *)partnerClientId clientId:(NSString *)clientId clientSecret:(NSString *)clientSecret;

/**
 *  Sets FlashSeats api credential
 *
 *  @param user   user
 *  @param secret secret
 */
+ (void)setFlashSeatsApiUser:(NSString *)user secret:(NSString *)secret;

/**
 *  Sets navigation bar color
 *
 *  @param barColor bar color. Default black.
 *  @param translucent navigation bar should be translucent or not. Default YES.
 */
+ (void)setNavigationBarColor:(UIColor *)barColor translucent:(BOOL)translucent;

/**
 *  Sets navigation title color
 *
 *  @param titleColor navigation title color. Default white.
 */
+ (void)setNavigationTitleColor:(UIColor *)titleColor;

/**
 *  Sets theme background color.
 *
 *  @param backgroundColor background color. Default white.
 */
+ (void)setBackgroundColor:(UIColor *)backgroundColor DEPRECATED_ATTRIBUTE;

/**
 *  Sets theme general text color
 *
 *  @param textColor text color. Default black.
 */
+ (void)setTextColor:(UIColor *)textColor DEPRECATED_ATTRIBUTE;

/**
 *  Sets CTA / button color
 *
 *  @param ctaColor CTA color. Default black.
 */
+ (void)setCtaColor:(UIColor *)ctaColor;

/**
 *  Sets CTA / button text color
 *
 *  @param ctaTextColor CTA text color. Default white.
 */
+ (void)setCtaTextColor:(UIColor *)ctaTextColor;

/**
 *  Sets hyperlinks text color
 *
 *  @param linkTextColor hyperlinks text color. Default blue.
 */
+ (void)setLinkTextColor:(UIColor *)linkTextColor DEPRECATED_ATTRIBUTE;

/**
 *  Sets a logo image that can be display at the center of navigation.
 *
 *  @param logo logo image
 */
+ (void)setClientLogo:(UIImage *)logo;

/**
 *  Sets different API end point host.
 */
+ (void)setApiEnvironment:(AXSSDKTargetAPI)apiEnv;

/**
 *  Sets different API end point type.
 */
+ (void)setApiType:(AXSSDKTargetAPIType)apiEnv;

/**
 *  Enable FlashSeats marketplace UI. API availability is based on account permission.
 *
 *  @param enabled BOOL
 */
+ (void)setFlashSeatsMarketplaceEnabled:(BOOL)enabled;


/**
 Enable site skin selection screen in FlashSeats marketplace find tickets screen

 @param enabled
 */
+ (void)setFlashSeatsManualSiteSkinEnabled:(BOOL)enabled;


/**
 Set which social login will be available on sign in screen. Default is all. Facebook is always enabled.

 @param socialLoginService social logins
 */
+ (void)setSocialLoginOptions:(AXSSDKSocialLoginOption)socialLoginOption;

/**
 Set name for the app font
 
 @param fontName the name of the font
 */
+ (void)setFontName:(NSString *)fontName;


/**
 Set timeout for retrieving order history.  Default is 120 seconds.
 @param timeout the order history request timeout
 */
+ (void)setOrderHistoryRequestTimeout:(NSNumber *)timeout;

/**
 Returns current AXS SDK version

 @return current AXS SDK version
 */
+ (NSString *)version;

/**
 Set navigation title in FlashSeats marketplace find tickets screen
 
 @param navigationTitle String
 */
+ (void)setMarketplaceNavigationTitle:(NSString *)navigationTitle;

/**
 Set mobile Id theme to override user selection
 */
+ (void)setMobileIdThemeWithLeftColor:(UIColor *)leftColor rightColor:(UIColor *)rightColor;

- (NSString *)clientIdShort;
- (NSString *)clientId;
- (NSString *)partnerClientId;
- (NSString *)clientSecret;

- (AXSSDKTargetAPI)apiEnv;
- (AXSSDKTargetAPIType)apiType;

- (UIColor *)navigationBarColor;
- (UIColor *)navigationTitleColor;
- (UIColor *)backgroundColor;
- (UIColor *)textColor;
- (UIColor *)ctaColor;
- (UIColor *)ctaTextColor;
- (UIColor *)linkTextColor;
- (UIImage *)clientLogo;
- (NSString *)fontName;
- (UIColor *)mobileIdThemeLeftColor;
- (UIColor *)mobileIdThemeRightColor;

- (AXSSDKSocialLoginOption)socialLoginOptions;
- (BOOL)navigationBarTranslucent;
- (NSNumber *)orderHistoryRequestTimeOut;

- (NSString *)flashSeatsBasicAuth;

- (BOOL)flashSeatsMarketplaceEnabled;
- (BOOL)flashSeatsManualSiteSkinEnabled;

- (NSString *)marketplaceNavigationTitle;

+ (NSDictionary *)clientConfigs;
+ (BOOL)hasCustomMobileIdTheme;

@end
