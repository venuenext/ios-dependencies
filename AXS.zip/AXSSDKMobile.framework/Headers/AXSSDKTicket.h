//
//  AXSSDKTicket.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 7/7/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "AXSSDKTicketProtocol.h"

@class AXSSDKProduct;

/**
 *  Represents a ticket
 */
@interface AXSSDKTicket : NSManagedObject <AXSSDKTicketProtocol>

@property (nullable, nonatomic, retain) NSString * barcodeForwardedEmail;
@property (nullable, nonatomic, retain) NSString * barcodeForwardedFirstName;
@property (nullable, nonatomic, retain) NSString * barcodeForwardedLastName;
@property (nullable, nonatomic, retain) NSData * barcodeImageData;
@property (nullable, nonatomic, retain) NSNumber * barcodeIsValid;
@property (nullable, nonatomic, retain) NSString * barcodeStatus;
@property (nullable, nonatomic, retain) NSString * barcodeValue;
@property (nullable, nonatomic, retain) NSNumber * forwardAllowed;
@property (nullable, nonatomic, retain) NSString * forwardedActionId;
@property (nullable, nonatomic, retain) NSNumber * canSell;
@property (nullable, nonatomic, retain) NSNumber * canTransfer;
@property (nullable, nonatomic, retain) NSNumber * itemNumber;
@property (nullable, nonatomic, retain) NSString * name;
@property (nullable, nonatomic, retain) NSString * seatNumber;
@property (nullable, nonatomic, retain) NSString * seatRow;
@property (nullable, nonatomic, retain) NSString * seatSection;
@property (nullable, nonatomic, retain) NSString * ticketStatus;
@property (nullable, nonatomic, retain) NSString * ticketId;
@property (nullable, nonatomic, retain) NSString * flashTicketId;
@property (nullable, nonatomic, retain) NSNumber * barcodeStatusId;
@property (nullable, nonatomic, retain) NSString * fulfillmentId;
@property (nullable, nonatomic, retain) NSNumber * deliveryDelayed;
@property (nullable, nonatomic, retain) NSDate * fulfillmentHeldUntilDate;
@property (nullable, nonatomic, retain) NSString * barcodeOriginalCustomerName;
@property (nullable, nonatomic, retain) AXSSDKProduct *product;
@property (nullable, nonatomic, retain) NSNumber * minAskPrice;
@property (nullable, nonatomic, retain) NSNumber * maxAskPrice;
@property (nullable, nonatomic, retain) NSNumber * isETicket;
@property (nullable, nonatomic, retain) NSNumber * isFlashSeat;
@property (nullable, nonatomic, retain) NSNumber * isGeneralAdmission;

@property (nullable, nonatomic, retain) NSString * seatNeighborhood;
@property (nullable, nonatomic, retain) NSString * externalSeatInfo1;
@property (nullable, nonatomic, retain) NSString * externalSeatInfo2;
@property (nullable, nonatomic, retain) NSString * priceCodePrintDescription;
@property (nullable, nonatomic, retain) NSString * seatAttributes;

@property (nullable, nonatomic, retain) NSString * seat;
@property (nullable, nonatomic, retain) NSString * row;
@property (nullable, nonatomic, retain) NSString * section;

@property (nonatomic, assign) BOOL isConvertedToFlash;

@property (nullable, nonatomic, assign) NSString * rowPrintDescription;
@property (nullable, nonatomic, assign) NSString * sectionPrintDescription;

@end
