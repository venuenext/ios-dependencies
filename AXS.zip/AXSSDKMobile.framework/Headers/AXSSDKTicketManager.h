//
//  AXSSDKTicketManager.h
//  AXSSDKMobile
//
//  Created by Ruslan Syakin on 06/03/2019.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AXSSDKOrder;
@class AXSSDKTicket;
@class AXSSDKTicketAPI;
@protocol AXSSDKTicketProtocol;

@interface AXSSDKTicketManager : NSObject

/**
 Create ticket barcode image with order and ticket.

 @param order order object from order history
 @param ticket ticket in the order
 @return UIImage or nil
 */
+ (nullable UIImage *)createMobileBarcodeImageWithOrder:(nonnull AXSSDKOrder *)order ticket:(nonnull AXSSDKTicket *)ticket;


/**
 Create a TicketAPI object which can be used to Share/Transfer/Revoke a ticket.

 @param order AXSSDKOrder object
 @param ticket AXSSDKTicket object
 @return AXSSDKTicketAPI
 */
+ (nullable AXSSDKTicketAPI *)ticketAPIWithOrder:(nonnull AXSSDKOrder *)order ticket:(nonnull AXSSDKTicket *)ticket;


/**
 Create a TicketAPI object which can be used to Transfer/Revoke one or more tickets. NOTE: This doesn't support Share.

 @param order AXSSDKOrder object
 @param tickets Array of AXSSDKTicket objects
 @return AXSSDKTicketAPI
 */
+ (nullable AXSSDKTicketAPI *)ticketAPIWithOrder:(nonnull AXSSDKOrder *)order tickets:(nonnull NSArray<id<AXSSDKTicketProtocol>> *)tickets;
@end
