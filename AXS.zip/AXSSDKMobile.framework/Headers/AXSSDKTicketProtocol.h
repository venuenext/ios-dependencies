//
//  AXSSDKTicketProtocol.h
//  AXSSDKMobile
//
//  Created by Panda on 7/9/17.
//  Copyright © 2017 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AXSSDKTicketProtocol


@property (nullable, nonatomic, retain) NSString * seat;
@property (nullable, nonatomic, retain) NSString * row;
@property (nullable, nonatomic, retain) NSString * section;
@property (nullable, nonatomic, retain) NSString * ticketId;
@property (nullable, nonatomic, retain) NSString * flashTicketId;
@property (nullable, nonatomic, retain) NSString * name;
@property (nullable, nonatomic, retain) NSNumber * isETicket;
@property (nullable, nonatomic, retain) NSNumber * isFlashSeat;
@property (nullable, nonatomic, retain) NSString * forwardedActionId;

@optional
@property (nullable, nonatomic, retain) NSString * fulfillmentId;
@property (nullable, nonatomic, retain) NSNumber * itemNumber;
@property (nullable, nonatomic, retain) NSNumber * minAskPrice;
@property (nullable, nonatomic, retain) NSNumber * maxAskPrice;
@property (nullable, nonatomic, retain) NSNumber * deliveryDelayed;
@property (nullable, nonatomic, retain) NSString * seatNeighborhood;
@property (nullable, nonatomic, retain) NSString * externalSeatInfo1;
@property (nullable, nonatomic, retain) NSString * externalSeatInfo2;
@property (nullable, nonatomic, retain) NSString * priceCodePrintDescription;
@property (nullable, nonatomic, retain) NSString * seatAttributes;
@property (nullable, nonatomic, retain) NSNumber * barcodeStatusId;

@property (nullable, nonatomic, retain) NSNumber * isGeneralAdmission;
@property (nullable, nonatomic, assign) NSString * rowPrintDescription;
@property (nullable, nonatomic, assign) NSString * sectionPrintDescription;

@end
