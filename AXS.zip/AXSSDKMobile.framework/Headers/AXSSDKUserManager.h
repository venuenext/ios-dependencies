//
//  AXSSDKUserManager.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 7/19/17.
//  Copyright © 2017 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AXSSDKFSUser;

@interface AXSSDKUserManager : NSObject

/**
 Get Flash Seats user by Flash memeber IDs for device region

 @param memberIds array of flash seats member IDs
 @param completionHandler
 */
- (void)getFSUsersWithMemberIds:(nonnull NSArray *)memberIds completionHandler:(nullable void(^)(NSError * _Nullable error, NSArray<NSDictionary *> * _Nullable users))completionHandler;


/**
 Get Flash Seats user by Flash memeber IDs for a region

 @param memberIds array of flash seats member IDs
 @param regionId region id
 @param completionHandler 
 */
- (void)getFSUsersWithMemberIds:(nonnull NSArray *)memberIds regionId:(nonnull NSNumber *)regionId completionHandler:(nullable void(^)(NSError * _Nullable error, NSArray<NSDictionary *> * _Nullable users))completionHandler;


/**
 Link flash seats user to current AXS user

 @param flashUser flash seats user
 @param completionHandler
 */
- (void)linkFSAccount:(nonnull AXSSDKFSUser *)flashUser completionHandler:(nullable void(^)(NSError * _Nullable error))completionHandler;


/**
 Send verification email to flash user to complete migration with AXS account

 @param email flash email
 @param completionHandler
 */
- (void)sendVerificationFSAccountEmail:(nonnull NSString *)email completionHandler:( nullable void(^)(NSError * _Nullable error))completionHandler;

/**
 Change password
 
 @param currentPassword   current passowrd
 @param newPassword       new passowrd
 @param completionHandler
 */
- (void)changePassword:(nonnull NSString *)currentPassword to:(nonnull NSString *)newPassword completionHandler:(nullable void(^)(NSError * _Nullable error))completionHandler;

@end
