//
//  NSDate+AXSSDKMobile.h
//  AXSSDKMobile
//
//  Created by Wilson Lei on 11/6/18.
//  Copyright © 2018 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (AXSSDKMobile)

- (nonnull NSString *)axssdk_timeAgo;
+ (nonnull NSDate *)axssdk_yesterday;
+ (nonnull NSDate *)axssdk_dayBeforeYesterday;
- (nonnull NSDate *)axssdk_utcToLocalTime;


/**
 Check if the date is today with local timezone

 @return BOOL
 */
- (BOOL)axssdk_isToday;

@end
