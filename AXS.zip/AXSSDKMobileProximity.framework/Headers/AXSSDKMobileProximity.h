//
//  AXSSDKMobileProximity.h
//  AXSSDKMobileProximity
//
//  Created by Dennis Padilla on 7/8/15.
//  Copyright (c) 2015 Dennis Padilla. All rights reserved.
//

#ifndef DEBUG
#define NSLog(...);
#endif

#import <UIKit/UIKit.h>

//! Project version number for AXSSDKMobileProximity.
FOUNDATION_EXPORT double AXSSDKMobileProximityVersionNumber;

//! Project version string for AXSSDKMobileProximity.
FOUNDATION_EXPORT const unsigned char AXSSDKMobileProximityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AXSSDKMobileProximity/PublicHeader.h>
#import <AXSSDKMobileProximity/AXSSDKProximityManager.h>
