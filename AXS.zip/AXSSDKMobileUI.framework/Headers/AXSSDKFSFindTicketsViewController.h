//
//  AXSSDKFSFindTicketsViewController.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 7/25/16.
//  Copyright © 2016 AXS. All rights reserved.
//

#import <AXSSDKMobileUI/AXSSDKMobileUI.h>

#define kAXSSDKNotifyFindTicketsUpdate @"kAXSSDKNotifyFindTicketsUpdate"

@interface AXSSDKFSFindTicketsViewController : AXSSDKViewController

@end
