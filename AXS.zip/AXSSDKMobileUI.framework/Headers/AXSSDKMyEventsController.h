//
//  AXSSDKMyEventsController.h
//  AXSSDKMobileIDUI
//
//  Created by Nagamalleswararao on 5/19/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKViewController.h"

#define kAXSSDKNotiShowWelcome @"kAXSSDKNotiShowWelcome"
#define kAXSSDKNotiRefreshEvents @"kAXSSDKNotiRefreshEvents"

typedef enum : NSUInteger {
    AXSSDKMyEventMenuItemMyEvents,
    AXSSDKMyEventMenuItemShared,
    AXSSDKMyEventMenuItemTransferred,
} AXSSDKMyEventMenuItem;

/**
 *  AXS my events view controller. Subclass of AXSSDKViewController.
 */
@interface AXSSDKMyEventsController : AXSSDKViewController <UIScrollViewDelegate, UITableViewDelegate, UITableViewDataSource>

@end
