//
//  AXSSDKMyUpcomingEventNavigationController.h
//  AXSSDKMobileUI
//
//  Created by Andrew Choi on 7/8/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
* AXS my upcoming event view controller which includes event information, AXS Mobile ID or e-ticket barcodes depending on the upcoming event's method of delivery.
*/
@interface AXSSDKMyUpcomingEventNavigationController : UINavigationController

- (id)init;
+ (instancetype)initWithRootViewController;

@end
