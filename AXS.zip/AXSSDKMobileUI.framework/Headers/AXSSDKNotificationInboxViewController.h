//
//  AXSSDKNotificationInboxViewController.h
//  AXSSDKMobileUI
//
//  Created by jnation on 10/10/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <AXSSDKMobileUI/AXSSDKMobileUI.h>
@class AXSSDKInboxNotification;

@interface AXSSDKNotificationInboxViewController : AXSSDKViewController
- (instancetype)initWithFocusNotification:(AXSSDKInboxNotification *)focusNotification;
- (void)reloadData;
@end
