//
//  AXSSDKSignInBaseViewController.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 8/4/17.
//  Copyright © 2017 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKViewController.h"

@class AXSSDKFSUser;

@interface AXSSDKSignInBaseViewController : AXSSDKViewController

@property (nullable, nonatomic, strong) AXSSDKViewController *redirectController;

- (void)updateUserPreferenceWithCompletionHandler:(void(^ _Nullable)(NSError * _Nullable error))completionHandler;
- (void)updateUserPreferenceWithFlashUser:(nullable AXSSDKFSUser *)flashUser completionHandler:(void(^ _Nullable)(NSError * _Nullable error))completionHandler;
- (void)updateUserPreferenceWithPrivacyURL:(nonnull NSString *)privacyURL termsURL:(nonnull NSString *)termsURL isMarketingOptIn:(nonnull NSNumber *)isMarketingOptIn completionHandler:(void(^ _Nullable)(NSError * _Nullable error))completionHandler;
- (void)handleNextFlow;

@end
