//
//  AXSSDKTooltip.h
//  AXSSDKMobileUI
//
//  Created by jnation on 6/19/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
@class AXSSDKTooltipPreferences;


typedef enum: NSUInteger {
    AXSSDKArrowDirectionLeft, AXSSDKArrowDirectionRight, AXSSDKArrowDirectionUp, AXSSDKArrowDirectionDown
} AXSTooltipArrowDirection;

typedef enum: NSUInteger {
    AXSTooltipPositioningSideLeft, AXSTooltipPositioningSideRight, AXSTooltipPositioningSideAbove, AXSTooltipPositioningSideBelow
} AXSTooltipPositioningSide;

typedef BOOL (^BoolBlock) (void);


@interface AXSSDKTooltip : UIControl <UIGestureRecognizerDelegate>
@property (nonnull, nonatomic, strong) AXSSDKTooltipPreferences *preferences;

/**
 Hide and remove self
 @param animated Should/n't animate dismissal
 */
-(void)dismissWithAnimated:(BOOL)animated;

-(nonnull AXSSDKTooltip *)respawnSelfWithAnimated:(BOOL)animated;

/**
 Spawn Tooltip with default preferences and no identifying cacheKey.
 This instance will try to automatically present itself even if preferences.showOnlyOnFirstArrival==NO
 because it has no way of determining if it has been seen before.
 
 @param anchorView View which Tooltip is describing and positioned/sized by
 @param msg Tooltip body text
 @param positioningSide Which side of anchorView to place Tooltip
 @param animated Should/n't animate arrival
 @return the spawned Tooltip
 */
+(nonnull AXSSDKTooltip *)spawnWithAnchorView:(nonnull UIView *)anchorView
                       msg:(nonnull NSString *) msg
           positioningSide:(AXSTooltipPositioningSide)positioningSide
                  animated:(BOOL)animated;

/**
 Spawn Tooltip with default preferences and custom cacheKey.
 The cacheKey is used to determine whether this Tooltip has been
 displayed before.
 
 @param anchorView View which Tooltip is describing and positioned/sized by
 @param msg Tooltip body text
 @param positioningSide Which side of anchorView to place Tooltip
 @param cacheKey UserDefaults key used to determine if this tip has been shown before
 @param animated Should/n't animate arrival
 @return the spawned Tooltip
 */
+(nonnull AXSSDKTooltip *)spawnWithAnchorView:(nonnull UIView *)anchorView
                       msg:(nonnull NSString *) msg
           positioningSide:(AXSTooltipPositioningSide)positioningSide
                  cacheKey:(nonnull NSString *)cacheKey
                  animated:(BOOL)animated;

/**
 Spawn Tooltip with custom preferences, or pass null to use default
 preferences.  If `predicate` is nonnull, its execution must return YES
 or Tooltip will not show
 
 @param anchorView View which Tooltip is describing and positioned/sized by
 @param msg Tooltip body text
 @param positioningSide Which side of anchorView to place Tooltip
 @param preferences Custom styling preferences
 @param animated Should/n't animate arrival
 @param predicate must return true to show tooltip
 @return the spawned Tooltip
 */
+(nonnull AXSSDKTooltip *)spawnWithAnchorView:(nonnull UIView *)anchorView
                       msg:(nonnull NSString *) msg
           positioningSide:(AXSTooltipPositioningSide)positioningSide
               preferences:(nullable AXSSDKTooltipPreferences *)preferences
                  animated:(BOOL)animated
                 predicate:(nullable BoolBlock)predicate;

/**
 Spawn tooltip and immediately dismiss before it shows onscreen
 */
+(nonnull AXSSDKTooltip *)spawnOrphanWithAnchorView:(nonnull UIView *)anchorView
                                                msg:(nonnull NSString *) msg
                                    positioningSide:(AXSTooltipPositioningSide)positioningSide
                                        preferences:(nullable AXSSDKTooltipPreferences *)preferences
                                           animated:(BOOL)animated
                                          predicate:(nullable BoolBlock)predicate;

-(void)setVisibilityWithShouldShow:(BOOL)shouldShow
                          animated:(BOOL)animated
                             delay:(double)delay;
@end

