//
//  AXSSDKTooltipManager.h
//  AXSSDKMobileUI
//
//  Created by jnation on 6/20/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <UIKit/UIKit.h>

@class AXSSDKTooltip;
@class AXSSDKTooltipPreferences;

typedef void (^VoidBlock) (void);

static NSString * _Nonnull const AXSSDKUserHasSeenSeeTicketEventDetailsKey = @"AXSSDKUserHasSeenSeeTicketEventDetailsKey";
static NSString * _Nonnull const AXSSDKUserHasSeenSeeFSTicketEventDetailsKey = @"AXSSDKUserHasSeenSeeFSTicketEventDetailsKey";
static NSString * _Nonnull const AXSSDKUserHasSeenPickAppThemeKey = @"AXSSDKUserHasSeenPickAppThemeKey";

@interface AXSSDKTooltipManager : NSObject <UIGestureRecognizerDelegate>
@property (nonnull, nonatomic, strong) AXSSDKTooltipPreferences *defaultPreferences;


/**
 Returns YES if any alive anchor view is a subview of VC's view.
 @param viewController the VC owner of the root view to search for any alive anchor view
 */

- (BOOL)anchorViewFoundInViewController:(nonnull UIViewController *)viewController;


/**
 Set default preferences with option to skip global application of new value.
 @param preferences New default preferences
 @param applyGlobally Should/n't apply to all onscreen Tooltips
 */

-(void)setDefaultPreferencesWithPreferences:(nonnull AXSSDKTooltipPreferences *)preferences
                              applyGlobally:(BOOL)applyGlobally;

+(nonnull AXSSDKTooltipManager *)sharedInstance;

/**
 Dismiss all registered Tooltips where requireTapFocusViewForDismissal==NO
 @param animated Should/n't animate dismissal
 */
-(void)softDismissAllTooltipsWithAnimated:(BOOL)animated;

/**
 Dismiss all registered Tooltips regardless of requireTapFocusViewForDismissal
 @param animated Should/n't animate dismissal
 */
-(void)hardDismissAllTooltipsWithAnimated:(BOOL)animated;

/**
 Deregister a particular tooltip.  Should occur automatically upon Tooltip dealloc.
 @param tooltip The Tooltip to dismiss
 */
-(void)deregisterTooltip:(nonnull AXSSDKTooltip *)tooltip;

/**
 Register a particular Tooltip.  Should occur automatically upon Tooltip init.
 The TooltipManager can only interact with registered Tooltip's
 @param tooltip The Tooltip to register
 @param anchorView the Tooltip's anchorview
 */
-(void)registerTooltip:(nonnull AXSSDKTooltip *)tooltip
        withAnchorView:(nonnull UIView *)anchorView;

- (BOOL)toolTipisRegistered:(nonnull AXSSDKTooltip *)tooltip;

-(void)autoRepositionAllTooltips;

-(nonnull AXSSDKTooltipPreferences *)defaultPreferencesWithCacheKey:(nonnull NSString *)cacheKey;

-(int)aliveTooltipCount;
@end

