//
//  AXSSDKBaseViewController.h
//  AXSSDKMobileIDUI
//
//  Created by Wilson Lei on 6/3/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKNavigationCenterItemPreference.h"

#define AXSSDKViewControllerDidAppearNotification @"AXSSDKViewControllerDidAppearNotification"

typedef enum : NSUInteger {
    AXSSDKAuthTypeNone,
    AXSSDKAuthTypeAXS,
    AXSSDKAuthTypeFlashSeats
} AXSSDKAuthType;

typedef enum : NSUInteger {
    AXSSDKTopBannerStyleBlue,
    AXSSDKTopBannerStyleYellow,
} AXSSDKTopBannerStyle;

@interface AXSSDKViewController : UIViewController
@property (nullable, nonatomic, strong) NSString *pageTitle;

/**
 Indicate if view should hide navigation bar or not.
 */
@property (nonatomic, assign) BOOL isNavigationBarHidden;

/**
 Indicate if view should hide navigation bar drop shadow or not.
 */
@property (nonatomic, assign) BOOL isNavigationBarShadowHidden;

/**
 *  Show this controller modally.
 *
 *  @param controller The parent controller that presents the modal.
 *  @param completion completion handler
 */
- (void)showFromController:(nonnull UIViewController *)controller completion:(void(^ _Nullable)(void))completion;

/**
 *  Push this controller to a navigation controller
 *
 *  @param navigationController The navigation controller
 *  @param animated             Animate or not
 */
- (void)pushToNavigationController:(nonnull UINavigationController *)navigationController animated:(BOOL)animated;

/**
 *  Replace the current view controller without animation
 *
 *  @param controller a new view controller
 */
- (void)replaceNavigationCurrentControllerWithController:(nonnull AXSSDKViewController *)controller;

/**
 *  Replace the current view controller with or without animation
 *
 *  @param controller a new view controller
 *  @param animated   animated or not
 */
- (void)replaceNavigationCurrentControllerWithController:(nonnull AXSSDKViewController *)controller animated:(BOOL)animated;

/**
 *  Remove all AXSSDKViewControllers in the navigation stack and then add a new view controller
 *
 *  @param controller a new view controller
 *  @param animated   animiated or not
 */
- (void)replaceNavigationAllControllersWithController:(nonnull AXSSDKViewController *)controller animated:(BOOL)animated;

/**
 *  Remove all AXSSDKSignInBaseViewController in the navigation stack and then add a new view controller
 *
 *  @param controller a new view controller
 *  @param animated   animiated or not
 */
- (void)replaceNavigationAllSignInControllersWithController:(nonnull AXSSDKViewController *)controller animated:(BOOL)animated;

/**
 *  Add more items to the navigation bar left items.
 *
 *  @param leftBarButtonItems Array of bar items.
 */
- (void)addNavigationBarLeftItems:(nonnull NSArray *)leftBarButtonItems;

/**
 *  Add more items to the navigation bar right items.
 *
 *  @param leftBarButtonItems Array of bar items.
 */
- (void)addNavigationBarRightItems:(nonnull NSArray *)rightBarButtonItems;

/**
 *  Set navigation center item display preference. e.g. title only, logo only or both title and logo.
 *
 *  @param navigationCenterItemPreference AXSSDKNavigationCenterItemPreference
 */
- (void)setNavigationCenterItemPreference:(AXSSDKNavigationCenterItemPreference)navigationCenterItemPreference;

/**
 *  Set navigation center item image. This overrides the value in AXSSDKSettings.
 *
 *  @param navigationCenterItemImage image
 */
- (void)setNavigationCenterItemImage:(nonnull UIImage *)navigationCenterItemImage;

/**
 *  Show a large activity indicator in the center of the view
 */
- (void)showActivityIndicator;

/**
 *  Show a large activity indicator in the center of the view with or without an overlay. The overlay blocks user interaction.
 *
 *  @param overlay has overlay or not
 */
- (void)showActivityIndicatorWithOverlay:(BOOL)overlay;

/**
 *  Hide center activity indicator
 */
- (void)hideActivityIndicator;

/**
 Display a static yellow banner with error message on top of the view with refresh button
 *  To add refresh action we need to override 'refreshAndDismissBanner' in child class and do not forget call 'super'
 
 @param message Attributed message
 */
- (void)showErrorBannerWithRefreshButtonAndAttributedTitle:(nonnull NSAttributedString *)message
                                                     style:(AXSSDKTopBannerStyle)style;

/**
 Display a timed blue banner with default logout message on top of the view
 
 */
- (void)showLoggedOutBanner;

/**
 Display a static yellow banner with default error message on top of the view with close button

 */
- (void)showAPIErrorBanner;

/**
 Display a static banner message on top of the view with close button

 @param message message
 */
- (void)showTopAttributedMessage:(nonnull NSAttributedString *)message style:(AXSSDKTopBannerStyle)style;

/**
 Display a banner message on top of the view for a few seconds
 
 @param message message
 @param style TopBannerStyle for banner
 */
- (void)showTimedTopAttributedMessage:(nonnull NSAttributedString *)message style:(AXSSDKTopBannerStyle)style;

- (void)refreshAndDismissBannerWithSender:(nullable NSNotification *)sender;

/**
 *  Private method
 */
- (void)showCloseButton;

/**
 *  Private method
 */
- (void)showMenuButton;


/**
 Indicate if current view controller is being presented modally or not

 @return BOOL
 */
- (BOOL)isModal;


/*
 Present alert discouraging users from taking screenshots of their mobile ID
 */
- (void)showScreenshotDetectedAlert;

/**
 *  Private method
 *
 *  @param authType           Required authorization type
 *  @param redirectController A redirect controller after authorization is completed
 */
- (BOOL)authenticate:(AXSSDKAuthType)authType redirectController:(nonnull AXSSDKViewController *)redirectController;


/**
 Private method
 */
- (void)startLoadingData;

/**
 Private method
 */
- (void)stopLoadingData;

-(BOOL)isOnscreen;

- (nullable UIScrollView *)baseScrollView;

@end
