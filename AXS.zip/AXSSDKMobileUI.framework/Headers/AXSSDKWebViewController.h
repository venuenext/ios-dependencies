//
//  AXSSDKWebViewController.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 12/7/15.
//  Copyright © 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "AXSSDKViewController.h"

typedef enum
{
    kAXSSDKWebViewSourceTypeRequest,
    kAXSSDKWebViewSourceTypeHTMLString
} AXSSDKWebViewSourceType;

/**
 A simple WebView controller
 */
@interface AXSSDKWebViewController : AXSSDKViewController

@property (nullable, nonatomic, strong) WKWebView *webView;

@property (nonatomic, assign) BOOL shouldDisplayDoneButton;
@property (nonatomic, assign) BOOL shouldIgnoreFrameLoadInterruptErrors;
@property (nonatomic, assign) BOOL toolbarHidden;
@property (nonatomic, assign) BOOL shouldHideTitle;

@property (nullable, nonatomic, strong) UIImage *backButtonItemImage;
@property (nullable, nonatomic, strong) UIImage *forwardButtonItemImage;

- (nonnull id)initWithURL:(nonnull NSString *)url;
- (nonnull id)initWithHTMLString:(nonnull NSString *)html;
- (void)setScalePageToFit:(BOOL)scalePageToFit;

@end
