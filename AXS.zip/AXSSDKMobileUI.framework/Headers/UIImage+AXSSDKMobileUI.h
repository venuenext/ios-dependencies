//
//  AXSSDKMobileUI+UIImage.h
//  AXSSDKMobileIDUI
//
//  Created by Nagamalleswararao on 6/5/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIImage (AXSSDKMobileUI)

+ (nullable UIImage*)axssdk_imageNamed:(nonnull NSString*)name;
+ (nullable UIImage*)axssdk_imageNamed:(nonnull NSString*)name fromBundle:(nonnull NSBundle *)bundle;
- (nonnull UIImage *)axssdk_maskWithColor:(nonnull UIColor *)color;
+ (nonnull UIImage *)axssdk_solidColorImage:(nonnull UIColor *)color;

@end
