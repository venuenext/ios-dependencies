//
//  UIView+AXSSDKMobileUI.h
//  AXSSDKMobileUI
//
//  Created by Andrew Choi on 12/17/18.
//  Copyright © 2018 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    AXSSDKGradientDirectionLeftToRight = 0,
    AXSSDKGradientDirectionRightToLeft,
    AXSSDKGradientDirectionTopToBottom,
    AXSSDKGradientDirectionBottomToTop
} AXSSDKGradientDirection;

typedef enum : NSUInteger {
    AXSSDKGradientColorOrchid = 0,
    AXSSDKGradientColorPeach,
    AXSSDKGradientColorMojito,
    AXSSDKGradientColorDaffodil
} AXSSDKGradientColor;

@interface UIView (AXSSDKMobileUI)

- (void)grayOut;
- (void)startShimmerAnimationInFrame:(CGRect)frame color:(nonnull UIColor *)color;
- (void)stopShimmerAnimation;
- (void)gradientBackground:(AXSSDKGradientColor)gradientColor;

- (void)gradientBackgroundFrom:(nonnull UIColor *)color1
                            to:(nonnull UIColor *)color2
                     direction:(AXSSDKGradientDirection)direction;

- (void)removeGradient;

@end
