//
//  AXSSDKAccountViewController.h
//  AXSSDKMobileUI
//
//  Created by Andrew Choi on 1/2/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import "AXSSDKSignInBaseViewController.h"

/**
 *  AXS My Account view controller
 */
@interface AXSSDKAccountViewController : AXSSDKSignInBaseViewController

@end
