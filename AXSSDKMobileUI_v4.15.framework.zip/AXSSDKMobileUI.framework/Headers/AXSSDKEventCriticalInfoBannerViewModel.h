//
//  AXSSDKEventCriticallInfoBannerViewModel.h
//  AXSSDKMobileUI
//
//  Created by Andrii Maliarchuk on 12.3.20.
//  Copyright © 2020 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AXSSDKEventCriticalInfoBannerViewModel : NSObject

@property (strong, nonatomic, nullable) NSAttributedString *title;
@property (strong, nonatomic, nullable) NSAttributedString *buttonTitle;
@property (strong, nonatomic, nonnull) UIColor *backgroundColor;
@property (nonatomic, copy, nullable) void(^onButtonTap)(void);

@end

@interface AXSSDKEventCriticalInfoBannerViewModel (Predefined)

+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)cancelledEventShowCta:(BOOL)showCta NS_SWIFT_NAME(cancelledEvent(showCTA:));
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)postponedEventShowCta:(BOOL)showCta NS_SWIFT_NAME(postponedEvent(showCTA:));
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)suspendedEventShowCta:(BOOL)showCta NS_SWIFT_NAME(suspendedEvent(showCTA:));
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)rescheduledEventShowDescription:(BOOL)showDescription showCta:(BOOL)showCta NS_SWIFT_NAME(rescheduledEvent(showDescription:showCTA:));
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)rescheduledEventNewVenueShowDescription:(BOOL)showDescription showCta:(BOOL)showCta NS_SWIFT_NAME(rescheduledEventNewVenue(showDescription:showCTA:));
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)newVenueShowDescription:(BOOL)showDescription showCta:(BOOL)showCta NS_SWIFT_NAME(newVenue(showDescription:showCTA:));
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)refundPendingWithDescription:(nullable NSString *)description;
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)refundRequestedWithDescription:(nullable NSString *)description;
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)refundProblem;
+ (nonnull AXSSDKEventCriticalInfoBannerViewModel *)donatedTicketWithMessage:(nullable NSString *)message showCta:(BOOL)showCta NS_SWIFT_NAME(donatedTicket(message:showCTA:));

@end
