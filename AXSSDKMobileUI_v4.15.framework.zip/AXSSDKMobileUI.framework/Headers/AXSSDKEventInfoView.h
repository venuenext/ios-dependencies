//
//  AXSSDKEventInfoView.h
//  AXSSDKMobileIDUI
//
//  Created by Nagamalleswararao on 6/15/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AXSSDKMobile/AXSSDKMobile.h>

@class AXSSDKEvent, AXSSDKOrder, AXSSDKScrollingLabel;

@protocol AXSSDKEventInfoViewDelegate

- (void)openTicketDetails;

@end

typedef enum : NSUInteger {
    AXSSDKEventInfoViewThemeGray,  // gray text, blue Weekday
    AXSSDKEventInfoViewThemeWhite,  // all text is white
    AXSSDKEventInfoViewThemeWhiteUpcoming // all text is white and listed/shared label is visible
} AXSSDKEventInfoViewTheme;


@interface AXSSDKEventInfoView : UIView

@property (weak, nonatomic) IBOutlet UIImageView * _Nullable ticketsNumberImage;
@property (nullable, weak, nonatomic) IBOutlet AXSSDKScrollingLabel *eventTimesLabel;
@property (nullable, weak, nonatomic) IBOutlet UILabel *eventDateLabel;
@property (weak, nonatomic) id<AXSSDKEventInfoViewDelegate> _Nullable delegate;

- (void)showInfoViewWithOrder:(nonnull id<AXSSDKOrderProtocol> )order
                  ticketCount:(nullable NSNumber *)ticketCount
                        theme:(AXSSDKEventInfoViewTheme)theme;

- (void)showInfoViewWithEvent:(nonnull id<AXSSDKEventProtocol>)event
                  ticketCount:(nullable NSNumber *)ticketCount
                        theme:(AXSSDKEventInfoViewTheme)theme;
@end
