//
//  AXSSDKFSMobileIdView.h
//  AXSSDKMobileUI
//
//  Created by Andrii Maliarchuk on 13.11.19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AXSSDKFSMobileIdViewDelegate;
@class AXSSDKFSMobileIdViewModel;
@class AXSSDKTicketDetailsView;

@protocol AXSSDKFSMobileIdView <NSObject>

- (void)applyViewModel:(nonnull AXSSDKFSMobileIdViewModel *)viewModel;
- (void)showBankAccountAlertWithConfirmationHandler:(void(^_Nullable)(void))confirmationHandler;
- (void)showBarcodeReloadFailureAlert;
- (void)dismiss;

@end

@protocol AXSSDKFSMobileIdViewDelegate <NSObject>

@property (nonatomic, assign) AXSSDKFSMobileIDBarcodeDisplayMode barcodeDisplayMode;

- (void)mobileIdViewDidBecomeReady;
- (void)mobileIdViewWillAppear;
- (void)mobileIdViewDidAppear;
- (void)mobileIdViewWillDisappear;
- (void)mobileIdDidGenerateBarcode;
- (void)mobileIdDidDisableBarcode;
- (void)mobileIdViewDidTapSellButton;
- (void)mobileIdViewDidTapDismissButton;
- (void)mobileIdViewDidTapInfoButton;

@end
