//
//  AXSSDKMobileIDBarcodeCell.h
//  AXSSDKMobileUI
//
//  Created by jnation on 9/3/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKRefreshIDControl.h"

@class AXSSDKFSMobileIdControl, AXSSDKMobileIDBarcodeCellViewModel;
@protocol AXSSDKMobileIDBarcodeCellDelegate;

@interface AXSSDKMobileIDBarcodeCell : UICollectionViewCell

@property (nonatomic, weak, nullable) id<AXSSDKMobileIDBarcodeCellDelegate> delegate;
@property (nonatomic, strong, nonnull) AXSSDKRefreshIDControl *refreshControl;

- (void)applyViewModel:(AXSSDKMobileIDBarcodeCellViewModel *_Nonnull)viewModel;
- (void)restartTimer;
- (void)stopTimer;

@end

@protocol AXSSDKMobileIDBarcodeCellDelegate <NSObject>
@optional
- (void)mobileIDBarcodeCell:(AXSSDKMobileIDBarcodeCell *_Nonnull)cell didFailToReloadBarcodeWithError:(NSError *_Nullable)error;
- (void)mobileIDBarcodeCellDidTapAddToWalletButton:(AXSSDKMobileIDBarcodeCell *_Nonnull)cell;
- (void)mobileIDBarcodeCellDidTapViewInWalletButton:(AXSSDKMobileIDBarcodeCell *_Nonnull)cell;
@end
