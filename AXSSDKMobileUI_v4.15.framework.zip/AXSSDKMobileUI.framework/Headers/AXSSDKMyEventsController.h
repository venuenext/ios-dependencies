//
//  AXSSDKMyEventsController.h
//  AXSSDKMobileIDUI
//
//  Created by Nagamalleswararao on 5/19/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKViewController.h"

#define kAXSSDKNotiShowWelcome @"kAXSSDKNotiShowWelcome"
#define kAXSSDKNotiRefreshEvents @"kAXSSDKNotiRefreshEvents"

typedef enum : NSUInteger {
    AXSSDKMyEventMenuItemMyEvents,
    AXSSDKMyEventMenuItemShared,
    AXSSDKMyEventMenuItemTransferred,
} AXSSDKMyEventMenuItem;

@class AXSSDKOrder, AXSSDKCharity;

@protocol AXSSDKMyEventsDelegate <NSObject>

@optional
- (void)didSelectEvent:(nonnull AXSSDKOrder*)order;

@end

/**
 *  AXS my events view controller. Subclass of AXSSDKViewController.
 */
@interface AXSSDKMyEventsController : AXSSDKViewController <UIScrollViewDelegate, UITableViewDelegate, UITableViewDataSource>

/**
 Indicate if view should bring up Mobile Id popup.
 */
@property (nonatomic, assign) BOOL isMobileIdPopupEnabled __deprecated_msg("Will be removed in 5.0 release");

/**
 Indicate if pull to refresh is enabled.
 */
@property (nonatomic, assign) BOOL isPullToRefreshEnabled;

/**
 Indicate if bounce is enabled.
 */
@property (nonatomic, assign) BOOL isScrollBouncingEnabled;

/**
 Indicate charity that ticket was donated to. Only need to set when AXSSDKSettings.myEventsRedirectEnabled = NO.
*/
@property (nullable, nonatomic, strong) AXSSDKCharity *donatedCharity;

/**
Indicate if is scrolling is enabled.
*/
- (void)setScrollEnabled:(BOOL)enabled;

/**
 Set a delegate to inform of Upcoming Event selection.
*/
@property (nullable, nonatomic, weak) id<AXSSDKMyEventsDelegate> delegate;

@end
