//
//  AXSSDKNavigationCenterItemPreference.h
//  AXSSDKMobileUI
//
//  Created by Nagamalleswararao on 6/24/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

/**
 *  Navigation bar center title preference
 */
typedef enum : NSUInteger {
    /**
     *  Show title only, default.
     */
    AXSSDKNavigationCenterItemPreferenceTitle = 1,
    /**
     *  Show image only.
     */
    AXSSDKNavigationCenterItemPreferenceLogo,
    /**
     *  Show both title and image.
     */
    AXSSDKNavigationCenterItemPreferenceTitleAndLogo
} AXSSDKNavigationCenterItemPreference;
