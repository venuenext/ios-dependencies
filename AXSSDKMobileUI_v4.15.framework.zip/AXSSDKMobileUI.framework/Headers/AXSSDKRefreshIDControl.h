//
//  AXSSDKRefreshIDControl.h
//  AXSSDKMobileUI
//
//  Created by jnation on 9/3/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AXSSDKRefreshIDControl: UIControl
- (void)setTintColor:(UIColor*)color;
- (void)setCounterLabelSeconds:(int)seconds;
@end
