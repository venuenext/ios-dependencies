//
//  AXSSDKSignInAXSViewController.h
//  AXSSDKMobileIDUI
//
//  Created by Nagamalleswararao on 5/19/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKSignInBaseViewController.h"
@class AXSSDKFSUser, AXSSDKResult;

/**
 *  AXS user sign in view controller. Subclass of AXSSDKViewController.
 */
@interface AXSSDKSignInAXSViewController : AXSSDKSignInBaseViewController

/**
 Indicate if view should hide closeButton.
 */
@property (nonatomic, assign) BOOL isCloseButtonHidden;

@end
