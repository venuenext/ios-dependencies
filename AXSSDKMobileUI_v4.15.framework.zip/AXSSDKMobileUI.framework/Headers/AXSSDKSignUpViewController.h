//
//  AXSSDKSignUpViewController.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 6/7/17.
//  Copyright © 2017 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKSignInBaseViewController.h"

@class AXSSDKFSUser;

@interface AXSSDKSignUpViewController : AXSSDKSignInBaseViewController
@end
