//
//  AXSSDKVersionDetailView.h
//  AXSSDKMobileUI
//
//  Created by jnation on 11/16/20.
//  Copyright © 2020 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface AXSSDKVersionDetailView : UILabel

@end


