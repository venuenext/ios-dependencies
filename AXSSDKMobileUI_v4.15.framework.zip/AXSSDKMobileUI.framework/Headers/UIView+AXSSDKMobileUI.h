//
//  UIView+AXSSDKMobileUI.h
//  AXSSDKMobileUI
//
//  Created by Andrew Choi on 12/17/18.
//  Copyright © 2018 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    AXSSDKGradientDirectionLeftToRight = 0,
    AXSSDKGradientDirectionRightToLeft,
    AXSSDKGradientDirectionTopToBottom,
    AXSSDKGradientDirectionBottomToTop
} AXSSDKGradientDirection;

typedef enum : NSUInteger {
    AXSSDKGradientColorOrchid = 0,
    AXSSDKGradientColorPeach,
    AXSSDKGradientColorMojito,
    AXSSDKGradientColorDaffodil
} AXSSDKGradientColor;

@interface UIView (AXSSDKMobileUI)

+ (void)axssdk_withoutAnimation:(void(^_Nonnull)(void))block;

- (void)axssdk_grayOut;
- (void)axssdk_startShimmerAnimationInFrame:(CGRect)frame color:(nonnull UIColor *)color;
- (void)axssdk_stopShimmerAnimation;
- (void)axssdk_gradientBackground:(AXSSDKGradientColor)gradientColor;
- (void)axssdk_gradientBackgroundFrom:(nonnull UIColor *)color1 to:(nonnull UIColor *)color2 direction:(AXSSDKGradientDirection)direction;
- (void)axssdk_removeGradient;

@end

@interface CAGradientLayer (AXSSDKMobileUI)

- (void)axssdk_applyGradient:(AXSSDKGradientColor)color;
- (void)axssdk_applyGradient:(AXSSDKGradientColor)color direction:(AXSSDKGradientDirection)direction;

@end
