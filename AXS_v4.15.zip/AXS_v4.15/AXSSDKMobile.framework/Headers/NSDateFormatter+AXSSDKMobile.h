//
//  NSDateFormatter+AXSSDKMobile.h
//  AXSSDKMobile
//
//  Created by jnation on 6/14/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateFormatter (AXSSDKMobile)

+ (nonnull instancetype)axssdk_formatterWithPOSIXLocale;

@end
