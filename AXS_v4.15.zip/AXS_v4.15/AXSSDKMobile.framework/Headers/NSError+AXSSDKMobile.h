//
//  NSError+Utility.h
//  AXSSDKMobile
//
//  Created by jnation on 11/8/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSError (Utility)
- (nullable NSString *)axssdk_localizedDescription;
@end

