//
//  AXSSDKProximityManager.h
//  AXSSDKMobileProximity
//
//  Created by Dennis Padilla on 7/8/15.
//  Copyright (c) 2015 Dennis Padilla. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  Proximity manager delegate
 */
@protocol AXSSDKProximityManagerDelegate <NSObject>

@optional
/**
 *  Protocol when user enters geofence region, but bluetooth is off.
 */
- (void)bluetoothOffWhenEnterGeofenceRegion;

@end

/**
 *  Proximity manager
 */
@interface AXSSDKProximityManager : NSObject

@property (nonatomic, weak) id<AXSSDKProximityManagerDelegate> delegate;

/**
 *  Shared instance of the class
 *
 *  @return class object
 */
+ (AXSSDKProximityManager *)sharedInstance;

/**
 *  Starts monitoring geofence and beacons
 */
- (void)startMonitoring;

/**
 *  Stoops monitoring geofence and beacons
 */
- (void)stopMonitoring;

/**
 *  Sets Gimbal API key
 *
 *  @param key Gimbal API key
 */
+ (void)setApiKey:(NSString *)key;

/**
 *  Enable debug view
 *
 *  @param enable BOOL
 */
+ (void)setDebug:(BOOL)debug;

/**
 *  Show proximity debug view modally
 */
- (void)showDebugView;

- (BOOL)isDebug;
@end
