//
//  AXSSDKCharity.h
//  AXSSDKMobileUI
//
//  Created by gpan on 4/23/20.
//  Copyright © 2020 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
@import AXSSDKMobile;

@interface AXSSDKCharity : AXSSDKModel

@property (nonnull, nonatomic, strong) NSString *id;
@property (nullable, nonatomic, strong) NSString *donationConfirmMessage;
@property (nullable, nonatomic, strong) NSString *learnMoreUrl;

@end
