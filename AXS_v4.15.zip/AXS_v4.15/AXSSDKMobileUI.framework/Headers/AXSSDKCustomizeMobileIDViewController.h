//
//  AXSSDKCustomizeMobileIDViewController.h
//  AXSSDKMobileUI
//
//  Created by Andrew Choi on 5/31/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <AXSSDKMobileUI/AXSSDKMobileUI.h>

@interface AXSSDKCustomizeMobileIDViewController : AXSSDKViewController

@property (nonatomic, copy) void(^onCloseButtonTap)(void);

@end
