//
//  AXSSDKEventCriticallInfoBanner.h
//  AXSSDKMobileUI
//
//  Created by Andrii Maliarchuk on 12.3.20.
//  Copyright © 2020 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKEventCriticalInfoBannerViewModel.h"

@interface AXSSDKEventCriticalInfoBanner : UIView

@property (weak, nonatomic) IBOutlet UILabel *label;

- (void)applyViewModel:(AXSSDKEventCriticalInfoBannerViewModel *)viewModel;

@end
