//
//  AXSSDKFSMobileIdViewController.h
//  AXSSDKMobileIDUI
//
//  Created by Wilson Lei on 11/11/15.
//  Copyright © 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKViewController.h"
#import "AXSSDKEventInfoView.h"
#import "AXSSDKFSMobileIdView.h"

@protocol AXSSDKPresenter;

@interface AXSSDKFSMobileIdViewController : AXSSDKViewController <AXSSDKFSMobileIdView>

@property (nonatomic, weak, nullable) id<AXSSDKFSMobileIdViewDelegate> delegate;

/**
 Indicate if view should automatically handle auto brightness.
 */
@property (nonatomic, assign) BOOL isAutoBrightnessEnabled;

- (void)setBarcodeDisplayMode:(AXSSDKFSMobileIDBarcodeDisplayMode)displayMode;

+ (nonnull instancetype)withPresenter:(nonnull id<AXSSDKPresenter, AXSSDKFSMobileIdViewDelegate>)presenter;

@end

@interface AXSSDKFSMobileIdViewController (Predefined)

+ (nonnull id)withOrder:(nullable id<AXSSDKOrderProtocol>)order;
+ (nonnull id)withOrder:(nullable id<AXSSDKOrderProtocol>)order isAutoBrightnessEnabled:(BOOL)autoBrightnessEnabled;
+ (nonnull id)withOrder:(nullable id<AXSSDKOrderProtocol>)order isAutoBrightnessEnabled:(BOOL)autoBrightnessEnabled barcodeDisplayMode:(AXSSDKFSMobileIDBarcodeDisplayMode)displayMode;

@end

@interface AXSSDKFSMobileIdViewController (Deprecated)

+ (nonnull id)withOrder:(nullable id<AXSSDKOrderProtocol>)order eventInfoTheme:(AXSSDKEventInfoViewTheme)eventInfoTheme DEPRECATED_ATTRIBUTE;

@end
