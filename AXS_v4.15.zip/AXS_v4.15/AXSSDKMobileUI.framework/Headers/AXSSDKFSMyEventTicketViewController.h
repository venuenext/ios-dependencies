//
//  AXSSDKFSMyEventTicketViewController.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 7/20/16.
//  Copyright © 2016 AXS. All rights reserved.
//

#import <AXSSDKMobileUI/AXSSDKMobileUI.h>

@protocol AXSSDKOrderProtocol;

@protocol AXSSDKFSMyEventTicketDelegate <NSObject>
@optional
- (void)didSelectUnlistedEvent:(nonnull id<AXSSDKOrderProtocol>)order;

@end

@interface AXSSDKFSMyEventTicketViewController : AXSSDKViewController

/**
 Set a delegate to inform of Upcoming Event selection.
*/
@property (nullable, nonatomic, weak) id<AXSSDKFSMyEventTicketDelegate> delegate;

- (nonnull id)initWithOrder:(nonnull id<AXSSDKOrderProtocol>)order;

@end
