//
//  AXSSDKInboxNotificationDetailViewController.h
//  AXSSDKMobileUI
//
//  Created by jnation on 10/11/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <AXSSDKMobileUI/AXSSDKMobileUI.h>
#import <UIKit/UIKit.h>
@class AXSSDKInboxNotification;

@interface AXSSDKInboxNotificationDetailViewController : AXSSDKViewController
- (nonnull instancetype)initWithNotification:(nonnull AXSSDKInboxNotification *)notification;
@end

