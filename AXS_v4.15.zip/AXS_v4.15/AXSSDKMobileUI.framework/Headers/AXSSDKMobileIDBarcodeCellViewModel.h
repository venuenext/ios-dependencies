//
//  AXSSDKMobileIDBarcodeCellViewModel.h
//  AXSSDKMobileUI
//
//  Created by Andrii Maliarchuk on 23.10.19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <Foundation/Foundation.h>
@import AXSSDKMobile;
@class AXSSDKFSUser;
@protocol AXSSDKOrderProtocol;

typedef NS_ENUM(NSInteger, AXSSDKMobileIDBarcodeCellWalletPassState) {
    AXSSDKMobileIDBarcodeCellWalletPassStateNone = 0,
    AXSSDKMobileIDBarcodeCellWalletPassStateAbleToAdd,
    AXSSDKMobileIDBarcodeCellWalletPassStateView
};

@interface AXSSDKMobileIDBarcodeCellViewModel : NSObject

@property (copy, nonatomic, nonnull) NSString *memberId;
@property (copy, nonatomic, nonnull) NSString *mobileId;
@property (copy, nonatomic, nonnull) NSNumber *regionId;
@property (copy, nonatomic, nonnull) NSString *regionIdString;
@property (nonatomic, assign) AXSSDKFSMobileIDBarcodeDisplayMode barcodeDisplayMode;
@property (nonatomic, assign) AXSSDKMobileIDBarcodeCellWalletPassState walletPassState;

- (instancetype _Nonnull)initWithUser:(AXSSDKFSUser *_Nonnull)user;
- (instancetype _Nonnull)initWithOrder:(id<AXSSDKOrderProtocol> _Nonnull)order;

@end
