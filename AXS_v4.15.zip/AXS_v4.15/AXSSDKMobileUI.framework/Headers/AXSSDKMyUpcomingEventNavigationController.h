//
//  AXSSDKMyUpcomingEventNavigationController.h
//  AXSSDKMobileUI
//
//  Created by Andrew Choi on 7/8/19.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>


/// User upcoming event view controller
@interface AXSSDKMyUpcomingEventNavigationController : UINavigationController

- (id)init;
+ (id)initWithRootViewController;

@end
