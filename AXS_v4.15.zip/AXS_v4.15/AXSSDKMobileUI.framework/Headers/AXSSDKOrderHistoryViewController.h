//
//  AXSSDKOrderHistoryViewController.h
//  AXSSDKMobileUI
//
//  Created by Ruslan Syakin on 09/01/2019.
//  Copyright © 2019 AXS. All rights reserved.
//

#import <AXSSDKMobileUI/AXSSDKMobileUI.h>

@interface AXSSDKOrderHistoryViewController : AXSSDKViewController

@end
