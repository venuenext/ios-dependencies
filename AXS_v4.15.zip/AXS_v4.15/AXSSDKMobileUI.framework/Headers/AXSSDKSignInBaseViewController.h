//
//  AXSSDKSignInBaseViewController.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 8/4/17.
//  Copyright © 2017 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AXSSDKViewController.h"
@import AXSSDKMobile;
@class AXSSDKFSUser;

@interface AXSSDKSignInBaseViewController : AXSSDKViewController

/**
Indicate if following important info screens should hide bottom bars on push. Setting `hidesBottomBarWhenPushed` will update this property as well.
*/
@property (nonatomic, assign) BOOL subsequentScreensShouldHideBottomBarWhenPushed;

@property (nullable, nonatomic, strong) UIViewController *redirectController;

@end
