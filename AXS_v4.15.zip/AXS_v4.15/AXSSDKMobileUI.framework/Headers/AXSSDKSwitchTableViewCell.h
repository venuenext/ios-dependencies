//
//  AXSSDKSwitchTableViewCell.h
//  AXSSDKMobileUI
//
//  Created by jnation on 12/7/20.
//  Copyright © 2020 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AXSSDKSwitchTableViewCell : UITableViewCell

@property (copy, nullable) void (^afterSwitchValueChangeBlock)(BOOL);
- (void)configureWithTitle:(nonnull NSString *)title isOn:(BOOL)isOn;

@end

