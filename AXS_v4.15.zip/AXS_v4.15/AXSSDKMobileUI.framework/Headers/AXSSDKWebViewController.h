//
//  AXSSDKWebViewController.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 12/7/15.
//  Copyright © 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "AXSSDKViewController.h"

typedef enum
{
    kAXSSDKWebViewSourceTypeRequest,
    kAXSSDKWebViewSourceTypeHTMLString
} AXSSDKWebViewSourceType;

/**
 AXS WebView controller which persists user login state.
 */
@interface AXSSDKWebViewController : AXSSDKViewController

@property (nonatomic, copy, nullable) BOOL(^shouldPerformNavigation)(NSURLRequest *_Nonnull, WKNavigationType);

@property (nullable, nonatomic, strong) WKWebView *webView;

@property (nonatomic, assign) BOOL shouldDisplayDoneButton;
@property (nonatomic, assign) BOOL shouldIgnoreFrameLoadInterruptErrors;
@property (nonatomic, assign) BOOL toolbarHidden;
@property (nonatomic, assign) BOOL shouldHideTitle;

@property (nullable, nonatomic, strong) UIImage *backButtonItemImage;
@property (nullable, nonatomic, strong) UIImage *forwardButtonItemImage;


/// Init with url
/// @param url url that should be loaded into the webview.
- (nonnull id)initWithURL:(nonnull NSString *)url;
- (nonnull id)initWithHTMLString:(nonnull NSString *)html;
- (void)setScalePageToFit:(BOOL)scalePageToFit;
- (void)loadURL:(nonnull NSString *)url;

@end
