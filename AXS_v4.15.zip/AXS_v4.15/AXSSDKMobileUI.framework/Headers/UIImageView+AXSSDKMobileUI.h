//
//  UIImageView+AXSSDKMobileUI.h
//  AXSSDKMobileUI
//
//  Created by Wilson Lei on 6/12/15.
//  Copyright (c) 2015 AXS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (AXSSDKMobileUI)

- (void)axssdk_loadImageWithURL:(nonnull NSString *)imageURL;
- (void)axssdk_loadImageWithURL:(nonnull NSString *)imageURL placeHolder:(nullable UIImage *)placeHolder;
- (void)axssdk_loadImageWithURL:(nonnull NSString *)imageURL placeHolder:(nullable UIImage *)placeHolder completion:(void(^ _Nullable)(void))completion;

@end
