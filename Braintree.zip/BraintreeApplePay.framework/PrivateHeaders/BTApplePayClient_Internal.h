#import "BTApplePayClient.h"

@interface BTApplePayClient ()
/**
 Exposed for testing to get the instance of BTAPIClient
*/
@property (nonatomic, strong) BTAPIClient *apiClient;

@end
