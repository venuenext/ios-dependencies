/*
* Unless explicitly stated otherwise all files in this repository are licensed under the Apache License Version 2.0.
* This product includes software developed at Datadog (https://www.datadoghq.com/).
* Copyright 2019-2020 Datadog, Inc.
*/

#import <Foundation/Foundation.h>

//! Project version number for DatadogObjc.
FOUNDATION_EXPORT double DatadogObjcVersionNumber;

//! Project version string for DatadogObjc.
FOUNDATION_EXPORT const unsigned char DatadogObjcVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DatadogObjc/PublicHeader.h>


