// Copyright © 2019 VenueNext. All rights reserved.

#import <UIKit/UIKit.h>

//! Project version number for DynamiContent.
FOUNDATION_EXPORT double DynamiContentVersionNumber;

//! Project version string for DynamiContent.
FOUNDATION_EXPORT const unsigned char DynamiContentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamiContent/PublicHeader.h>


