//
//  ResaleSdk.h
//  ResaleSdk
//
//  Created by Harout Grigoryan on 10/9/20.
//

#import <Foundation/Foundation.h>

//! Project version number for ResaleSdk.
FOUNDATION_EXPORT double ResaleSdkVersionNumber;

//! Project version string for ResaleSdk.
FOUNDATION_EXPORT const unsigned char ResaleSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ResaleSdk/PublicHeader.h>


