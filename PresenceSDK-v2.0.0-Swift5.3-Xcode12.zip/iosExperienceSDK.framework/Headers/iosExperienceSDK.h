//
//  iosExperienceSDK.h
//  iosExperienceSDK
//
//  Created by Dharmesh Patel on 11/14/16.
//  Copyright © 2016 Dharmesh Patel. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for iosExperienceSDK.
FOUNDATION_EXPORT double iosExperienceSDKVersionNumber;

//! Project version string for iosExperienceSDK.
FOUNDATION_EXPORT const unsigned char iosExperienceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iosExperienceSDK/PublicHeader.h>

