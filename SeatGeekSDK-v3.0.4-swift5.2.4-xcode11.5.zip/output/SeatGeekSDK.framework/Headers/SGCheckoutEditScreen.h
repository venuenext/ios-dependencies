//
//  SGCheckoutEditScreen.h
//  SeatGeek
//
//  Created by James Van-As on 20/11/14.
//  Copyright (c) 2014 SeatGeek. All rights reserved.
//

#import "SGPaymentControllerProtocol.h"
#import "SGCheckoutBaseScreen.h"
#import "MGBase.h"

#ifndef SEATGEEK_SDK
#import "Constants.h"
#endif

@class SGFadeLoadingView, SGCheckout, SGNavBarButton;

@interface SGCheckoutEditScreen : SGCheckoutBaseScreen <SGPaymentControllerProtocol>

@property (nonatomic, assign) BOOL saveChangesOnBack;
@property (nonatomic, assign) BOOL hasChanged;

- (void)undoChanges;
- (void)saveChangesThenDo:(MGBlock)success fail:(SGAPIFailBlock)fail;
- (void)showLoadingView:(BOOL)show;

@property (nonatomic,strong) SGNavBarButton *backButton;
@property (nonatomic,strong) SGNavBarButton *cancelButton;
@property (nonatomic,strong) SGNavBarButton *doneButton;
@property (nonatomic,strong) SGFadeLoadingView *loadingView;

- (void)tappedBack;
- (void)tappedDone;
- (void)tappedCancel;

@property (nonatomic, copy) MGBlock afterSetRecoupmentMethod;

@end
