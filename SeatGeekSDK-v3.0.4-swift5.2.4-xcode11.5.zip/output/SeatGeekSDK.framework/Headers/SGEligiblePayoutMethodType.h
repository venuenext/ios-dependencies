//
//  SGEligiblePayoutMethodType.h
//  SGAPIPrivate
//
//  Created by Hunter Mask on 3/18/19.
//

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SGPItem.h>
#else
#import <SGAPIPrivate/SGPItem.h>
#endif

#import "SGFunding.h"

@interface SGEligiblePayoutMethodType : SGPItem

@property (nonatomic, strong, nullable) NSString *summary;
@property (nonatomic, strong, nonnull) NSString *displayName;
@property (nonatomic, strong, nullable) NSString *imageURL;
@property (nonatomic) SGFundingType type;

@end
