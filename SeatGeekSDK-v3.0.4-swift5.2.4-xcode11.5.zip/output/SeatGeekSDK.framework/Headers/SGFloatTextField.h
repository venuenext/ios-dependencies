//
//  SGFloatTextField.h
//  SeatGeek
//
//  Created by James Van-As on 9/06/14.
//  Copyright (c) 2014 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SGTextField.h"

@interface SGFloatTextField : SGTextField

// extra label positioning offsets (additional)
@property (nonatomic,assign) CGPoint leftFloatLabelOffset;
@property (nonatomic,assign) CGPoint rightFloatLabelOffset;
@property (nonatomic,strong) UIColor *leftFloatTextColor;
@property (nonatomic,strong) UIColor *rightFloatTextColor;
@property (nonatomic,strong) UIColor *rightHelperTextColor;
@property (nonatomic,strong) UIColor *placeholderTextColor;
@property (nonatomic,strong) UIColor *placeholderTextHighlightColor;
@property (nonatomic,strong) UIColor *placeholderBackgroundColor;
@property (nonatomic,assign) UIEdgeInsets textInsets;

- (void)setLeftFloatText:(NSString *)text;  //this will default to the placeholder text
- (void)setRightFloatText:(NSString *)text;
- (void)setRightHelperText:(NSString *)text;

- (NSString *)leftFloatText;
- (NSString *)rightFloatText;
- (NSString *)rightHelperText;

- (void)setLeftFloatVisible:(BOOL)visible animated:(BOOL)animated;
- (void)setRightFloatVisible:(BOOL)visible animated:(BOOL)animated;
- (void)setRightHelperVisible:(BOOL)visible;

- (void)setText:(NSString *)text animateChange:(BOOL)animate;

// text editing notifications.  You might want to override in a subclass and then call super
- (void)textDidChange:(NSNotification *)notification;
- (void)didStartEditingText:(NSNotification *)notification;
- (void)didFinishEditingText:(NSNotification *)notification;

@end
