//
//  SGFundingSROCredit.h
//  Pods
//
//  Created by Matt Baron on 7/24/18.
//

#import "SGFunding.h"

@interface SGFundingSROCredit : SGFunding

@end
