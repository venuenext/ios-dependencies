//
//  SGPDFViewer.h
//  SeatGeek
//
//  Created by James Van-As on 7/05/15.
//  Copyright (c) 2015 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SGLoadingSpinner, SGTicketGroup;

NS_SWIFT_NAME(PDFViewer)
@interface SGPDFViewer : UIViewController <UIWebViewDelegate, UIScrollViewDelegate>

+ (instancetype _Nonnull)viewerForTicketGroup:(SGTicketGroup * _Nonnull )group;

@property (nonatomic, strong, nonnull) SGTicketGroup *ticketGroup;
@property (nonatomic, strong, nonnull) UIWebView *webView;
@property (nonatomic, strong, nonnull) SGLoadingSpinner *loadingSpinner;
@property (nonatomic, strong, nonnull) UIView *footer;
@property (nonatomic, strong, nonnull) UIButton *closeButton;
@property (nonatomic, strong, nonnull) UIButton *printButton;
@property (nonatomic, assign) BOOL printAfterOpen;
/// If YES, this property will force the screen to brighten.  If NO, the brightness is determined by the event's start time
@property (nonatomic, assign) BOOL brightenScreenOnOpen;

/**
 * Set this property to scroll to a point in the PDF when it opens. For example,
 * to scroll to the 4th page of a 5 page PDF, you'd pass 0.3 (0.0 is the 1st page
 * and 0.4 the last, 5th page).
 */
@property (nonatomic) CGFloat fractionToScrollTo;


@end
