//
//  SGSearchField.h
//  SeatGeek
//
//  Created by Steven Lehrburger on 8/11/17.
//  Copyright © 2017 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SGSearchField : UITextField

@end
