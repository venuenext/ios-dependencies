//
//  SGActionButton.h
//  SeatGeek
//
//  Created by David McNerney on 8/7/15.
//  Copyright (c) 2015 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * A button such that we often have at the bottom of screens for actions,
 * like Transfer Tickets etc. Already has the standard rounded corners and border,
 * allows client code to set border and background colors for different control states,
 * or to select from one of the combinations in the styleguide.
 */

typedef enum {
    SGActionButtonColorStyleNone,
    
    SGActionButtonColorStyleBlue,
    SGActionButtonColorStyleGreen,
    SGActionButtonColorStyleLight,
} SGActionButtonColorStyle;

typedef enum {
    SGActionButtonSizeStyleNone,
    
    SGActionButtonSizeStyleFullwidth,
    SGActionButtonSizeStylePrimary,
    SGActionButtonSizeStyleSecondary
} SGActionButtonSizeStyle;

@interface SGActionButton : UIButton

+ (SGActionButton *)button;

- (void)setColorStyle:(SGActionButtonColorStyle)colorStyle;

/** For now this only changes the button's title font, but warrants a special setter so we can
    1) encourage that only the proper styles get assigned to the button titles, and
    2) lay the foundation for letting the action buttons also manage their own frame
    and insets in the future, perhaps based on their parent view. */
- (void)setSizeStyle:(SGActionButtonSizeStyle)sizeStyle;

/** Also clears the current color style. */
- (void)setBackgroundColor:(UIColor *)color forState:(UIControlState)state;


/** Also clears the current color style.
    If not set for a control state, defaults to the background color. */
- (void)setBorderColor:(UIColor *)color forState:(UIControlState)state;

/** These button titles will be used if there is enough width for the text. */
- (void)setPreferredLongTitle:(NSString *)title forState:(UIControlState)state;

@end
