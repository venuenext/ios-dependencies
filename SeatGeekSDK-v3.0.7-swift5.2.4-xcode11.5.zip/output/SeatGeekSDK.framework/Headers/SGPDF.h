//
//  Created by matt on 14/10/15.
//

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SGItem.h>
#else
#import <SGAPI/SGItem.h>
#endif

@interface SGPDF : SGItem

@property (nullable, nonatomic, strong, readonly) NSData *data;

- (nullable UIImage *)imageWithMaxSize:(CGSize)size;

- (BOOL)canShowOrDownloadPDFData;

@end
