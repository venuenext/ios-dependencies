//
//  SGPaymentControllerProtocol.h
//  SeatGeek
//
//  Created by James Van-As on 13/11/14.
//  Copyright (c) 2014 SeatGeek. All rights reserved.
//

#import "SGAPIError.h"
#import "MGBlockWrapper.h"

@class SGCheckoutPurchase;

@protocol SGPaymentControllerProtocol <NSObject>

@property (nonatomic, strong) SGCheckoutPurchase *purchase;
@property (nonatomic, assign) BOOL saveChangesOnBack;
@property (nonatomic, assign) BOOL hasChanged;

- (void)undoChanges;
- (void)saveChangesThenDo:(MGBlock)success fail:(SGAPIFailBlock)fail;

- (CGFloat)contentHeight;

@end
