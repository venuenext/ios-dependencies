//
//  SGPaymentMethodBillingInfo.h
//  Pods
//
//  Created by Matt Baron on 6/19/18.
//

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SGPItem.h>
#else
#import <SGAPIPrivate/SGPItem.h>
#endif

@class SGPaymentMethodBillingInfoField;

@interface SGPaymentMethodBillingInfo : SGPItem

@property (nonatomic, strong) NSArray <SGPaymentMethodBillingInfoField *> *billingInfoFields;
@property (nonatomic, copy) NSString *country;
@property (nonatomic, copy) NSString *countryLabel;

- (void)fetchBillingInfoForCountry:(NSString *)countryCode
                            thenDo:(MGBlock)success
                            onFail:(SGAPIFailBlock)fail;
@end
