//
//  SGPayoutMethod.h
//  Pods
//
//  Created by James Van-As on 19/10/15.
//
//

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SGPItem.h>
#else
#import <SGAPIPrivate/SGPItem.h>
#endif

#import "SGTrackerEnums.h"
#import "MGBlockWrapper.h"

@class SGPayoutMethodAddress, SGFunding;
@class SGFundingVenmo, SGFundingBank, SGFundingSROCredit;

@interface SGPayoutMethod : SGPItem

@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *firstName;
@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSDate *dateOfBirth;
@property (nonatomic, strong) NSString *localizedDateOfBirthString;
@property (nonatomic, strong) NSString *dateOfBirthString;

@property (nonatomic, strong) SGPayoutMethodAddress *address;
@property (nonatomic, strong) SGFunding *funding;   // api terminology here.  venom / bank account details
@property (nonatomic, strong) SGFunding *previousFunding;   // preivously selected funding, used for undo

@property (nonatomic, strong) SGFundingBank *bankFunding;   // for convenience
@property (nonatomic, strong) SGFundingVenmo *venmoFunding;   // for convenience
@property (nonatomic, strong) SGFundingSROCredit *sroCreditFunding;   // for convenience

@property (nonatomic, strong, readonly) NSString *spreedlyToken;

@property (nonatomic, strong) NSArray *errors;  // list of parameter errors
@property (nonatomic, assign) BOOL hasChanged;

@property (nonatomic) SGTrackerUserPayoutEditType trackerEditType;
@property (nonatomic) SGTrackerUserPayoutMethod trackerMethod;
@property (nonatomic) SGTrackerUserPayoutUIOrigin trackerUIOrigin;

@property (nonatomic, strong) NSString *displayName;
@property (nonatomic, strong) NSString *imageURL;
@property (nonatomic, strong) NSString *summary;

- (void)saveIdentityThenDo:(MGBlock)success onFail:(SGAPIFailBlock)fail;

- (BOOL)isEqualToPayoutMethod:(SGPayoutMethod *)other;

- (BOOL)hasRequiredPersonalInformation;

@end
