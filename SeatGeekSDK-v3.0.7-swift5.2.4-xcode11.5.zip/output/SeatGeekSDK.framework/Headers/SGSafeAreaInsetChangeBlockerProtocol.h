//
//  SGSafeAreaInsetChangeBlockerProtocol.h
//  SeatGeek
//
//  Created by James Van-As on 27/06/18.
//  Copyright © 2018 SeatGeek. All rights reserved.
//

@protocol SGSafeAreaInsetChangeBlocker
@property (nonatomic) BOOL ignoreSafeAreaInsetChanges;
@end

