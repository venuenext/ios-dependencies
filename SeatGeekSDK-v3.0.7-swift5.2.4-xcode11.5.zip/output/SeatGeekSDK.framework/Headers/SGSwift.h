//
//  SGSwift.h
//  SeatGeek
//
//  Created by James Van-As on 17/11/17.
//  Copyright © 2017 SeatGeek. All rights reserved.
//

/*
 Compatibility layer for easier importing of swift headers
 across the different targets
 */

#ifndef SGSwift_h
#define SGSwift_h

#if __has_include("SeatGeek-Swift.h")
#import "SeatGeek-Swift.h"
#endif
#if __has_include("SeatGeekNotificationContentTickets-Swift.h")
#import "SeatGeekNotificationContentTickets-Swift.h"
#endif

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SeatGeekSDK-Swift.h>
#endif

#endif /* SGSwift_h */
