//
//  Created by matt on 17/07/15.
//

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SGItem.h>
#import "SGPerson.h"
#else
#import <SGAPI/SGItem.h>
#import "SGPerson.h"
#endif

@interface SGTransferPerson : SGPerson

@property (nonatomic, copy) NSString *shortFullName;
@property (nonatomic, strong) NSDictionary *images;
@property (nonatomic, copy) NSString *iMessageUUID;
@property (nonatomic, copy) NSData *imageData;
@property (nonatomic, assign) BOOL isLocalContact;

- (NSString *)identifyingString;    // Display string that favours username over full name

- (BOOL)isSeatGeekUser;

@end
