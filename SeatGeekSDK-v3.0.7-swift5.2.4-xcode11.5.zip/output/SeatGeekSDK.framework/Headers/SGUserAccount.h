//
//  Created by matt on 9/04/14.
//

#import "SGAPIError.h"

typedef void (^SGKeychainCompletion)(NSString *username, NSString *password);

@class SGUserLoginState;

@interface SGUserAccount : NSObject

#pragma mark - Logging In / Out
+ (void)resumeSession;
+ (void)loginWithUsername:(NSString *)username password:(NSString *)password;
+ (void)loginWithTwoFAVerification:(NSString *)code;
+ (void)resendTwoFAVerificationSuccess:(MGBlock)success fail:(SGAPIFailBlock)fail;
+ (void)disableTwoFAWithBackup:(NSString *)code success:(MGBlock)success fail:(SGAPIFailBlock)fail;
+ (void)loginViaFacebook;  // in most cases, we want to use new permissions, so default to this
+ (void)loginWithFacebookWithNewPermissions:(BOOL)useNewPermissions;
+ (void)logout;

+ (void)loginAfterTokenExchangeWithAccessToken:(NSString *)accessToken;

#pragma mark - Safari Keychain
+ (void)getSafariKeychainCredentialsThenDo:(SGKeychainCompletion)completion;
+ (void)saveCredentialsToSafariKeychainWithUserName:(NSString *)username
                                           password:(NSString *)password;

/**
 Evaluates whether or not we should manually prompt a user to save their credentials to iCloud keychain.
 There are certain scenarios where we shouldn't do this, such as when the system does it automatically
 or when one or both of the credentials is blank or nil.

 @param username The username used
 @param password The password used
 @return YES if we should manually prompt a user to save their credentials to iCloud keychain.
 */
+ (BOOL)shouldPromptToSaveCredentialsToKeychainWithUserName:(NSString *)username
                                                   password:(NSString *)password;

#pragma mark - Signing Up
+ (void)signupWithEmail:(NSString *)email password:(NSString *)password firstName:(NSString *)firstName lastName:(NSString *)lastName accessToken:(NSString *)token;

#pragma mark - Password Reset
+ (void)sendPasswordResetRequestFor:(NSString *)email onSuccessDo:(void (^)(void))success
                           onFailDo:(void (^)(void))fail;

#pragma mark - Login States
+ (BOOL)loggedIn;
+ (BOOL)loggingIn;
+ (BOOL)isWaitingToRestoreSession;
+ (BOOL)sessionExists;
+ (SGUserLoginState *)loginState;
+ (void)setLoginState:(SGUserLoginState *)state;

#pragma mark - Session type

/**
 * true if user logged in via FB, false if not. Note that currently, this
 * method will return true after a failed FB login attempt, even though not
 * logged in at all.
 */
+ (BOOL)isFacebookSession;

@end
