//
//  Created by matt on 9/04/14.
//

#define SGUserEventsFetchingStarted     @"SGUserEventsFetchingStarted"
#define SGUserEventsFetchingFinished    @"SGUserEventsFetchingFinished"
#define SGUserEventsFetchingFailed      @"SGUserEventsFetchingFailed"
#define SGUserEventsLoaded       @"SGUserEventsLoaded"
#define SGUserEventsChanged      @"SGUserEventsChanged"
#define SGUserPerformersFetchingStarted     @"SGUserPerformersFetchingStarted"
#define SGUserPerformersFetchingFinished    @"SGUserPerformersFetchingFinished"
#define SGUserPerformersFetchingFailed      @"SGUserPerformersFetchingFailed"
#define SGUserPerformersLoaded   @"SGUserPerformersLoaded"
#define SGUserPerformersChanged  @"SGUserPerformersChanged"
#define SGUserVenuesFetchingStarted     @"SGUserVenuesFetchingStarted"
#define SGUserVenuesFetchingFinished    @"SGUserVenuesFetchingFinished"
#define SGUserVenuesFetchingFailed      @"SGUserVenuesFetchingFailed"
#define SGUserVenuesLoaded       @"SGUserVenuesLoaded"
#define SGUserVenuesChanged      @"SGUserVenuesChanged"

#import "SGItemPrivate.h"
#import "SGTrackerEnums.h"

@class SGUser, SGEvent, SGPerformer, SGVenue, SGItem, SGPListMetadataItem;

@interface SGUserTracking : NSObject

@property (nonatomic, strong) NSMutableOrderedSet <SGPerformer *> *trackedPerformers;
@property (nonatomic, strong) NSMutableOrderedSet <SGEvent *> *trackedEvents;
@property (nonatomic, strong) NSMutableOrderedSet <SGVenue *> *trackedVenues;

+ (instancetype)tracker;

- (void)fetchTrackedEvents;
- (void)fetchTrackedPerformers;
- (void)fetchTrackedVenues;

- (BOOL)fetchingEvents;
- (BOOL)fetchingPerformers;
- (BOOL)fetchingVenues;

- (BOOL)isTrackingEvent:(SGEvent *)event;
- (BOOL)isTrackingEventWithID:(NSString *)eventID;

- (BOOL)isTrackingPerformer:(SGPerformer *)performer;
- (BOOL)isTrackingPerformerWithID:(NSString *)performerID;

- (BOOL)isTrackingVenue:(SGVenue *)venue;
- (BOOL)isTrackingVenueWithID:(NSString *)venueID;

- (BOOL)isTrackingItem:(SGItem *)item;

- (void)trackEvent:(SGEvent *)event uiOrigin:(SGTrackerUserEventUIOrigin)uiOrigin;
- (void)trackEventWithID:(NSString *)eventID uiOrigin:(SGTrackerUserEventUIOrigin)uiOrigin;

- (void)trackPerformer:(SGPerformer *)performer uiOrigin:(SGTrackerUserPerformerUIOrigin)uiOrigin;
- (void)trackPerformerWithID:(NSString *)performerID uiOrigin:(SGTrackerUserPerformerUIOrigin)uiOrigin;

- (void)trackVenue:(SGVenue *)venue uiOrigin:(SGTrackerUserVenueUIOrigin)uiOrigin;
- (void)trackVenueWithID:(NSString *)venueID uiOrigin:(SGTrackerUserVenueUIOrigin)uiOrigin;

- (void)untrackEvent:(SGEvent *)event uiOrigin:(SGTrackerUserEventUIOrigin)uiOrigin;
- (void)untrackEventWithID:(NSString *)eventID uiOrigin:(SGTrackerUserEventUIOrigin)uiOrigin;
- (void)untrackPerformer:(SGPerformer *)performer uiOrigin:(SGTrackerUserPerformerUIOrigin)uiOrigin;
- (void)untrackPerformerWithID:(NSString *)performerID uiOrigin:(SGTrackerUserPerformerUIOrigin)uiOrigin;
- (void)untrackVenue:(SGVenue *)venue uiOrigin:(SGTrackerUserVenueUIOrigin)uiOrigin;
- (void)untrackVenueWithID:(NSString *)venueID uiOrigin:(SGTrackerUserVenueUIOrigin)uiOrigin;

// TODO figure out how to use the interaction method enum for SGTracker instead of the BOOL
// even though we are in a Shared pod that needs to be compiled for targets that don't
// have the tracker-ios pod.
//
// Update: same for the browseListMetadata, which is for the ui_origin and other metadata.
// After this initial migration is done, we can design a better and more universal pattern
// for collecting the metadata upstream of the actual SGTracker call. - @lehrblogger
//
// Another update: same for isFromEventView. We want data about event view usage ASAP for
// the event page redesign, but the ugliness of this code shows the urgency of making time
// to implement a better approach... - @lehrblogger
- (void)trackEvent:(SGEvent *)event
        isFromPeek:(BOOL)isFromPeek
      listMetadata:(SGPListMetadataItem *)listMetadata
          uiOrigin:(SGTrackerUserEventUIOrigin)uiOrigin;

- (void)trackPerformer:(SGPerformer *)performer
            isFromPeek:(BOOL)isFromPeek
          listMetadata:(SGPListMetadataItem *)listMetadata
              uiOrigin:(SGTrackerUserPerformerUIOrigin)uiOrigin;

- (void)trackVenue:(SGVenue *)venue
        isFromPeek:(BOOL)isFromPeek
      listMetadata:(SGPListMetadataItem *)listMetadata
          uiOrigin:(SGTrackerUserVenueUIOrigin)uiOrigin;

- (void)untrackEvent:(SGEvent *)event isFromPeek:(BOOL)isFromPeek
        listMetadata:(SGPListMetadataItem *)listMetadata
            uiOrigin:(SGTrackerUserEventUIOrigin)uiOrigin;

- (void)untrackPerformer:(SGPerformer *)performer
              isFromPeek:(BOOL)isFromPeek
            listMetadata:(SGPListMetadataItem *)listMetadata
                uiOrigin:(SGTrackerUserPerformerUIOrigin)uiOrigin;

- (void)untrackVenue:(SGVenue *)venue
          isFromPeek:(BOOL)isFromPeek
        listMetadata:(SGPListMetadataItem *)listMetadata
            uiOrigin:(SGTrackerUserVenueUIOrigin)uiOrigin;

- (void)trackItem:(SGItem *)item
       isFromPeek:(BOOL)isFromPeek
     listMetadata:(SGPListMetadataItem *)listMetadata
         uiOrigin:(int)uiOrigin;

- (void)untrackItem:(SGItem *)item
         isFromPeek:(BOOL)isFromPeek
       listMetadata:(SGPListMetadataItem *)listMetadata
           uiOrigin:(int)uiOrigin;

@end
