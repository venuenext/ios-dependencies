//
//  UIColor+Hex.h
//  Pods
//
//  Created by James Van-As on 20/04/15.
//
//

#import <UIKit/UIKit.h>

@interface UIColor (Hex)

+ (UIColor *)colorWithHex:(unsigned int)hex;
+ (UIColor *)colorWithHex:(unsigned int)hex alpha:(CGFloat)alpha;
+ (UIColor *)colorWithInterpolationFrom:(UIColor *)startColor
                                     to:(UIColor *)endColor
                                      t:(float)t;
+ (NSInteger)hexFromColor:(UIColor *)color;

@end
