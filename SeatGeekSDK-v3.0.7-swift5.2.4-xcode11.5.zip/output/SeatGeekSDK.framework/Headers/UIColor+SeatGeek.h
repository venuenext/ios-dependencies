//
//  UIColor+SeatGeek.h
//  SeatGeek
//
//  Created by Eric Waller on 10/4/12.
//  Copyright (c) 2012 Devin7 Software. All rights reserved.
//

#import "UIColor+Hex.h"

typedef enum {
    SGListingColorDeepGreen = 0,
    SGListingColorGreen = 1,
    SGListingColorGreenYellow = 2,
    SGListingColorYellow = 3,
    SGListingColorOrange = 4,
    SGListingColorOrangeRed = 5,
    SGListingColorRed = 6,
    SGListingColorBlue = 7
} SGListingColor;

@interface UIColor (SeatGeek)

NS_ASSUME_NONNULL_BEGIN

// Named

@property(class, nonatomic, readonly) UIColor *primary;
@property(class, nonatomic, readonly) UIColor *confirm;
@property(class, nonatomic, readonly) UIColor *warning;
@property(class, nonatomic, readonly) UIColor *error;
@property(class, nonatomic, readonly) UIColor *textLight;
@property(class, nonatomic, readonly) UIColor *textMedium;
@property(class, nonatomic, readonly) UIColor *textDark;
@property(class, nonatomic, readonly) UIColor *textTertiary;
@property(class, nonatomic, readonly) UIColor *textTertiarySelected;
@property(class, nonatomic, readonly) UIColor *background;
@property(class, nonatomic, readonly) UIColor *keyline;
@property(class, nonatomic, readonly) UIColor *highlight;
@property(class, nonatomic, readonly) UIColor *listingPackage;
@property(class, nonatomic, readonly) UIColor *dailyTapDarkBlue;
@property(class, nonatomic, readonly) UIColor *unselectedSeat;
@property(class, nonatomic, readonly) UIColor *spotifyGreen;
@property(class, nonatomic, readonly) UIColor *spotifyDOEGradientTop;
@property(class, nonatomic, readonly) UIColor *spotifyDOEGradientBottom;
@property(class, nonatomic, readonly) UIColor *trendingItemPositiveGreen;
@property(class, nonatomic, readonly) UIColor *actionIndicator;

// Greys

@property(class, nonatomic, readonly) UIColor *sg_extraLightGrey;
@property(class, nonatomic, readonly) UIColor *sg_lighterGrey;
@property(class, nonatomic, readonly) UIColor *sg_lightGrey;
@property(class, nonatomic, readonly) UIColor *sg_grey;
@property(class, nonatomic, readonly) UIColor *sg_darkGrey;
@property(class, nonatomic, readonly) UIColor *sg_black;
@property(class, nonatomic, readonly) UIColor *sg_gradientBlack;

// Reds

@property(class, nonatomic, readonly) UIColor *sg_lightRed;
@property(class, nonatomic, readonly) UIColor *sg_red;
@property(class, nonatomic, readonly) UIColor *sg_darkRed;

// Oranges

@property(class, nonatomic, readonly) UIColor *sg_lightOrange;
@property(class, nonatomic, readonly) UIColor *sg_orange;
@property(class, nonatomic, readonly) UIColor *sg_darkOrange;

// Yellows

@property(class, nonatomic, readonly) UIColor *sg_lightYellow;
@property(class, nonatomic, readonly) UIColor *sg_yellow;
@property(class, nonatomic, readonly) UIColor *sg_darkYellow;

// Greens

@property(class, nonatomic, readonly) UIColor *sg_lightGreen;
@property(class, nonatomic, readonly) UIColor *sg_green;
@property(class, nonatomic, readonly) UIColor *sg_darkGreen;

// Limes

@property(class, nonatomic, readonly) UIColor *sg_lightLime;
@property(class, nonatomic, readonly) UIColor *sg_lime;
@property(class, nonatomic, readonly) UIColor *sg_darkLime;

// Blues

@property(class, nonatomic, readonly) UIColor *sg_lightBlue;
@property(class, nonatomic, readonly) UIColor *sg_blue;
@property(class, nonatomic, readonly) UIColor *sg_darkBlue;

// Purples

@property(class, nonatomic, readonly) UIColor *sg_lightPurple;
@property(class, nonatomic, readonly) UIColor *sg_purple;
@property(class, nonatomic, readonly) UIColor *sg_darkPurple;

// Pinks

@property(class, nonatomic, readonly) UIColor *sg_lightPink;
@property(class, nonatomic, readonly) UIColor *sg_pink;
@property(class, nonatomic, readonly) UIColor *sg_darkPink;



// Everything Below This is LEGACY and their usage should be deprecated

// Backgrounds, text, and borders
@property(class, nonatomic, readonly) UIColor *sg_background1;
@property(class, nonatomic, readonly) UIColor *sg_background2;
@property(class, nonatomic, readonly) UIColor *sg_background3;
@property(class, nonatomic, readonly) UIColor *sg_background4;

@property(class, nonatomic, readonly) UIColor *sg_border1;
@property(class, nonatomic, readonly) UIColor *sg_border2;
@property(class, nonatomic, readonly) UIColor *sg_separator;

// Table View
@property(class, nonatomic, readonly) UIColor *sg_tableViewCellSelected;

/// placeholder image for loading / missing states of artwork
@property(class, nonatomic, readonly) UIColor *sg_imagePlaceholder;

@property(class, nonatomic, readonly) UIColor *sg_text1;
@property(class, nonatomic, readonly) UIColor *sg_text2;
@property(class, nonatomic, readonly) UIColor *sg_text3;
@property(class, nonatomic, readonly) UIColor *sg_text4;

@property(class, nonatomic, readonly) UIColor *sg_subheader;

// Brand colors
@property(class, nonatomic, readonly) UIColor *sg_blue1;
@property(class, nonatomic, readonly) UIColor *sg_blue2;
@property(class, nonatomic, readonly) UIColor *sg_blue3;
@property(class, nonatomic, readonly) UIColor *sg_blue4;
@property(class, nonatomic, readonly) UIColor *sg_blue5;
@property(class, nonatomic, readonly) UIColor *sg_blue6;
@property(class, nonatomic, readonly) UIColor *sg_blue7;
@property(class, nonatomic, readonly) UIColor *sg_blue8;
@property(class, nonatomic, readonly) UIColor *sg_green1;
@property(class, nonatomic, readonly) UIColor *sg_green2;
@property(class, nonatomic, readonly) UIColor *sg_green3;
@property(class, nonatomic, readonly) UIColor *sg_orange1;
@property(class, nonatomic, readonly) UIColor *sg_orange2;
@property(class, nonatomic, readonly) UIColor *sg_yellow1;
@property(class, nonatomic, readonly) UIColor *sg_yellow2;
@property(class, nonatomic, readonly) UIColor *sg_yellow3;
@property(class, nonatomic, readonly) UIColor *sg_red1;
@property(class, nonatomic, readonly) UIColor *sg_red2;
@property(class, nonatomic, readonly) UIColor *sg_gray1;
@property(class, nonatomic, readonly) UIColor *sg_gray2;
@property(class, nonatomic, readonly) UIColor *sg_gray3;
@property(class, nonatomic, readonly) UIColor *sg_gray4;
@property(class, nonatomic, readonly) UIColor *sg_gray5;
@property(class, nonatomic, readonly) UIColor *sg_gray6;
@property(class, nonatomic, readonly) UIColor *sg_gray7;
@property(class, nonatomic, readonly) UIColor *sg_gray8;
@property(class, nonatomic, readonly) UIColor *sg_gray9;
@property(class, nonatomic, readonly) UIColor *sg_gray10;
@property(class, nonatomic, readonly) UIColor *sg_secondaryNavyLight24;

// Named Colors
@property(class, nonatomic, readonly) UIColor *sg_navy;
@property(class, nonatomic, readonly) UIColor *sg_navyDark;
@property(class, nonatomic, readonly) UIColor *sg_highlightBlue;

@property(class, nonatomic, readonly) UIColor *sg_gray;
@property(class, nonatomic, readonly) UIColor *sg_darkGray;

// Wrapper methods to for the sake of centralization and clarity
@property(class, nonatomic, readonly) UIColor *sg_white;
@property(class, nonatomic, readonly) UIColor *sg_clear;
@property(class, nonatomic, readonly) UIColor *sg_shadow;
@property(class, nonatomic, readonly) UIColor *sg_todayWidget1;
@property(class, nonatomic, readonly) UIColor *sg_todayWidget2;
@property(class, nonatomic, readonly) UIColor *sg_todayWidget3;

// Navbar
@property(class, nonatomic, readonly) UIColor *navBarButtonBGOnTransparentBar;
@property(class, nonatomic, readonly) UIColor *navBarButtonTintOnTransparentBar;
@property(class, nonatomic, readonly) UIColor *navBarButtonTintOnSolidBar;
@property(class, nonatomic, readonly) UIColor *navBarBGSolid;
@property(class, nonatomic, readonly) UIColor *navBarBGTransparent;
@property(class, nonatomic, readonly) UIColor *navBarTitleOnSolidBar;
@property(class, nonatomic, readonly) UIColor *navBarSubtitleOnSolidBar;

// Tabbar
@property(class, nonatomic, readonly) UIColor *sg_tabBarNormal;
@property(class, nonatomic, readonly) UIColor *sg_tabBarSelected;

// Miscellaneous other colors
@property(class, nonatomic, readonly) UIColor *sg_blue1TransparentButtonBackground;
@property(class, nonatomic, readonly) UIColor *sg_lyft;
@property(class, nonatomic, readonly) UIColor *sg_keyboardAccessoryDividerLine;
@property(class, nonatomic, readonly) UIColor *sg_keyboardAccessoryTop1;
@property(class, nonatomic, readonly) UIColor *sg_keyboardAccessoryTop2;
@property(class, nonatomic, readonly) UIColor *sg_keyboardAccessoryBottom1;
@property(class, nonatomic, readonly) UIColor *sg_keyboardAccessoryBottom2;
@property(class, nonatomic, readonly) UIColor *sg_randomColor;
+ (UIColor *)missingArtworkColorForSeed:(NSString *)seed;
@property(class, nonatomic, readonly) UIColor *sg_tooltip;
@property (class, nonatomic, readonly) UIColor *sg_eventListBackgroundColor;

// Used for deal score and pins
+ (UIColor *)sg_listingColorForBucket:(SGListingColor)bucket;
+ (UIColor *)sg_pinColorForBucket:(SGListingColor)bucket;
+ (UIColor *)sg_mapGray;

NS_ASSUME_NONNULL_END

- (nullable UIColor *)darkerColor;

/// Returns a color interpolated towards end color with amount t [0,1]
- (nonnull UIColor *)interpolateTo:(nonnull UIColor *)endColor t:(float)t;

/// Returns a solid color from overlaying another color on top with an alpha using standard source over blending
- (nonnull UIColor *)withOverlay:(nonnull UIColor *)overlayColor alpha:(CGFloat)a;

- (BOOL)isLegibleAgainstColor:(nonnull UIColor *)color;

@end
