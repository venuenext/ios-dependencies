//
//  UIScrollView+SeatGeek.h
//  SeatGeek
//
//  Created by James Van-As on 1/08/13.
//  Copyright (c) 2013 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (SeatGeek)

- (void)scrollToTopAnimated:(BOOL)animated;
- (void)scrollToBottomAnimated:(BOOL)animated;
- (CGFloat)heightWithoutInsets;
@property (readonly) BOOL isScrolledToTop;
@property (readonly) BOOL isScrolledToBottom;
- (CGFloat)distanceFromBottom;
/// the y component of contentOffset if the scrollview was to be scrolled to the bottom
@property (readonly) CGFloat bottomScrollYOffset;

/// True if scrolling is required to view all content.
@property (readonly) BOOL canScroll;

@end
