//
//  UIView+SeatGeek.h
//  SeatGeek
//
//  Created by James Van-As on 1/08/13.
//  Copyright (c) 2013 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (SeatGeek)

+ (UIView*) notFoundViewWithFrame:(CGRect)frame text:(NSString*)text;
- (void)addSubviewToBack:(UIView*)view;
- (void)roundOffFrame;

- (UIView *)sg_superviewOfClass:(Class)class;

@end
