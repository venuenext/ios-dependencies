//
//  SGAPIValidatorDateOfBirth.h
//  Pods
//
//  Created by James Van-As on 22/10/15.
//
//

#import "SGAPIValidator.h"

@interface SGAPIValidatorDateOfBirth : SGAPIValidator

@end
