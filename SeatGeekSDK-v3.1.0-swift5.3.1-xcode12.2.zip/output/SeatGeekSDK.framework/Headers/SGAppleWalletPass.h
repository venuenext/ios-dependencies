//
//  SGAppleWallet.h
//  Adjust
//
//  Created by Matt Baron on 10/16/17.
//

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SGItem.h>
#else
#import <SGAPI/SGItem.h>
#endif
#import <PassKit/PassKit.h>

@interface SGAppleWalletPass : SGItem

@property (nullable, nonatomic, readonly, strong) PKPass *pkPass;
@property (nullable, nonatomic, readonly, strong) NSData *data;

@end
