//
//  Created by matt on 1/12/14.
//

#import "MGLine.h"
#import <MessageUI/MessageUI.h>
#import "SGNavigatorChildController.h"

@class SGCheckoutPurchase;

@interface SGCheckoutBaseScreen : SGNavigatorChildController <MFMailComposeViewControllerDelegate> {
    UIView *_footer;
}

@property (nonatomic, strong) SGCheckoutPurchase *purchase;
@property (nonatomic, strong) UIView *footer;

@end
