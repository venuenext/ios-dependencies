//
//  Created by matt on 16/01/15.
//

#import <Foundation/Foundation.h>
#import "SGPurchase.h"
#import "SGAPIError.h"

#define SGCheckoutPurchaseSummaryFetchStarted       @"SGCheckoutPurchaseSummaryFetchStarted"
#define SGCheckoutPurchaseSummaryFetchFinished      @"SGCheckoutPurchaseSummaryFetchFinished"
#define SGCheckoutPurchaseSummaryFetchFailed        @"SGCheckoutPurchaseSummaryFetchFailed"
#define SGCheckoutPurchaseUserSecurityCheckRequired @"SGCheckoutPurchaseUserSecurityCheckRequired"
#define SGCheckoutPurchaseSucceeded                 @"SGCheckoutPurchaseSucceeded"
#define SGVibrateSummaryErrors @"SGVibrateSummaryErrors"
#define SGOpenedWebCheckout @"SGOpenedWebCheckout"

@class SGUser, SGUserShippingAddress, SGUserPaymentMethod, SGPurchaseDeliveryMethod, SGListing, SGPromoCode, SGAccessCode, SGCartLevelCoupon, SGAcknowledgement, SGKReturnPolicy;
@class SGSeatOption;

@interface SGCheckoutPurchase : SGPurchase

+ (instancetype)purchaseForListing:(SGListing *)listing;

@property (nonatomic, copy) NSString *transactionId;

// from server
@property (nonatomic, strong) NSArray *availableSplits;
@property (nonatomic, strong) NSArray <SGSeatOption *> *availableSeats;
@property (nonatomic, strong) SGSeatOption *selectedSeat;
@property (nonatomic, strong) NSArray <NSDictionary *> *selectedAddOns;
@property (nonatomic, strong) SGKReturnPolicy *returnPolicy;

/// optional array of dictionaries that we just bounce back to the server
@property (nonatomic, strong) NSArray *bundleItems;
@property (nonatomic, strong) NSArray *availableDeliveryMethods;
@property (nonatomic, strong) NSArray *priceTypes;
@property (nonatomic, readonly) BOOL hasPriceTypes;
@property (nonatomic, strong) NSString *ineligibleListingMessage;
@property (nonatomic) BOOL showSwapsExperience;
@property (nonatomic, strong) NSArray <SGPromoCode *> *availablePromoCodes;
@property (nonatomic, strong) NSArray <SGAcknowledgement *> *acknowledgements;
@property (nonatomic, assign) BOOL promoCodeEligible;
@property (nonatomic, assign) BOOL requiresPaymentMethod;
@property (nonatomic, strong) SGPromoCode *promoCode;
@property (nonatomic, strong) SGAccessCode *accessCode;
@property (nonatomic, strong) SGCartLevelCoupon *cartLevelCoupon;
@property (nonatomic, copy) NSString *accessToken;
@property (nonatomic, strong) NSArray <SGAPIError *> *errors;
@property (nonatomic, assign) BOOL priceTypesNeedReselection;
@property (nonatomic, assign, readonly) BOOL shouldLaunchTransfers;

@property (nonatomic, assign) BOOL cvvRecacheNeeded;
- (BOOL)allowSeatSelection;

// from client
@property (nonatomic, strong) SGUser *user;
@property (nonatomic, strong, readonly) SGListing *listing;
- (NSString *)combinedNotes;

// from client and server
@property (nonatomic, strong) NSMutableDictionary *marketSpecificFields;

// getting chatty with the server
- (void)hitClickTrackerThenDo:(MGBlock)success onFail:(SGAPIFailBlock)fail;
- (void)fetchSummaryThenDo:(MGBlock)success onFail:(SGAPIFailBlock)fail;
- (void)submitThenDo:(MGBlock)success onFail:(SGAPIFailBlock)fail;

// request states
- (BOOL)fetchingClickID;
- (BOOL)fetchingSummary;
- (BOOL)hasSummary;
- (BOOL)submitting;
- (BOOL)submitSucceeded;
- (BOOL)failedPermanently;

- (NSString *)displayStringForQuantity;
- (NSString *)displayStringForQuantityNoE;

- (BOOL)allowDeliveryMethodSelect;

/// Flag remotely operated by the server which dictates whether we show any promo code UI or not
@property (nonatomic, readonly) BOOL showPromoCodeUI;

@property (nonatomic,readonly) BOOL canApplePay;
/// Doesn't guarantee that apple pay is being used, but that apple pay is the option currently presented to the user
@property (nonatomic,assign) BOOL applePaySelected;
/// true if the user had the choice of using apple pay, but explicitly changed to a credit card
@property (nonatomic,assign) BOOL userDoesntWantApplePay;
- (BOOL)isApplePay;

- (BOOL)useSandbox;

- (NSArray *)errorsForCategory:(NSString *)errorCategory;
- (NSArray *)localValidationErrors; // note this actually performs local validation
- (NSArray *)localValidationErrorsForCategory:(NSString *)errorCategory;  // note this actually performs local validation
- (BOOL)hasFatalErrors;
- (BOOL)hasGeneralErrors;
- (BOOL)hasErrors;
- (BOOL)hasNonPaymentRelatedErrors;

/// returns true if the errors array contains the "account exists / login required error".
@property (nonatomic, readonly) BOOL loginRequired;

// Cart mode
- (void)abandonCart;

// GA logging
- (NSDictionary *)logFields;
- (void)logCheckoutBegan;
- (void)logCheckoutAttempt;
- (void)logPurchaseAttempt;
- (void)logCheckoutSuccess;

@end
