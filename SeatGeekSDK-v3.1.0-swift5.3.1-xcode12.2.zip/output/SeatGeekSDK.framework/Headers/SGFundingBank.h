//
//  SGFundingBank.h
//  Pods
//
//  Created by James Van-As on 19/10/15.
//
//

#import "SGFunding.h"

@interface SGFundingBank : SGFunding
@property (nonatomic, strong) NSString *accountNumber;
@property (nonatomic, strong) NSString *routingNumber;
@property (nonatomic, strong) NSString *accountNumberLast4Digits;
@end
