//
//  SGPaymentMethodSelect.h
//  SeatGeek
//
//  Created by James Van-As on 3/02/15.
//  Copyright (c) 2015 SeatGeek. All rights reserved.
//

#import "SGPaymentControllerProtocol.h"
#import "SGCheckoutEditScreen.h"

@class SGTransfer;

@interface SGPaymentMethodSelect : SGCheckoutEditScreen <SGPaymentControllerProtocol>

+ (instancetype)paymentSelectForRecoupment;
+ (instancetype)controllerWithTransfer:(SGTransfer *)transfer;

@property (nonatomic, assign) BOOL allowSelectApplePay;

@end
