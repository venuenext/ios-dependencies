//
//  Created by matt on 20/01/15.
//

#ifdef SEATGEEK_SDK
#import <SeatGeekSDK/SGPaymentMethod.h>
#else
#import <SGAPIPrivate/SGPaymentMethod.h>
#endif

#define SGUpdatePaymentMethodsWithDict  @"SGUpdatePaymentMethodsWithDict"
#define SGDeletePaymentMethod           @"SGDeletePaymentMethod"
#define SGRefreshCreditCardFields       @"SGRefreshCreditCardFields"

@interface SGPaymentMethodSpreedly : SGPaymentMethod
      <NSCopying>

@property (nonatomic, copy) NSString *storageState;
@property (nonatomic, assign) BOOL cvvRecacheNeeded;
@property (nonatomic, assign) BOOL eligibleForRecoupment;

- (void)deleteFromServerOnFail:(SGAPIFailBlock)fail;
- (void)setIsDefault:(BOOL)isDefault tellServer:(BOOL)tellServer;
- (void)setIsEligibleRecoupmentMethodThenDo:(void(^)(NSDictionary *responseJSON))success
                                    failure:(void(^)(void))failure;

- (BOOL)needToSendToSpreedly;
- (void)sendToSpreedlyThenDo:(void(^)(void))success onFail:(SGAPIFailBlock)fail;
- (void)recacheCVVThenDo:(void(^)(void))success onFail:(SGAPIFailBlock)fail wasUI:(BOOL)wasUI;

@end
