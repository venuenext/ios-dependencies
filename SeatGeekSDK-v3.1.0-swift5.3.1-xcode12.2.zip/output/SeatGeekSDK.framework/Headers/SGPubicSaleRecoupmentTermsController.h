//
//  SGPubicSaleRecoupmentTermsController.h
//  SeatGeek
//
//  Created by Steven Lehrburger on 3/8/17.
//  Copyright © 2017 SeatGeek. All rights reserved.
//

#import "SGCheckoutEditScreen.h"

@interface SGPubicSaleRecoupmentTermsController : SGCheckoutEditScreen

@end
