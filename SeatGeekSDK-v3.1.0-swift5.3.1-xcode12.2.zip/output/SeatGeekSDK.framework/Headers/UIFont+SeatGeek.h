//
//  UIFont+SeatGeek.h
//  SeatGeek
//
//  Created by Steven Lehrburger on 01/12/16.
//  Copyright (c) 2016 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * Fonts are documented in this Google Doc's "iOS Font Library" tab:
 *      https://docs.google.com/spreadsheets/d/1t-cNqyBG_sqr0FecRoLvC77jamXqNITrUkppS_jwZss/edit#gid=714641015
 */
@interface UIFont (SeatGeek)

#pragma mark - "Snow Blanket" redesign fonts

/// Gilroy-SemiBold 17
@property(class, nonatomic, readonly) UIFont *sb_headline;

/// Gilroy-SemiBold 16
@property(class, nonatomic, readonly) UIFont *sb_headline2;

/// Gilroy-Bold 17
@property(class, nonatomic, readonly) UIFont *sb_navTitle1;

/// Gilroy-SemiBold 16
@property(class, nonatomic, readonly) UIFont *sb_navTitle2;

/// SFUIText-Regular 14
@property(class, nonatomic, readonly) UIFont *sb_body1;

/// SFUIText-Regular 13
@property(class, nonatomic, readonly) UIFont *sb_body2;

/// SFUIText-Regular 12
@property(class, nonatomic, readonly) UIFont *sb_body3;

/// SFUIText-Regular 12
@property(class, nonatomic, readonly) UIFont *sb_body4;

/// SF-Semibold 17
@property(class, nonatomic, readonly) UIFont *sb_button1;

/// SF-Semibold 15
@property(class, nonatomic, readonly) UIFont *sb_button2;

/// SF-Bold 13
@property(class, nonatomic, readonly) UIFont *sb_button3;

/// SF-Medium 14
@property(class, nonatomic, readonly) UIFont *sb_button4;

/// Gilroy-ExtraBold 30
@property(class, nonatomic, readonly) UIFont *sb_display1;

/// Gilroy-Bold 24
@property(class, nonatomic, readonly) UIFont *sb_display2;

/// Gilroy-Bold 20
@property(class, nonatomic, readonly) UIFont *sb_display3;

/// SFUIText-Regular 18
//TODO this has been removed from the type guide – how do we remove it?
@property(class, nonatomic, readonly) UIFont *sb_subdisplay;

/// Gilroy-Bold 19
@property(class, nonatomic, readonly) UIFont *sb_subdisplay1;

/// Gilroy-SemiBold 18
@property(class, nonatomic, readonly) UIFont *sb_subdisplay2;


/// SFUIText-Regular 15
@property(class, nonatomic, readonly) UIFont *sb_link;

/// SFUIText-Medium 15
@property(class, nonatomic, readonly) UIFont *sb_label;

/// SFUIText-Medium 15
@property(class, nonatomic, readonly) UIFont *sb_selected1;

/// SFUIText-Medium 14
@property(class, nonatomic, readonly) UIFont *sb_selected2;

/// SFUIText-Semibold 12
@property(class, nonatomic, readonly) UIFont *sb_selected4;

/// SFUIText-Regular 16
@property(class, nonatomic, readonly) UIFont *sb_title;

/// SFUIText-Medium 15
@property(class, nonatomic, readonly) UIFont *sb_title2;

/// SFUIText-Regular 15
@property(class, nonatomic, readonly) UIFont *sb_title3;

/// SFUIText-Medium 16
@property(class, nonatomic, readonly) UIFont *sb_boldTitle1;

/// SFUIText-Medium 15
@property(class, nonatomic, readonly) UIFont *sb_boldTitle2;

// sb_body4
@property(class, nonatomic, readonly)  UIFont *sb_floatLabel;

/// SFUIText-SemiBold 11
@property(class, nonatomic, readonly)  UIFont *sb_subheader;

/// SF-Semibold 15
@property(class, nonatomic, readonly) UIFont *sb_mapTooltip;

/// SF-Medium 9
@property(class, nonatomic, readonly) UIFont *sb_tabBarNormal;

/// SF-Semibold 9
@property(class, nonatomic, readonly) UIFont *sb_tabBarSelected;

/// SF-Semibold 15
@property(class, nonatomic, readonly) UIFont *sb_dealScore;

/// SF-Bold 12
@property(class, nonatomic, readonly) UIFont *sb_browseCategoryName;

/// SF-Medium 12
@property(class, nonatomic, readonly) UIFont *sb_browseOuterPriceLabel;

/// SF-Medium 13
@property(class, nonatomic, readonly) UIFont *sb_pillTitle;

#pragma mark - Feature Fonts

/// Effra-Light 34
@property(class, nonatomic, readonly) UIFont *sg_feature1;

#pragma mark - Display Fonts

/// Effra-Medium 20
@property(class, nonatomic, readonly) UIFont *sg_display1;

/// Effra-Medium 18
@property(class, nonatomic, readonly) UIFont *sg_display2;

/// SF-Medium 18
@property(class, nonatomic, readonly) UIFont *sg_display3;

/// SF-Medium 16
@property(class, nonatomic, readonly) UIFont *sg_display4;

/// SF-Medium 15
@property(class, nonatomic, readonly) UIFont *sg_display5;

/// SF-Medium 13
@property(class, nonatomic, readonly) UIFont *sg_display6;

/// SF-Medium 13
@property(class, nonatomic, readonly) UIFont *sg_display7;

/// SF-Medium 11
@property(class, nonatomic, readonly) UIFont *sg_display8;

#pragma mark - Body Fonts

/// SF-Regular 16
@property(class, nonatomic, readonly) UIFont *sg_body1;

/// SF-Regular 15
@property(class, nonatomic, readonly) UIFont *sg_body2;

/// SF-Regular 14
@property(class, nonatomic, readonly) UIFont *sg_body3;

/// SF-Regular 13
@property(class, nonatomic, readonly) UIFont *sg_body4;

/// SF-Regular 12
@property(class, nonatomic, readonly) UIFont *sg_body5;

#pragma mark - Other Fonts

/// Effra-Bold 15
@property(class, nonatomic, readonly) UIFont *sg_button1;

/// Effra-Bold 14
@property(class, nonatomic, readonly) UIFont *sg_button2;

/// SF-Regular 14
@property(class, nonatomic, readonly) UIFont *sg_button3;

/// SF-Bold 10
@property(class, nonatomic, readonly) UIFont *sg_button4;

/// SF-Bold 12
@property(class, nonatomic, readonly) UIFont *sg_subtitle;

/// SF-Bold 11
@property(class, nonatomic, readonly) UIFont *sg_subheader;

/// SF-Medium 10
@property(class, nonatomic, readonly) UIFont *sg_floatLabel;

/// SF-Medium 26
@property(class, nonatomic, readonly) UIFont *sg_listingPrice1;

/// SF-Medium 8
@property(class, nonatomic, readonly) UIFont *sg_dealScoreLabel;

/// Effra-Medium 38
@property(class, nonatomic, readonly) UIFont *sg_filterPriceLabel;

/// SF-Semibold 17
@property(class, nonatomic, readonly) UIFont *sg_nav;

/// SF-Regular 17
@property(class, nonatomic, readonly) UIFont *sg_navlink;


/// DEPRECATED – This method should be used only for older views with non-standard
/// fonts. New views should always be designed to use one of the existing styles.
+ (UIFont *)sg_genericWithSize:(CGFloat)size;

@end
