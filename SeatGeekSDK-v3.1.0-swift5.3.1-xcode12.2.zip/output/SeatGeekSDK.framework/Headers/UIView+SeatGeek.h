//
//  UIView+SeatGeek.h
//  SeatGeek
//
//  Created by James Van-As on 1/08/13.
//  Copyright (c) 2013 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (SeatGeek)

+ (UIView*) sgk_notFoundViewWithFrame:(CGRect)frame text:(NSString*)text;
- (void)sgk_addSubviewToBack:(UIView*)view;
- (void)sgk_roundOffFrame;

- (UIView *)sgk_superviewOfClass:(Class)class;

@end
