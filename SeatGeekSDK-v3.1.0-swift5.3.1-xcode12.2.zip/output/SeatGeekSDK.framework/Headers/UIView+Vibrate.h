//
//  UIView+Vibrate.h
//  SeatGeek
//
//  Created by James Van-As on 4/07/14.
//  Copyright (c) 2014 SeatGeek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Vibrate)
- (void)vibrateWithDuration:(NSTimeInterval)duration
                     travel:(CGFloat)travel
                   useMotor:(BOOL)useMotor
                 completion:(void (^)(BOOL finished))completion;

@end
