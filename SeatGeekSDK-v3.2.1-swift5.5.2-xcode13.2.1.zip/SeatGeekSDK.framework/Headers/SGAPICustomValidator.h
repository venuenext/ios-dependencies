//
//  SGAPICustomValidator.h
//  Pods
//
//  Created by Matt Baron on 6/27/18.
//

#import "SGPItem.h"

@interface SGAPICustomValidator : SGPItem
@property (nonatomic, copy) NSString *errorMessage;
@property (nonatomic, copy) NSString *regexString;
@end
