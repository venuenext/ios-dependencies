//
//  SGAPIPrivateImports.h
//  Pods
//
//  Created by Dan Stenmark on 12/23/21.
//

#if __has_include(<SeatGeekSDK/SGPItem.h>)
#define SGPITEM_H <SeatGeekSDK/SGPItem.h>
#elif __has_include(<SGAPIPrivate/SGPItem.h>)
#define SGPITEM_H <SGAPIPrivate/SGPItem.h>
#endif

#if __has_include(<SeatGeekSDK/SGItem.h>)
#define SGITEM_H <SeatGeekSDK/SGItem.h>
#elif __has_include(<SGAPI/SGItem.h>)
#define SGITEM_H <SGAPI/SGItem.h>
#endif

#if __has_include(<SeatGeekSDK/SGAPIError.h>)
#define SGAPIERROR_H <SeatGeekSDK/SGAPIError.h>
#elif __has_include(<SGAPIPrivate/SGAPIError.h>)
#define SGAPIERROR_H <SGAPIPrivate/SGAPIError.h>
#endif

#if __has_include(<SeatGeekSDK/SGTrackerEnums.h>)
#define SGTRACKER_ENUMS_H <SeatGeekSDK/SGTrackerEnums.h>
#elif __has_include(<SGTracker/SGTrackerEnums.h>)
#define SGTRACKER_ENUMS_H <SGTracker/SGTrackerEnums.h>
#endif

#if __has_include(<SeatGeekSDK/SGHTTPRequest.h>)
#define SGHTTPREQUEST_H <SeatGeekSDK/SGHTTPRequest.h>
#elif __has_include(<SGHTTPRequest/SGHTTPRequest.h>)
#define SGHTTPREQUEST_H <SGHTTPRequest/SGHTTPRequest.h>
#endif

#if __has_include(<SeatGeekSDK/SGAddress.h>)
#define SGADDRESS_H <SeatGeekSDK/SGAddress.h>
#elif __has_include(<SGAPIPrivate/SGAddress.h>)
#define SGADDRESS_H <SGAPIPrivate/SGAddress.h>
#endif

#if __has_include(<SeatGeekSDK/MGBlockWrapper.h>)
#define MGBLOCKWRAPPER_H <SeatGeekSDK/MGBlockWrapper.h>
#elif __has_include(<MGEvents/MGBlockWrapper.h>)
#define MGBLOCKWRAPPER_H <MGEvents/MGBlockWrapper.h>
#endif

#if __has_include(<SeatGeekSDK/SGAPICustomValidator.h>)
#define SGAPI_CUSTOM_VALIDATOR_H <SeatGeekSDK/SGAPICustomValidator.h>
#elif __has_include(<SGAPIPrivate/SGAPICustomValidator.h>)
#define SGAPI_CUSTOM_VALIDATOR_H <SGAPIPrivate/SGAPICustomValidator.h>
#endif

#if __has_include(<SeatGeekSDK/SGPaymentMethod.h>)
#define SGPAYMENT_METHOD_H <SeatGeekSDK/SGPaymentMethod.h>
#elif __has_include(<SGAPIPrivate/SGPaymentMethod.h>)
#define SGPAYMENT_METHOD_H <SGAPIPrivate/SGPaymentMethod.h>
#endif

#if __has_include(<SeatGeekSDK/SGQuery.h>)
#define SGQUERY_H <SeatGeekSDK/SGQuery.h>
#elif __has_include(<SGAPI/SGQuery.h>)
#define SGQUERY_H <SGAPI/SGQuery.h>
#endif

#if __has_include(<SeatGeekSDK/SGSpotlightSearchableProtocol.h>)
#define SGSPOTLIGHT_SEARCHABLE_PROTOCOL_H <SeatGeekSDK/SGSpotlightSearchableProtocol.h>
#elif __has_include(<SGAPIPrivate/SGSpotlightSearchableProtocol.h>)
#define SGSPOTLIGHT_SEARCHABLE_PROTOCOL_H <SGAPIPrivate/SGSpotlightSearchableProtocol.h>
#endif

#if __has_include(<SeatGeekSDK/SGPerson.h>)
#define SGPERSON_H <SeatGeekSDK/SGPerson.h>
#elif __has_include(<SGAPIPrivate/SGPerson.h>)
#define SGPERSON_H <SGAPIPrivate/SGPerson.h>
#endif
