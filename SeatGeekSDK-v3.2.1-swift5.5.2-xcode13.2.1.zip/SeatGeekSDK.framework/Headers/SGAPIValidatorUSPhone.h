//
//  Created by matt on 7/02/15.
//

#import "SGAPIValidator.h"

@interface SGAPIValidatorUSPhone : SGAPIValidator

@end
