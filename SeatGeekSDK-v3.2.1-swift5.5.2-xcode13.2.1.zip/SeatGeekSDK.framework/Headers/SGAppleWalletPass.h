//
//  SGAppleWallet.h
//  Adjust
//
//  Created by Matt Baron on 10/16/17.
//

@import PassKit;

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGITEM_H

@interface SGAppleWalletPass : SGItem

@property (nullable, nonatomic, readonly, strong) PKPass *pkPass;
@property (nullable, nonatomic, readonly, strong) NSData *data;

@end
