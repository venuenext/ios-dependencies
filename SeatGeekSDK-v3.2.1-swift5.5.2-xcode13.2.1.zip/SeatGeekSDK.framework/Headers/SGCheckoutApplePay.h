//
//  Created by matt on 13/01/15.
//
// See the Apple Pay comments in
// https://github.com/seatgeek/api/blob/master/docs/checkout/purchases/summary.md and
// https://github.com/seatgeek/api/blob/master/docs/checkout/purchases/request_object.md .

@import PassKit;

#import "SGCheckoutBaseScreen.h"

@class SGCheckoutPurchase, SGEventManager;

@interface SGCheckoutApplePay : SGCheckoutBaseScreen <PKPaymentAuthorizationViewControllerDelegate>

#ifndef SEATGEEK_SDK
@property (nonatomic, assign) SGTrackerEventListingViewMode verifiedPrimaryViewMode;
#endif
@property (nonatomic, strong) PKPaymentRequest *request;
@property (nonatomic, strong) PKPaymentAuthorizationViewController *applePayView;
@property (nonatomic, assign) BOOL loggedCheckoutBegin;
/// block to be called if the user cancels out of apple pays
@property (nonatomic, copy) MGBlock onCancel;
/// Clicked listing display orientation
@property (nonatomic, assign) BOOL isHorizontalListing;

@end
