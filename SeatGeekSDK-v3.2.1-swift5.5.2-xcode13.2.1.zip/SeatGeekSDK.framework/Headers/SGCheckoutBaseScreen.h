//
//  Created by matt on 1/12/14.
//

@import MessageUI;

#import "MGLine.h"
#import "SGNavigatorChildController.h"

@class SGCheckoutPurchase;

@interface SGCheckoutBaseScreen : SGNavigatorChildController <MFMailComposeViewControllerDelegate> {
    UIView *_footer;
}

@property (nonatomic, strong) SGCheckoutPurchase *purchase;
@property (nonatomic, strong) UIView *footer;

@end
