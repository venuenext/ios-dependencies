//
//  SGEligiblePayoutMethodType.h
//  SGAPIPrivate
//
//  Created by Hunter Mask on 3/18/19.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H
#import "SGFunding.h"

@interface SGEligiblePayoutMethodType : SGPItem

@property (nonatomic, strong, nullable) NSString *summary;
@property (nonatomic, strong, nonnull) NSString *displayName;
@property (nonatomic, strong, nullable) NSString *imageURL;
@property (nonatomic) SGFundingType type;

@end
