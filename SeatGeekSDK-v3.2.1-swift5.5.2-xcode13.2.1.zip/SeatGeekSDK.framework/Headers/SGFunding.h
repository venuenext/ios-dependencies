//
//  SGFunding.h
//  Pods
//
//  Created by James Van-As on 19/10/15.
//
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H

typedef NS_ENUM(NSInteger, SGFundingType) {
    SGFundingTypeBank,
    SGFundingTypeVenmo,
    SGFundingTypeSROCredit,
    SGFundingTypeUnknown
};

@interface SGFunding : SGPItem

+ (instancetype)fundingItemForDict:(NSDictionary *)dict;

+ (SGFundingType)fundingTypeForString:(NSString *)typeString;
+ (NSString *)stringForFundingType:(SGFundingType)fundingType;

@property (nonatomic) SGFundingType type;

- (NSString *)shortDisplayString;
- (NSString *)longDisplayString;
- (UIImage *)image;
- (UIImage *)smallImage;

- (NSDictionary *)payload;  // used for sending to the server

@end
