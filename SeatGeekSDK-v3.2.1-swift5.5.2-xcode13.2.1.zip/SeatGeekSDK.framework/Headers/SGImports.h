//
//  SGImports.h
//  SeatGeek
//
//  Created by Dan Stenmark on 12/23/21.
//  Copyright © 2021 SeatGeek. All rights reserved.
//

#if __has_include(<SeatGeekSDK/SGAPIPrivateImports.h>)
#import <SeatGeekSDK/SGAPIPrivateImports.h>
#elif __has_include(<SGAPIPrivate/SGAPIPrivateImports.h>)
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#if __has_include(<SeatGeekSDK/SGPurchase.h>)
#define SGPURCHASE_H <SeatGeekSDK/SGPurchase.h>
#elif __has_include(<SGAPIPrivate/SGPurchase.h>)
#define SGPURCHASE_H <SGAPIPrivate/SGPurchase.h>
#endif
