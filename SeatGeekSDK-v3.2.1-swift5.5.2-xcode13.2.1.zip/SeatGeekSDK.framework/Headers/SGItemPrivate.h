//
//  Created by matt on 31/08/14.
//

#import "SGSpotlightSearchableProtocol.h"


@protocol SGItemPrivate <NSObject, SGSpotlightSearchable>

- (NSString *)dataKey;
/// placeholder artwork
- (NSString *)placeHolderImageName;
- (NSString *)imageURLForSize:(CGSize)size;
/// fallback background colour to be used for this item
- (UIColor *)missingArtworkColor;

@end
