//
//  SGLogging.h
//  SeatGeek
//
//  Created by James Van-As on 4/04/14.
//  Copyright (c) 2014 SeatGeek. All rights reserved.
//

#ifdef SG_CRASHLYTICS_ENABLED
#import <FirebaseCrashlytics/FIRCrashlytics.h>
#endif

#import <Foundation/Foundation.h>

typedef NS_OPTIONS(NSInteger, SGLoggingTypes) {
    SGLoggingTypeNone      = 1 << 0,
    SGLoggingTypeGeneric   = 1 << 1,
    SGLoggingTypeAnalytics = 1 << 2,
    SGLoggingTypeAPI       = 1 << 3
};

// Debug Logging. SGLog to log, SGDebugLog to log only in Debug builds.
#define SGLog(s, ...) \
NSLog(@"%@",[NSString stringWithFormat:(s), ##__VA_ARGS__])

// Logging to crashlytics
#ifdef SG_CRASHLYTICS_ENABLED
#define CrashlyticsLog(type, __FORMAT__, ...) \
    if ([SGLogging shouldLog:type]) { \
        [[FIRCrashlytics crashlytics] logWithFormat:@"%s line %d $ " __FORMAT__, __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]; \
    } else { \
        [[FIRCrashlytics crashlytics] logWithFormat:@"%s line %d $ " __FORMAT__, __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]; \
    }
#else
#define CrashlyticsLog(type, __FORMAT__, ...) \
    do {} while (0)
#endif


#if !defined(DEBUG)

// Release build only
    #define SGDebugLog(...) do {} while (0)
    #define SGDebugTypedLog(type, ...) do {} while (0)
    #define SGDebugAssert(condition, desc, ...) \
        if (!(condition)) { \
            CrashlyticsLog(SGLoggingTypeGeneric, @"%@",[NSString stringWithFormat:(desc), ##__VA_ARGS__]); \
        }
    #define SGRemindMeOn(dateString, to) do {} while (0)
#else

    // Debug build only logging
    bool AmIBeingDebugged(void);

    #define SGDebugLog(...) \
        if ([SGLogging shouldLog:SGLoggingTypeGeneric]) { SGLog(__VA_ARGS__); }

    #define SGDebugTypedLog(type, ...) \
        if ([SGLogging shouldLog:type]) { SGLog(__VA_ARGS__); }

    #define SGDebugAssert(condition, desc, ...) \
    if (!(condition)) { \
        NSLog(@"%@",[NSString stringWithFormat:(desc), ##__VA_ARGS__]); \
        if (AmIBeingDebugged()) \
            kill (getpid(), SIGSTOP); \
        else { \
            NSLog(@"%s, %d: could not break into debugger.", __FILE__, __LINE__); \
            CrashlyticsLog(SGLoggingTypeGeneric, @"%@",[NSString stringWithFormat:(desc), ##__VA_ARGS__]); \
        } \
    }
    #define SGRemindMeOn(dateString, toDo) \
        { [SGLogging remindMeOnDateString:dateString to:toDo]; }

#endif

@interface SGLogging : NSObject

+ (SGLoggingTypes)loggingMask;
+ (void)setLoggingMask:(SGLoggingTypes)types;
+ (BOOL)shouldLog:(SGLoggingTypes)types;
+ (void)remindMeOn:(NSDate *)reminderDate to:(NSString *)doSomething;
+ (void)remindMeOnDateString:(NSString *)dateString to:(NSString *)doSomething;
+ (void)updateCrashlyticsDeviceID;

@end
