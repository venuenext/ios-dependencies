//
//  Created by matt on 14/10/15.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGITEM_H

@interface SGPDF : SGItem

@property (nullable, nonatomic, strong, readonly) NSData *data;

- (nullable UIImage *)imageWithMaxSize:(CGSize)size;

- (BOOL)canShowOrDownloadPDFData;

@end
