//
//  Created by matt on 30/07/15.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGITEM_H
#import SGAPIERROR_H
#import MGBLOCKWRAPPER_H

@class SGFileCache;

@interface SGPItem : SGItem
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) NSMutableDictionary *previousValues;
@property (nonatomic, strong) NSDictionary *customValidators;

// undo management
- (BOOL)hasChanged;
- (void)undoChanges;
- (BOOL)willChangeField:(NSString *)field toValue:(id)value;

// saving updates
- (void)saveChanges;
- (void)saveChangesThenDo:(MGBlock)success onFail:(SGAPIFailBlock)fail;

// local validation
+ (NSDictionary *)validators;
- (NSArray *)validationErrors;
- (NSArray *)validationErrorsFor:(NSDictionary *)validators;
- (SGAPIError *)validationErrorForField:(NSString *)field;
+ (NSString *)categoryForValidationErrors;  // defaults to unknown

// custom local validation
// These methods expect a dictionary with the structure {fieldName: [SGAPIValidator subclass]}
- (NSArray *)validationErrorsForCustomValidators:(NSDictionary *)validators;
- (SGAPIError *)validationErrorForField:(NSString *)field withCustomValidators:(NSDictionary *)customValidators;

@end
