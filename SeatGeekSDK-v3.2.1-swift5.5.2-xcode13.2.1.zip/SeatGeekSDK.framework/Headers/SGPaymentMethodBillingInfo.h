//
//  SGPaymentMethodBillingInfo.h
//  Pods
//
//  Created by Matt Baron on 6/19/18.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H

@class SGPaymentMethodBillingInfoField;

@interface SGPaymentMethodBillingInfo : SGPItem

@property (nonatomic, strong) NSArray <SGPaymentMethodBillingInfoField *> *billingInfoFields;
@property (nonatomic, copy) NSString *country;
@property (nonatomic, copy) NSString *countryLabel;

- (void)fetchBillingInfoForCountry:(NSString *)countryCode
                           eventId:(NSNumber *)eventId
                            thenDo:(MGBlock)success
                            onFail:(SGAPIFailBlock)fail;
@end
