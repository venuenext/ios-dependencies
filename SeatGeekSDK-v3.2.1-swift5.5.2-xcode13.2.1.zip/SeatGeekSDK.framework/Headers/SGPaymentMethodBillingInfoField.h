//
//  SGPaymentMethodBillingInfoField.h
//  Pods
//
//  Created by Matt Baron on 6/19/18.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H
#import SGAPI_CUSTOM_VALIDATOR_H

@class SGPaymentMethodBillingInfoFieldOption;

@interface SGPaymentMethodBillingInfoField : SGPItem

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *label;
@property (nonatomic, assign) BOOL required;
@property (nonatomic, strong) NSArray <SGPaymentMethodBillingInfoFieldOption *> *billingInfoFieldOptions;
@property (nonatomic, strong) NSArray <SGAPICustomValidator *> *customRegexValidators;

- (NSArray<SGPaymentMethodBillingInfoFieldOption *> *)filteredBillingInfoFieldOptionsByLabelForQuery:(NSString *)query;
- (SGPaymentMethodBillingInfoFieldOption *)matchingBillingInfoFieldOptionForQuery:(NSString *)query;

- (BOOL)supportsOptions;
@end
