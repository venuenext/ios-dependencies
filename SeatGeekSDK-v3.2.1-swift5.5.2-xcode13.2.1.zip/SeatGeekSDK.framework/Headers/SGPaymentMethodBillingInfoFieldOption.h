//
//  SGPaymentMethodBillingInfoFieldOption.h
//  Pods
//
//  Created by Matt Baron on 6/19/18.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H

@interface SGPaymentMethodBillingInfoFieldOption : SGPItem

@property (nonatomic, copy) NSString *value;
@property (nonatomic, copy) NSString *label;
@property (nonatomic, copy) NSString *shortLabel;

@end
