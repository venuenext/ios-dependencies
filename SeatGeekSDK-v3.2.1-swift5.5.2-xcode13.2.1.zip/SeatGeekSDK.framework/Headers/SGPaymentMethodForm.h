//
//  SGPaymentMethodForm.h
//  SeatGeek
//
//  Created by James Van-As on 4/09/14.
//  Copyright (c) 2014 SeatGeek. All rights reserved.
//

#import "SGPaymentControllerProtocol.h"
#import "SGCheckoutEditScreen.h"

#define SGRefetchBillingInfo @"SGRefetchBillingInfo"

@class SGPaymentMethodSpreedly, SGPaymentMethodBillingInfo;

@interface SGPaymentMethodForm : SGCheckoutEditScreen
      <SGPaymentControllerProtocol, UITextFieldDelegate>

+ (instancetype)paymentForRecoupment;
+ (instancetype)paymentForRecoupmentHideBuyerGuarantee;

+ (UIViewController *)createBuyerGuaranteeController;

@property (nonatomic, strong) SGPaymentMethodSpreedly *paymentMethod;

@property (nonatomic, strong) SGPaymentMethodBillingInfo *billingInfo;

@property (nonatomic,assign) BOOL showDeleteButton;
@property (nonatomic,assign) BOOL focusKeyboardOnOpen;
@property (nonatomic,assign) NSTimeInterval focusKeyboardOnOpenDelay;

#if INCLUDE_VENUE_SERVICES
@property (nonatomic) SGTrackerUserPaymentUIOrigin uIOrigin;
#endif

@end
