//
//  Created by matt on 20/01/15.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPAYMENT_METHOD_H

#define SGUpdatePaymentMethodsWithDict  @"SGUpdatePaymentMethodsWithDict"
#define SGDeletePaymentMethod           @"SGDeletePaymentMethod"
#define SGRefreshCreditCardFields       @"SGRefreshCreditCardFields"

@interface SGPaymentMethodSpreedly : SGPaymentMethod
      <NSCopying>

@property (nonatomic, copy) NSString *storageState;
@property (nonatomic, assign) BOOL cvvRecacheNeeded;
@property (nonatomic, assign) BOOL eligibleForRecoupment;

- (void)deleteFromServerOnFail:(SGAPIFailBlock)fail;
- (void)setIsDefault:(BOOL)isDefault tellServer:(BOOL)tellServer;
- (void)setIsEligibleRecoupmentMethodThenDo:(void(^)(NSDictionary *responseJSON))success
                                    failure:(void(^)(void))failure;

- (BOOL)needToSendToSpreedly;
- (void)sendToSpreedlyThenDo:(void(^)(void))success onFail:(SGAPIFailBlock)fail;
- (void)recacheCVVThenDo:(void(^)(void))success onFail:(SGAPIFailBlock)fail wasUI:(BOOL)wasUI;

@end
