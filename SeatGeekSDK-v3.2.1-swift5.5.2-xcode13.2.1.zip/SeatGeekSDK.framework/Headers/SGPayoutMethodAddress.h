//
//  SGPayoutMethodAddress.h
//  Pods
//
//  Created by James Van-As on 19/10/15.
//
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGADDRESS_H

@interface SGPayoutMethodAddress : SGAddress

- (NSDictionary *)payload;  // used for sending to the server

@end
