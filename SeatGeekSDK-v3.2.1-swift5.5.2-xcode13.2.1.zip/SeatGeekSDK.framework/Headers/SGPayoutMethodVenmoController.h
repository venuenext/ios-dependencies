//
//  SGPayoutMethodVenmoController.h
//  SeatGeek
//
//  Created by James Van-As on 21/10/15.
//  Copyright © 2015 SeatGeek. All rights reserved.
//

#import "SGNavigatorChildController.h"

@class SGPayoutMethod;

@interface SGPayoutMethodVenmoController : SGNavigatorChildController <UITextFieldDelegate>

@property (nonatomic, copy) MGBlock onTappedDone;

+ (instancetype)controllerWithPayoutMethod:(SGPayoutMethod *)payoutMethod;

@end
