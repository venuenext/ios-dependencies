//
//  SGPayoutStatus.h
//  Pods
//
//  Created by Steven Lehrburger on 11/19/15.
//
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H

#define SGKPayoutStatusPending @"pending"
#define SGKPayoutStatusIssued  @"issued"

@interface SGPayoutStatus : NSObject

+ (id)itemForString:(NSString *)string;

- (NSString *)type;
- (NSString *)displayStatus;

@end
