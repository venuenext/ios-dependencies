//
//  Created by matt on 30/07/15.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H

@interface SGPerson : SGPItem

@property (nonatomic, copy) NSString *username;
@property (nonatomic, copy) NSString *fullName;
@property (nonatomic, copy) NSString *firstName;
@property (nonatomic, copy) NSString *lastName;
@property (nonatomic, copy) NSString *mobilePhone;
@property (nonatomic, copy) NSString *prettyMobilePhone;
@property (nonatomic, copy) NSString *email;
@property (nonatomic, copy) NSString *profileImageUrl;

- (NSString *)displayName;
- (NSString *)shortDisplayName;
- (NSString *)initials;

@end
