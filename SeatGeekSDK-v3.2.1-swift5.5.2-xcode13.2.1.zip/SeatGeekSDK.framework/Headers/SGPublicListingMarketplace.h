//
//  SGPublicListingMarketplace.h
//  Pods
//
//  Created by Matt Baron on 3/6/18.
//

#if __has_include(<SeatGeekSDK/SGImports.h>)
#import <SeatGeekSDK/SGImports.h>
#else
#import <SGAPIPrivate/SGAPIPrivateImports.h>
#endif

#import SGPITEM_H

typedef NS_ENUM(NSInteger, SGPublicListingMarketplaceDisplayType) {
    SGPublicListingMarketplaceDisplayTypeRequired,
    SGPublicListingMarketplaceDisplayTypeOptional,
    SGPublicListingMarketplaceDisplayTypeNone,
    SGPublicListingMarketplaceDisplayTypeUnknown
};

@interface SGPublicListingMarketplace : SGPItem

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *shortName;
@property (nonatomic, readonly) SGPublicListingMarketplaceDisplayType displayType;
@property (nonatomic, readonly) BOOL isSeatGeekMarket;

@end
