//
//  Created by James on 25/09/15.
//

@class CSSearchableItemAttributeSet, UIImage;

typedef void (^SpotlightCompletion)(NSError * _Nullable error);

@protocol SGSpotlightSearchable <NSObject>

// Spotlight
- (void)addToLocalSpotlightIndex;
- (void)removeFromLocalSpotlightIndex;

- (NSString * _Nonnull)spotlightItemTitle;
- (NSString * _Nonnull)spotlightItemDescription;

@optional
+ (void)removeAllFromSpotlightIndex; // should remove all of this object type from the spotlight index

#if !TARGET_OS_WATCH

- (void)addToLocalAndPublicSpotlightIndex:(nullable void(^)( NSUserActivity * _Nullable userActivity))receiveUserActivity;

- (void)addToLocalSpotlightIndexWithImage:(UIImage * _Nullable)image;
- (void)addToLocalSpotlightIndexWithImage:(UIImage * _Nullable )image then:(nullable SpotlightCompletion)completion;

// Lower level calls used by addToLocalSpotlightIndex, or accessed manually for NSUserActivity
- (CSSearchableItemAttributeSet * _Nonnull)searchAttributes;

#endif

@end
