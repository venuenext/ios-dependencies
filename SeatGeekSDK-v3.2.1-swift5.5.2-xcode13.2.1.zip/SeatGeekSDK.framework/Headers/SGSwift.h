//
//  SGSwift.h
//  SeatGeek
//
//  Created by James Van-As on 17/11/17.
//  Copyright © 2017 SeatGeek. All rights reserved.
//

/*
 Compatibility layer for easier importing of swift headers
 across the different targets
 */

#if __has_include("SeatGeek-Swift.h")
#import "SeatGeek-Swift.h"
#elif __has_include("SeatGeekToday-Swift.h")
#import "SeatGeekToday-Swift.h"
#elif __has_include("SeatGeekMessageApp-Swift.h")
#import "SeatGeekMessageApp-Swift.h"
#elif __has_include("SeatGeekNotificationContentTickets-Swift.h")
#import "SeatGeekNotificationContentTickets-Swift.h"
#elif __has_include(<SeatGeekSDK/SeatGeekSDK-Swift.h>)
#import <SeatGeekSDK/SeatGeekSDK-Swift.h>
#endif
