//
//  SGTrackerEnums.h
//  Pods
//
//  Version 17.0.0 created by the Tracker Service using ios_generate_classes.py.
//
//

typedef enum {
    SGTrackerGlobalUIOriginAccountSettings,
    SGTrackerGlobalUIOriginAllSearchResults,
    SGTrackerGlobalUIOriginAppForeground,
    SGTrackerGlobalUIOriginBestAvailableForm,
    SGTrackerGlobalUIOriginBrowse,
    SGTrackerGlobalUIOriginBrowseSearch,
    SGTrackerGlobalUIOriginBrowseSearchDefaultSuggestion,
    SGTrackerGlobalUIOriginCategory,
    SGTrackerGlobalUIOriginCategorySidebar,
    SGTrackerGlobalUIOriginCheckout,
    SGTrackerGlobalUIOriginCheckoutPromocode,
    SGTrackerGlobalUIOriginCity,
    SGTrackerGlobalUIOriginCollectionsBar,
    SGTrackerGlobalUIOriginContextualPushPrompt,
    SGTrackerGlobalUIOriginDebug,
    SGTrackerGlobalUIOriginDeeplink,
    SGTrackerGlobalUIOriginDrawer,
    SGTrackerGlobalUIOriginEmailModal,
    SGTrackerGlobalUIOriginEvent,
    SGTrackerGlobalUIOriginEventFilters,
    SGTrackerGlobalUIOriginEventFiltersMenu,
    SGTrackerGlobalUIOriginEventInfo,
    SGTrackerGlobalUIOriginEventListingsHeader,
    SGTrackerGlobalUIOriginEventSidebar,
    SGTrackerGlobalUIOriginEventTickets,
    SGTrackerGlobalUIOriginEventTitle,
    SGTrackerGlobalUIOriginExchangeModal,
    SGTrackerGlobalUIOriginFacebookAccountUpgrade,
    SGTrackerGlobalUIOriginFilterModal,
    SGTrackerGlobalUIOriginFilterSortModal,
    SGTrackerGlobalUIOriginForgotPassword,
    SGTrackerGlobalUIOriginHome,
    SGTrackerGlobalUIOriginHomeSearch,
    SGTrackerGlobalUIOriginHomeSidebar,
    SGTrackerGlobalUIOriginHomepage,
    SGTrackerGlobalUIOriginHorizontalList,
    SGTrackerGlobalUIOriginiMessage,
    SGTrackerGlobalUIOriginInitialOnboarding,
    SGTrackerGlobalUIOriginiOSToday,
    SGTrackerGlobalUIOriginList,
    SGTrackerGlobalUIOriginListingDetail,
    SGTrackerGlobalUIOriginLocationSearch,
    SGTrackerGlobalUIOriginLogIn,
    SGTrackerGlobalUIOriginLogin,
    SGTrackerGlobalUIOriginLogin2Fa,
    SGTrackerGlobalUIOriginLottery,
    SGTrackerGlobalUIOriginMatchup,
    SGTrackerGlobalUIOriginModal,
    SGTrackerGlobalUIOriginMyTickets,
    SGTrackerGlobalUIOriginMyTicketsTicket,
    SGTrackerGlobalUIOriginNag,
    SGTrackerGlobalUIOriginNavBarButton,
    SGTrackerGlobalUIOriginNavBarDropdown,
    SGTrackerGlobalUIOriginNavBarSearch,
    SGTrackerGlobalUIOriginNavBarTrackTickets,
    SGTrackerGlobalUIOriginNflListSeatgeekUpsell,
    SGTrackerGlobalUIOriginNotification,
    SGTrackerGlobalUIOriginOnboarding,
    SGTrackerGlobalUIOriginPaidTransfer,
    SGTrackerGlobalUIOriginPerformer,
    SGTrackerGlobalUIOriginPerformerSidebar,
    SGTrackerGlobalUIOriginPostPurchase,
    SGTrackerGlobalUIOriginPublicSale,
    SGTrackerGlobalUIOriginRecurringEvent,
    SGTrackerGlobalUIOriginReferralInvites,
    SGTrackerGlobalUIOriginRegister,
    SGTrackerGlobalUIOriginResaleFlow,
    SGTrackerGlobalUIOriginSearch,
    SGTrackerGlobalUIOriginSeatingChartBestDeal,
    SGTrackerGlobalUIOriginSeatingChartFtEvents,
    SGTrackerGlobalUIOriginSeatingChartLowestPrice,
    SGTrackerGlobalUIOriginSeatingChartNextEvent,
    SGTrackerGlobalUIOriginSellLanding,
    SGTrackerGlobalUIOriginSellTickets,
    SGTrackerGlobalUIOriginSettings,
    SGTrackerGlobalUIOriginSettingsDisable,
    SGTrackerGlobalUIOriginSettingsEnable,
    SGTrackerGlobalUIOriginSettingsPromocode,
    SGTrackerGlobalUIOriginShortcutDynamicRecommendedEvent,
    SGTrackerGlobalUIOriginShortcutDynamicTicket,
    SGTrackerGlobalUIOriginShortcutDynamicTrackedEvent,
    SGTrackerGlobalUIOriginShortcutMyTickets,
    SGTrackerGlobalUIOriginShortcutSearch,
    SGTrackerGlobalUIOriginShortcutTracking,
    SGTrackerGlobalUIOriginStandalone,
    SGTrackerGlobalUIOriginTabSearch,
    SGTrackerGlobalUIOriginTickets,
    SGTrackerGlobalUIOriginTracking,
    SGTrackerGlobalUIOriginTrackingDashboard,
    SGTrackerGlobalUIOriginTransfer,
    SGTrackerGlobalUIOriginVenue,
    SGTrackerGlobalUIOriginVenueSeatingChart,
    SGTrackerGlobalUIOriginVenueSidebar,
    SGTrackerGlobalUIOriginVenuenext,
    SGTrackerGlobalUIOriginVerticalList,
    SGTrackerGlobalUIOriginZendeskSupportSdk,
    SGTrackerGlobalUIOriginNone,
} SGTrackerGlobalUIOrigin;


typedef enum {
    SGTrackerOpenAccountManagerScopeAccount,
    SGTrackerOpenAccountManagerScopeTransaction,
    SGTrackerOpenAccountManagerScopeNone,
} SGTrackerOpenAccountManagerScope;

typedef enum {
    SGTrackerOpenAccountManagerTypeCobranded,
    SGTrackerOpenAccountManagerTypeCobrandedEmbedded,
    SGTrackerOpenAccountManagerTypeSeatgeek,
    SGTrackerOpenAccountManagerTypeNone,
} SGTrackerOpenAccountManagerType;

typedef enum {
    SGTrackerApplewalletDisplayTypeBarcode,
    SGTrackerApplewalletDisplayTypePDF,
    SGTrackerApplewalletDisplayTypeScreenshot,
    SGTrackerApplewalletDisplayTypePlaceholder,
    SGTrackerApplewalletDisplayTypeNone,
} SGTrackerApplewalletDisplayType;

typedef enum {
    SGTrackerApplewalletUIOriginMyTicketsTicket,
    SGTrackerApplewalletUIOriginGlobal,
    SGTrackerApplewalletUIOriginNone,
} SGTrackerApplewalletUIOrigin;

typedef enum {
    SGTrackerAuthenticatedLinkUIOriginAccountSettings,
    SGTrackerAuthenticatedLinkUIOriginLogIn,
    SGTrackerAuthenticatedLinkUIOriginFacebookAccountUpgrade,
    SGTrackerAuthenticatedLinkUIOriginEventTickets,
    SGTrackerAuthenticatedLinkUIOriginNone,
} SGTrackerAuthenticatedLinkUIOrigin;

typedef enum {
    SGTrackerBrowseFilterFilterTypeCalendar,
    SGTrackerBrowseFilterFilterTypeLocation,
    SGTrackerBrowseFilterFilterTypeQuickDate,
    SGTrackerBrowseFilterFilterTypeOuter,
    SGTrackerBrowseFilterFilterTypeNone,
} SGTrackerBrowseFilterFilterType;

typedef enum {
    SGTrackerCheckoutErrorCategoryContact,
    SGTrackerCheckoutErrorCategoryDeliveryMethod,
    SGTrackerCheckoutErrorCategoryFatal,
    SGTrackerCheckoutErrorCategoryGeneral,
    SGTrackerCheckoutErrorCategoryPayment,
    SGTrackerCheckoutErrorCategoryProduct,
    SGTrackerCheckoutErrorCategoryShippingAddress,
    SGTrackerCheckoutErrorCategoryUnknown,
    SGTrackerCheckoutErrorCategoryNone,
} SGTrackerCheckoutErrorCategory;

typedef enum {
    SGTrackerCheckoutFeeChoiceHideFees,
    SGTrackerCheckoutFeeChoiceShowFees,
    SGTrackerCheckoutFeeChoiceNone,
} SGTrackerCheckoutFeeChoice;

typedef enum {
    SGTrackerCheckoutPaymentTypeCreditCard,
    SGTrackerCheckoutPaymentTypeApplePay,
    SGTrackerCheckoutPaymentTypeGooglePay,
    SGTrackerCheckoutPaymentTypeNone,
} SGTrackerCheckoutPaymentType;

typedef enum {
    SGTrackerCheckoutPromocodeTypeDiscount,
    SGTrackerCheckoutPromocodeTypeNone,
} SGTrackerCheckoutPromocodeType;

typedef enum {
    SGTrackerCheckoutFieldDataFieldBillingFirstName,
    SGTrackerCheckoutFieldDataFieldBillingLastName,
    SGTrackerCheckoutFieldDataFieldBillingAddress1,
    SGTrackerCheckoutFieldDataFieldBillingAddress2,
    SGTrackerCheckoutFieldDataFieldBillingCity,
    SGTrackerCheckoutFieldDataFieldBillingState,
    SGTrackerCheckoutFieldDataFieldBillingZip,
    SGTrackerCheckoutFieldDataFieldCardCvv,
    SGTrackerCheckoutFieldDataFieldCardExpMonth,
    SGTrackerCheckoutFieldDataFieldCardExpYear,
    SGTrackerCheckoutFieldDataFieldCardNumber,
    SGTrackerCheckoutFieldDataFieldDeliveryOption,
    SGTrackerCheckoutFieldDataFieldEmail,
    SGTrackerCheckoutFieldDataFieldNflOptIn,
    SGTrackerCheckoutFieldDataFieldPhone,
    SGTrackerCheckoutFieldDataFieldPromocode,
    SGTrackerCheckoutFieldDataFieldQuantity,
    SGTrackerCheckoutFieldDataFieldSeat,
    SGTrackerCheckoutFieldDataFieldShippingFirstName,
    SGTrackerCheckoutFieldDataFieldShippingLastName,
    SGTrackerCheckoutFieldDataFieldShippingAddress1,
    SGTrackerCheckoutFieldDataFieldShippingAddress2,
    SGTrackerCheckoutFieldDataFieldShippingCity,
    SGTrackerCheckoutFieldDataFieldShippingState,
    SGTrackerCheckoutFieldDataFieldShippingZip,
    SGTrackerCheckoutFieldDataFieldTerms,
    SGTrackerCheckoutFieldDataFieldNone,
} SGTrackerCheckoutFieldDataField;

typedef enum {
    SGTrackerCheckoutFieldEditTypeAdd,
    SGTrackerCheckoutFieldEditTypeRemove,
    SGTrackerCheckoutFieldEditTypeUpdate,
    SGTrackerCheckoutFieldEditTypeNone,
} SGTrackerCheckoutFieldEditType;

typedef enum {
    SGTrackerCheckoutItemItemTypeAccountCreditButton,
    SGTrackerCheckoutItemItemTypeBuyersGuaranteeDetails,
    SGTrackerCheckoutItemItemTypeFaqItem,
    SGTrackerCheckoutItemItemTypeFeeTooltip,
    SGTrackerCheckoutItemItemTypeMiniMap,
    SGTrackerCheckoutItemItemTypeUpsellSkip,
    SGTrackerCheckoutItemItemTypeNone,
} SGTrackerCheckoutItemItemType;

typedef enum {
    SGTrackerCheckoutCheckoutTypeApplePay,
    SGTrackerCheckoutCheckoutTypeCheckout,
    SGTrackerCheckoutCheckoutTypeGooglePay,
    SGTrackerCheckoutCheckoutTypeNone,
} SGTrackerCheckoutCheckoutType;

typedef enum {
    SGTrackerCheckoutSortTypeBestSeat,
    SGTrackerCheckoutSortTypeDealScore,
    SGTrackerCheckoutSortTypePrice,
    SGTrackerCheckoutSortTypeNone,
} SGTrackerCheckoutSortType;

typedef enum {
    SGTrackerCheckoutSectionEditTypeAdd,
    SGTrackerCheckoutSectionEditTypeEditSaved,
    SGTrackerCheckoutSectionEditTypeUseNone,
    SGTrackerCheckoutSectionEditTypeUseSaved,
    SGTrackerCheckoutSectionEditTypeNone,
} SGTrackerCheckoutSectionEditType;

typedef enum {
    SGTrackerCheckoutSectionFormSectionContact,
    SGTrackerCheckoutSectionFormSectionDeliveryAddress,
    SGTrackerCheckoutSectionFormSectionDeliveryOption,
    SGTrackerCheckoutSectionFormSectionNotes,
    SGTrackerCheckoutSectionFormSectionPayment,
    SGTrackerCheckoutSectionFormSectionPriceBreakdown,
    SGTrackerCheckoutSectionFormSectionPriceTypes,
    SGTrackerCheckoutSectionFormSectionPromocode,
    SGTrackerCheckoutSectionFormSectionQuantity,
    SGTrackerCheckoutSectionFormSectionSeats,
    SGTrackerCheckoutSectionFormSectionUpsells,
    SGTrackerCheckoutSectionFormSectionUpsellQuantity,
    SGTrackerCheckoutSectionFormSectionNone,
} SGTrackerCheckoutSectionFormSection;

typedef enum {
    SGTrackerCheckoutListingsDisplayOrientationHorizontal,
    SGTrackerCheckoutListingsDisplayOrientationVertical,
    SGTrackerCheckoutListingsDisplayOrientationNone,
} SGTrackerCheckoutListingsDisplayOrientation;

typedef enum {
    SGTrackerCheckoutSummaryFeeChoiceHideFees,
    SGTrackerCheckoutSummaryFeeChoiceShowFees,
    SGTrackerCheckoutSummaryFeeChoiceNone,
} SGTrackerCheckoutSummaryFeeChoice;

typedef enum {
    SGTrackerCheckoutSummaryPromocodeTypeDiscount,
    SGTrackerCheckoutSummaryPromocodeTypeNone,
} SGTrackerCheckoutSummaryPromocodeType;

typedef enum {
    SGTrackerCheckoutSummarySortTypeBestSeat,
    SGTrackerCheckoutSummarySortTypeDealScore,
    SGTrackerCheckoutSummarySortTypePrice,
    SGTrackerCheckoutSummarySortTypeNone,
} SGTrackerCheckoutSummarySortType;

typedef enum {
    SGTrackerDeviceLocationLocationSourcePreviousSession,
    SGTrackerDeviceLocationLocationSourceGps,
    SGTrackerDeviceLocationLocationSourceGeoIp,
    SGTrackerDeviceLocationLocationSourceInitialGeoIp,
    SGTrackerDeviceLocationLocationSourceLocationSearch,
    SGTrackerDeviceLocationLocationSourceAccount,
    SGTrackerDeviceLocationLocationSourceRoute,
    SGTrackerDeviceLocationLocationSourceNone,
} SGTrackerDeviceLocationLocationSource;

typedef enum {
    SGTrackerDeviceLocationUIOriginBrowse,
    SGTrackerDeviceLocationUIOriginSettings,
    SGTrackerDeviceLocationUIOriginSearch,
    SGTrackerDeviceLocationUIOriginGlobal,
    SGTrackerDeviceLocationUIOriginNone,
} SGTrackerDeviceLocationUIOrigin;

typedef enum {
    SGTrackerEntrancePageTypeAccount,
    SGTrackerEntrancePageTypeAccountManager,
    SGTrackerEntrancePageTypeAmpPerformer,
    SGTrackerEntrancePageTypeCategory,
    SGTrackerEntrancePageTypeCityPage,
    SGTrackerEntrancePageTypeEventPage,
    SGTrackerEntrancePageTypeHomepage,
    SGTrackerEntrancePageTypeListPage,
    SGTrackerEntrancePageTypeMatchupPage,
    SGTrackerEntrancePageTypeOther,
    SGTrackerEntrancePageTypePerformerPage,
    SGTrackerEntrancePageTypeRecurringEventPage,
    SGTrackerEntrancePageTypeSearch,
    SGTrackerEntrancePageTypeSeatView,
    SGTrackerEntrancePageTypeSeatingChart,
    SGTrackerEntrancePageTypeTba,
    SGTrackerEntrancePageTypeVenuePage,
    SGTrackerEntrancePageTypeNone,
} SGTrackerEntrancePageType;

typedef enum {
    SGTrackerEntrancePlatformAndroid,
    SGTrackerEntrancePlatformiOS,
    SGTrackerEntrancePlatformMobileWeb,
    SGTrackerEntrancePlatformWeb,
    SGTrackerEntrancePlatformNone,
} SGTrackerEntrancePlatform;

typedef enum {
    SGTrackerEntranceSourceCopy,
    SGTrackerEntranceSourceEmail,
    SGTrackerEntranceSourceNativeemail,
    SGTrackerEntranceSourceFacebook,
    SGTrackerEntranceSourceOther,
    SGTrackerEntranceSourceSiri,
    SGTrackerEntranceSourceSms,
    SGTrackerEntranceSourceTwitter,
    SGTrackerEntranceSourceNone,
} SGTrackerEntranceSource;

typedef enum {
    SGTrackerEntranceUIOriginShortcutMyTickets,
    SGTrackerEntranceUIOriginShortcutSearch,
    SGTrackerEntranceUIOriginShortcutTracking,
    SGTrackerEntranceUIOriginShortcutDynamicTicket,
    SGTrackerEntranceUIOriginShortcutDynamicTrackedEvent,
    SGTrackerEntranceUIOriginShortcutDynamicRecommendedEvent,
    SGTrackerEntranceUIOriginGlobal,
    SGTrackerEntranceUIOriginNone,
} SGTrackerEntranceUIOrigin;

typedef enum {
    SGTrackerEvent3DTouchUIOriginBrowse,
    SGTrackerEvent3DTouchUIOriginBrowseSearch,
    SGTrackerEvent3DTouchUIOriginCategory,
    SGTrackerEvent3DTouchUIOriginList,
    SGTrackerEvent3DTouchUIOriginPerformer,
    SGTrackerEvent3DTouchUIOriginTabSearch,
    SGTrackerEvent3DTouchUIOriginTracking,
    SGTrackerEvent3DTouchUIOriginVenue,
    SGTrackerEvent3DTouchUIOriginGlobal,
    SGTrackerEvent3DTouchUIOriginNone,
} SGTrackerEvent3DTouchUIOrigin;

typedef enum {
    SGTrackerEventBoxOfficeUIOriginEvent,
    SGTrackerEventBoxOfficeUIOriginEventInfo,
    SGTrackerEventBoxOfficeUIOriginGlobal,
    SGTrackerEventBoxOfficeUIOriginNone,
} SGTrackerEventBoxOfficeUIOrigin;

typedef enum {
    SGTrackerEventUIOriginAllSearchResults,
    SGTrackerEventUIOriginBrowse,
    SGTrackerEventUIOriginBrowseSearch,
    SGTrackerEventUIOriginCategory,
    SGTrackerEventUIOriginCategorySidebar,
    SGTrackerEventUIOriginCity,
    SGTrackerEventUIOriginEventSidebar,
    SGTrackerEventUIOriginHome,
    SGTrackerEventUIOriginHomeSearch,
    SGTrackerEventUIOriginiMessage,
    SGTrackerEventUIOriginiOSToday,
    SGTrackerEventUIOriginMatchup,
    SGTrackerEventUIOriginList,
    SGTrackerEventUIOriginMyTicketsTicket,
    SGTrackerEventUIOriginNavBarSearch,
    SGTrackerEventUIOriginNotification,
    SGTrackerEventUIOriginPerformer,
    SGTrackerEventUIOriginPerformerSidebar,
    SGTrackerEventUIOriginPublicSale,
    SGTrackerEventUIOriginRecurringEvent,
    SGTrackerEventUIOriginSeatingChartBestDeal,
    SGTrackerEventUIOriginSeatingChartFtEvents,
    SGTrackerEventUIOriginSeatingChartLowestPrice,
    SGTrackerEventUIOriginSeatingChartNextEvent,
    SGTrackerEventUIOriginTabSearch,
    SGTrackerEventUIOriginTracking,
    SGTrackerEventUIOriginTrackingDashboard,
    SGTrackerEventUIOriginTransfer,
    SGTrackerEventUIOriginVenue,
    SGTrackerEventUIOriginVenueSeatingChart,
    SGTrackerEventUIOriginNone,
} SGTrackerEventUIOrigin;

typedef enum {
    SGTrackerEventCollectionUIOriginCollectionsBar,
    SGTrackerEventCollectionUIOriginEventFiltersMenu,
    SGTrackerEventCollectionUIOriginNone,
} SGTrackerEventCollectionUIOrigin;

typedef enum {
    SGTrackerEventFeeFeeChoiceHideFees,
    SGTrackerEventFeeFeeChoiceShowFees,
    SGTrackerEventFeeFeeChoiceNone,
} SGTrackerEventFeeFeeChoice;

typedef enum {
    SGTrackerEventFeeFeeDefaultHideFees,
    SGTrackerEventFeeFeeDefaultShowFees,
    SGTrackerEventFeeFeeDefaultNone,
} SGTrackerEventFeeFeeDefault;

typedef enum {
    SGTrackerEventFeeUIOriginCollectionsBar,
    SGTrackerEventFeeUIOriginEventListingsHeader,
    SGTrackerEventFeeUIOriginFilterModal,
    SGTrackerEventFeeUIOriginSettings,
    SGTrackerEventFeeUIOriginGlobal,
    SGTrackerEventFeeUIOriginNone,
} SGTrackerEventFeeUIOrigin;

typedef enum {
    SGTrackerEventItemItemTypeAccessCodeToast,
    SGTrackerEventItemItemTypeBlueListingButton,
    SGTrackerEventItemItemTypeChangeSeats,
    SGTrackerEventItemItemTypePackageToast,
    SGTrackerEventItemItemTypePriceBreakdown,
    SGTrackerEventItemItemTypeSellerNotesInfo,
    SGTrackerEventItemItemTypeSellerNotesFaqArticle,
    SGTrackerEventItemItemTypeViewSeatInfo,
    SGTrackerEventItemItemTypeNone,
} SGTrackerEventItemItemType;

typedef enum {
    SGTrackerEventListingBestDealOrLowestPriceListingBestDeal,
    SGTrackerEventListingBestDealOrLowestPriceListingLowestPrice,
    SGTrackerEventListingBestDealOrLowestPriceListingNone,
} SGTrackerEventListingBestDealOrLowestPriceListing;

typedef enum {
    SGTrackerEventListingCheckoutTypeApplePay,
    SGTrackerEventListingCheckoutTypeCheckout,
    SGTrackerEventListingCheckoutTypeNone,
} SGTrackerEventListingCheckoutType;

typedef enum {
    SGTrackerEventListingFeeChoiceHideFees,
    SGTrackerEventListingFeeChoiceShowFees,
    SGTrackerEventListingFeeChoiceNone,
} SGTrackerEventListingFeeChoice;

typedef enum {
    SGTrackerEventListingFeeDefaultHideFees,
    SGTrackerEventListingFeeDefaultShowFees,
    SGTrackerEventListingFeeDefaultNone,
} SGTrackerEventListingFeeDefault;

typedef enum {
    SGTrackerEventListingInteractionMethod3DTouchPeek,
    SGTrackerEventListingInteractionMethodNone,
} SGTrackerEventListingInteractionMethod;

typedef enum {
    SGTrackerEventListingListingsDisplayOrientationHorizontal,
    SGTrackerEventListingListingsDisplayOrientationVertical,
    SGTrackerEventListingListingsDisplayOrientationNone,
} SGTrackerEventListingListingsDisplayOrientation;

typedef enum {
    SGTrackerEventListingPaymentTypeApplePay,
    SGTrackerEventListingPaymentTypeCreditCard,
    SGTrackerEventListingPaymentTypeNone,
} SGTrackerEventListingPaymentType;

typedef enum {
    SGTrackerEventListingSortTypeBestSeat,
    SGTrackerEventListingSortTypeDealScore,
    SGTrackerEventListingSortTypePrice,
    SGTrackerEventListingSortTypeNone,
} SGTrackerEventListingSortType;

typedef enum {
    SGTrackerEventListingViewModeAllNflVerified,
    SGTrackerEventListingViewModeSomeNflVerified,
    SGTrackerEventListingViewModeNoNflVerified,
    SGTrackerEventListingViewModeNone,
} SGTrackerEventListingViewMode;

typedef enum {
    SGTrackerEventListingUIOriginCheckout,
    SGTrackerEventListingUIOriginListingDetail,
    SGTrackerEventListingUIOriginGlobal,
    SGTrackerEventListingUIOriginNone,
} SGTrackerEventListingUIOrigin;

typedef enum {
    SGTrackerEventListingsDeliveryMethodAll,
    SGTrackerEventListingsDeliveryMethodEticket,
    SGTrackerEventListingsDeliveryMethodInAppEticket,
    SGTrackerEventListingsDeliveryMethodInstantEticket,
    SGTrackerEventListingsDeliveryMethodNone,
} SGTrackerEventListingsDeliveryMethod;

typedef enum {
    SGTrackerEventListingsFeeChoiceHideFees,
    SGTrackerEventListingsFeeChoiceShowFees,
    SGTrackerEventListingsFeeChoiceNone,
} SGTrackerEventListingsFeeChoice;

typedef enum {
    SGTrackerEventListingsFilterTypeAccessCodes,
    SGTrackerEventListingsFilterTypeAda,
    SGTrackerEventListingsFilterTypeDeliveryMethod,
    SGTrackerEventListingsFilterTypeObstructedView,
    SGTrackerEventListingsFilterTypePackage,
    SGTrackerEventListingsFilterTypePrice,
    SGTrackerEventListingsFilterTypePrimaryResale,
    SGTrackerEventListingsFilterTypePrime,
    SGTrackerEventListingsFilterTypePromocode,
    SGTrackerEventListingsFilterTypeQuantity,
    SGTrackerEventListingsFilterTypeSeatRow,
    SGTrackerEventListingsFilterTypeSeatQuality,
    SGTrackerEventListingsFilterTypeSeatSection,
    SGTrackerEventListingsFilterTypeSpatialCollection,
    SGTrackerEventListingsFilterTypeNone,
} SGTrackerEventListingsFilterType;

typedef enum {
    SGTrackerEventListingsObstructedViewChoiceAll,
    SGTrackerEventListingsObstructedViewChoiceUnobstructedView,
    SGTrackerEventListingsObstructedViewChoiceNone,
} SGTrackerEventListingsObstructedViewChoice;

typedef enum {
    SGTrackerEventListingsPriceFilterChoiceManual,
    SGTrackerEventListingsPriceFilterChoiceSlider,
    SGTrackerEventListingsPriceFilterChoiceNone,
} SGTrackerEventListingsPriceFilterChoice;

typedef enum {
    SGTrackerEventListingsPrimaryResaleChoicePrimaryOnly,
    SGTrackerEventListingsPrimaryResaleChoicePrimaryAndOfficialResale,
    SGTrackerEventListingsPrimaryResaleChoiceNone,
} SGTrackerEventListingsPrimaryResaleChoice;

typedef enum {
    SGTrackerEventListingsPrimeChoiceAll,
    SGTrackerEventListingsPrimeChoicePrime,
    SGTrackerEventListingsPrimeChoiceNone,
} SGTrackerEventListingsPrimeChoice;

typedef enum {
    SGTrackerEventListingsPromocodeChoiceSupportsPromoCodeOnly,
    SGTrackerEventListingsPromocodeChoiceAll,
    SGTrackerEventListingsPromocodeChoiceNone,
} SGTrackerEventListingsPromocodeChoice;

typedef enum {
    SGTrackerEventListingsUIOriginHorizontalList,
    SGTrackerEventListingsUIOriginVerticalList,
    SGTrackerEventListingsUIOriginCollectionsBar,
    SGTrackerEventListingsUIOriginFilterSortModal,
    SGTrackerEventListingsUIOriginSettings,
    SGTrackerEventListingsUIOriginBestAvailableForm,
    SGTrackerEventListingsUIOriginEventListingsHeader,
    SGTrackerEventListingsUIOriginNone,
} SGTrackerEventListingsUIOrigin;

typedef enum {
    SGTrackerEventListingsListingsDisplayOrientationHorizontal,
    SGTrackerEventListingsListingsDisplayOrientationVertical,
    SGTrackerEventListingsListingsDisplayOrientationNone,
} SGTrackerEventListingsListingsDisplayOrientation;

typedef enum {
    SGTrackerEventListingsShowMethodBottomsheetExpand,
    SGTrackerEventListingsShowMethodCollectionsBar,
    SGTrackerEventListingsShowMethodFilterModal,
    SGTrackerEventListingsShowMethodMapInteraction,
    SGTrackerEventListingsShowMethodMapModeButton,
    SGTrackerEventListingsShowMethodPageLoad,
    SGTrackerEventListingsShowMethodNone,
} SGTrackerEventListingsShowMethod;

typedef enum {
    SGTrackerEventListingsSortOrderAsc,
    SGTrackerEventListingsSortOrderDesc,
    SGTrackerEventListingsSortOrderNone,
} SGTrackerEventListingsSortOrder;

typedef enum {
    SGTrackerEventListingsSortTypeBestSeat,
    SGTrackerEventListingsSortTypeDQ,
    SGTrackerEventListingsSortTypePrice,
    SGTrackerEventListingsSortTypeNone,
} SGTrackerEventListingsSortType;

typedef enum {
    SGTrackerEventRowInteractionMethodLongPressDrag,
    SGTrackerEventRowInteractionMethodNone,
} SGTrackerEventRowInteractionMethod;

typedef enum {
    SGTrackerEventSectionInteractionMethodLongPressDrag,
    SGTrackerEventSectionInteractionMethodNone,
} SGTrackerEventSectionInteractionMethod;

typedef enum {
    SGTrackerEventShareUIOriginEvent,
    SGTrackerEventShareUIOriginEventInfo,
    SGTrackerEventShareUIOriginListingDetail,
    SGTrackerEventShareUIOriginGlobal,
    SGTrackerEventShareUIOriginNone,
} SGTrackerEventShareUIOrigin;

typedef enum {
    SGTrackerEventFeeChoiceHideFees,
    SGTrackerEventFeeChoiceShowFees,
    SGTrackerEventFeeChoiceNone,
} SGTrackerEventFeeChoice;

typedef enum {
    SGTrackerHelpContactUIOriginLogin2Fa,
    SGTrackerHelpContactUIOriginGlobal,
    SGTrackerHelpContactUIOriginNone,
} SGTrackerHelpContactUIOrigin;

typedef enum {
    SGTrackerIngestionsBarcodesTicketTypeBarcode,
    SGTrackerIngestionsBarcodesTicketTypePDF,
    SGTrackerIngestionsBarcodesTicketTypeNone,
} SGTrackerIngestionsBarcodesTicketType;

typedef enum {
    SGTrackerIngestionsEventsTicketTypeBarcode,
    SGTrackerIngestionsEventsTicketTypePDF,
    SGTrackerIngestionsEventsTicketTypeNone,
} SGTrackerIngestionsEventsTicketType;

typedef enum {
    SGTrackerIngestionsHelpDetailTicketTypePDF,
    SGTrackerIngestionsHelpDetailTicketTypeScreenshot,
    SGTrackerIngestionsHelpDetailTicketTypeNone,
} SGTrackerIngestionsHelpDetailTicketType;

typedef enum {
    SGTrackerIngestionsMetadataTicketTypeBarcode,
    SGTrackerIngestionsMetadataTicketTypePDF,
    SGTrackerIngestionsMetadataTicketTypeNone,
} SGTrackerIngestionsMetadataTicketType;

typedef enum {
    SGTrackerIngestionsPerformerTicketTypeBarcode,
    SGTrackerIngestionsPerformerTicketTypePDF,
    SGTrackerIngestionsPerformerTicketTypeNone,
} SGTrackerIngestionsPerformerTicketType;

typedef enum {
    SGTrackerIngestionsSummaryTicketTypeBarcode,
    SGTrackerIngestionsSummaryTicketTypePDF,
    SGTrackerIngestionsSummaryTicketTypeNone,
} SGTrackerIngestionsSummaryTicketType;

typedef enum {
    SGTrackerIngestionsUploadTicketTypeBarcode,
    SGTrackerIngestionsUploadTicketTypePDF,
    SGTrackerIngestionsUploadTicketTypeNone,
} SGTrackerIngestionsUploadTicketType;

typedef enum {
    SGTrackerListUIOriginBrowse,
    SGTrackerListUIOriginBrowseSearch,
    SGTrackerListUIOriginBrowseSearchDefaultSuggestion,
    SGTrackerListUIOriginHome,
    SGTrackerListUIOriginList,
    SGTrackerListUIOriginMyTickets,
    SGTrackerListUIOriginNotification,
    SGTrackerListUIOriginPerformer,
    SGTrackerListUIOriginTabSearch,
    SGTrackerListUIOriginGlobal,
    SGTrackerListUIOriginNone,
} SGTrackerListUIOrigin;

typedef enum {
    SGTrackerListItemInteractionMethodClick,
    SGTrackerListItemInteractionMethodDismiss,
    SGTrackerListItemInteractionMethodScroll,
    SGTrackerListItemInteractionMethodTrack,
    SGTrackerListItemInteractionMethodUntrack,
    SGTrackerListItemInteractionMethod3DTouchPeek,
    SGTrackerListItemInteractionMethod3DTouchPop,
    SGTrackerListItemInteractionMethodPlaySong,
    SGTrackerListItemInteractionMethodPauseSong,
    SGTrackerListItemInteractionMethodNone,
} SGTrackerListItemInteractionMethod;

typedef enum {
    SGTrackerListItemUIOriginBrowse,
    SGTrackerListItemUIOriginBrowseSearch,
    SGTrackerListItemUIOriginBrowseSearchDefaultSuggestion,
    SGTrackerListItemUIOriginHome,
    SGTrackerListItemUIOriginList,
    SGTrackerListItemUIOriginMyTickets,
    SGTrackerListItemUIOriginNotification,
    SGTrackerListItemUIOriginPerformer,
    SGTrackerListItemUIOriginTabSearch,
    SGTrackerListItemUIOriginGlobal,
    SGTrackerListItemUIOriginNone,
} SGTrackerListItemUIOrigin;

typedef enum {
    SGTrackerListViewUIOriginBrowse,
    SGTrackerListViewUIOriginBrowseSearch,
    SGTrackerListViewUIOriginBrowseSearchDefaultSuggestion,
    SGTrackerListViewUIOriginHome,
    SGTrackerListViewUIOriginList,
    SGTrackerListViewUIOriginMyTickets,
    SGTrackerListViewUIOriginNotification,
    SGTrackerListViewUIOriginPerformer,
    SGTrackerListViewUIOriginTabSearch,
    SGTrackerListViewUIOriginNone,
} SGTrackerListViewUIOrigin;

typedef enum {
    SGTrackerLotteryItemTypeEnter,
    SGTrackerLotteryItemTypeTrackPerformer,
    SGTrackerLotteryItemTypeEnableNotifications,
    SGTrackerLotteryItemTypeNone,
} SGTrackerLotteryItemType;

typedef enum {
    SGTrackerLotteryUIOriginBrowse,
    SGTrackerLotteryUIOriginDeeplink,
    SGTrackerLotteryUIOriginGlobal,
    SGTrackerLotteryUIOriginNone,
} SGTrackerLotteryUIOrigin;

typedef enum {
    SGTrackerMusicPlayerUIOriginBrowse,
    SGTrackerMusicPlayerUIOriginMyTicketsTicket,
    SGTrackerMusicPlayerUIOriginNone,
} SGTrackerMusicPlayerUIOrigin;

typedef enum {
    SGTrackerMusicPlayerInteractionMethodNext,
    SGTrackerMusicPlayerInteractionMethodPause,
    SGTrackerMusicPlayerInteractionMethodPlay,
    SGTrackerMusicPlayerInteractionMethodPrevious,
    SGTrackerMusicPlayerInteractionMethodOpenSpotify,
    SGTrackerMusicPlayerInteractionMethodNone,
} SGTrackerMusicPlayerInteractionMethod;

typedef enum {
    SGTrackerNavigationItemTypeBrowse,
    SGTrackerNavigationItemTypeSearch,
    SGTrackerNavigationItemTypeMyTickets,
    SGTrackerNavigationItemTypeAccountSettings,
    SGTrackerNavigationItemTypeTracking,
    SGTrackerNavigationItemTypeNone,
} SGTrackerNavigationItemType;

typedef enum {
    SGTrackerNotificationContentContentActionTicketGroupTransfer,
    SGTrackerNotificationContentContentActionTicketGroupView,
    SGTrackerNotificationContentContentActionNone,
} SGTrackerNotificationContentContentAction;

typedef enum {
    SGTrackerNotificationContentNotificationTypeTicketsAvailable,
    SGTrackerNotificationContentNotificationTypeNone,
} SGTrackerNotificationContentNotificationType;

typedef enum {
    SGTracker3DTouchUIOriginBrowse,
    SGTracker3DTouchUIOriginBrowseSearch,
    SGTracker3DTouchUIOriginCategory,
    SGTracker3DTouchUIOriginList,
    SGTracker3DTouchUIOriginTabSearch,
    SGTracker3DTouchUIOriginTracking,
    SGTracker3DTouchUIOriginGlobal,
    SGTracker3DTouchUIOriginNone,
} SGTracker3DTouchUIOrigin;

typedef enum {
    SGTrackerPerformerUIOriginBrowse,
    SGTrackerPerformerUIOriginBrowseSearch,
    SGTrackerPerformerUIOriginCategory,
    SGTrackerPerformerUIOriginCategorySidebar,
    SGTrackerPerformerUIOriginEventInfo,
    SGTrackerPerformerUIOriginEventSidebar,
    SGTrackerPerformerUIOriginEventTitle,
    SGTrackerPerformerUIOriginHomeSearch,
    SGTrackerPerformerUIOriginHomeSidebar,
    SGTrackerPerformerUIOriginList,
    SGTrackerPerformerUIOriginNavBarButton,
    SGTrackerPerformerUIOriginNavBarSearch,
    SGTrackerPerformerUIOriginPerformerSidebar,
    SGTrackerPerformerUIOriginTabSearch,
    SGTrackerPerformerUIOriginTracking,
    SGTrackerPerformerUIOriginTrackingDashboard,
    SGTrackerPerformerUIOriginVenueSidebar,
    SGTrackerPerformerUIOriginNotification,
    SGTrackerPerformerUIOriginNone,
} SGTrackerPerformerUIOrigin;

typedef enum {
    SGTrackerPerformerItemItemTypeBuyerGuaranteeCallout,
    SGTrackerPerformerItemItemTypeDealScorePromo,
    SGTrackerPerformerItemItemTypeExternalReview,
    SGTrackerPerformerItemItemTypeLoadMore,
    SGTrackerPerformerItemItemTypeMobileAppPromo,
    SGTrackerPerformerItemItemTypeNflAuthenticatedCallout,
    SGTrackerPerformerItemItemTypeOfficialTicketingPartner,
    SGTrackerPerformerItemItemTypeParkingCta,
    SGTrackerPerformerItemItemTypeSeoShowMore,
    SGTrackerPerformerItemItemTypeSeoLink,
    SGTrackerPerformerItemItemTypeShowDetails,
    SGTrackerPerformerItemItemTypeShowDescription,
    SGTrackerPerformerItemItemTypeTestimonials,
    SGTrackerPerformerItemItemTypeTbaNews,
    SGTrackerPerformerItemItemTypeNone,
} SGTrackerPerformerItemItemType;

typedef enum {
    SGTrackerPerformerMediaMediaSellerItunes,
    SGTrackerPerformerMediaMediaSellerNone,
} SGTrackerPerformerMediaMediaSeller;

typedef enum {
    SGTrackerPerformerMediaMediaTypeMusic,
    SGTrackerPerformerMediaMediaTypeNone,
} SGTrackerPerformerMediaMediaType;

typedef enum {
    SGTrackerPerformerMediaMediaPlayerItunes,
    SGTrackerPerformerMediaMediaPlayerNone,
} SGTrackerPerformerMediaMediaPlayer;

typedef enum {
    SGTrackerPerformerSubtabOffers,
    SGTrackerPerformerSubtabClubPasses,
    SGTrackerPerformerSubtabEvents,
    SGTrackerPerformerSubtabParking,
    SGTrackerPerformerSubtabPlayoffTickets,
    SGTrackerPerformerSubtabPreseasonTickets,
    SGTrackerPerformerSubtabSuites,
    SGTrackerPerformerSubtabTicketPackages,
    SGTrackerPerformerSubtabNone,
} SGTrackerPerformerSubtab;

typedef enum {
    SGTrackerPromotionDisplayTypeCustomImage,
    SGTrackerPromotionDisplayTypeDailyTap,
    SGTrackerPromotionDisplayTypeFeaturedEvent,
    SGTrackerPromotionDisplayTypeFeaturedPerformer,
    SGTrackerPromotionDisplayTypePriceDrop,
    SGTrackerPromotionDisplayTypeReferral,
    SGTrackerPromotionDisplayTypeStaticList,
    SGTrackerPromotionDisplayTypeEventDetail,
    SGTrackerPromotionDisplayTypeNone,
} SGTrackerPromotionDisplayType;

typedef enum {
    SGTrackerPromotionUIOriginBrowse,
    SGTrackerPromotionUIOriginEvent,
    SGTrackerPromotionUIOriginEventInfo,
    SGTrackerPromotionUIOriginHomepage,
    SGTrackerPromotionUIOriginMyTickets,
    SGTrackerPromotionUIOriginPostPurchase,
    SGTrackerPromotionUIOriginSettings,
    SGTrackerPromotionUIOriginGlobal,
    SGTrackerPromotionUIOriginNone,
} SGTrackerPromotionUIOrigin;

typedef enum {
    SGTrackerSearchUIOriginHome,
    SGTrackerSearchUIOriginBrowse,
    SGTrackerSearchUIOriginList,
    SGTrackerSearchUIOriginPerformer,
    SGTrackerSearchUIOriginEvent,
    SGTrackerSearchUIOriginVenue,
    SGTrackerSearchUIOriginMyTickets,
    SGTrackerSearchUIOriginTrackingDashboard,
    SGTrackerSearchUIOriginTracking,
    SGTrackerSearchUIOriginSettings,
    SGTrackerSearchUIOriginSearch,
    SGTrackerSearchUIOriginZendeskSupportSdk,
    SGTrackerSearchUIOriginGlobal,
    SGTrackerSearchUIOriginNone,
} SGTrackerSearchUIOrigin;

typedef enum {
    SGTrackerSellUIOriginHomeSidebar,
    SGTrackerSellUIOriginMyTickets,
    SGTrackerSellUIOriginMyTicketsTicket,
    SGTrackerSellUIOriginNavBarButton,
    SGTrackerSellUIOriginPerformerSidebar,
    SGTrackerSellUIOriginSellLanding,
    SGTrackerSellUIOriginGlobal,
    SGTrackerSellUIOriginNone,
} SGTrackerSellUIOrigin;

typedef enum {
    SGTrackerMyTicketsViewModeClassic,
    SGTrackerMyTicketsViewModeCompact,
    SGTrackerMyTicketsViewModeNone,
} SGTrackerMyTicketsViewMode;

typedef enum {
    SGTrackerOpenDomainSlugSportingkc,
    SGTrackerOpenDomainSlugNone,
} SGTrackerOpenDomainSlug;

typedef enum {
    SGTrackerSellCreateUIOriginResaleFlow,
    SGTrackerSellCreateUIOriginExchangeModal,
    SGTrackerSellCreateUIOriginNflListSeatgeekUpsell,
    SGTrackerSellCreateUIOriginGlobal,
    SGTrackerSellCreateUIOriginNone,
} SGTrackerSellCreateUIOrigin;

typedef enum {
    SGTrackerSellItemItemTypeExchangeModal,
    SGTrackerSellItemItemTypeDelistModal,
    SGTrackerSellItemItemTypeListButton,
    SGTrackerSellItemItemTypeCloseButton,
    SGTrackerSellItemItemTypeEditButton,
    SGTrackerSellItemItemTypeDelistButton,
    SGTrackerSellItemItemTypeListSeatgeekButton,
    SGTrackerSellItemItemTypeMorePartnersButton,
    SGTrackerSellItemItemTypeToken,
    SGTrackerSellItemItemTypeNflListSeatgeekButtonUpsell,
    SGTrackerSellItemItemTypeNone,
} SGTrackerSellItemItemType;

typedef enum {
    SGTrackerSellEditTypeAdd,
    SGTrackerSellEditTypeUpdate,
    SGTrackerSellEditTypeNone,
} SGTrackerSellEditType;

typedef enum {
    SGTrackerTransfersAcceptPaymentTypeApplePay,
    SGTrackerTransfersAcceptPaymentTypeCreditCard,
    SGTrackerTransfersAcceptPaymentTypeNone,
} SGTrackerTransfersAcceptPaymentType;

typedef enum {
    SGTrackerTransfersUIOriginEventTickets,
    SGTrackerTransfersUIOriginCheckout,
    SGTrackerTransfersUIOriginNotification,
    SGTrackerTransfersUIOriginiMessage,
    SGTrackerTransfersUIOriginStandalone,
    SGTrackerTransfersUIOriginGlobal,
    SGTrackerTransfersUIOriginNone,
} SGTrackerTransfersUIOrigin;

typedef enum {
    SGTrackerTransfersRecipientTypeEmail,
    SGTrackerTransfersRecipientTypeLink,
    SGTrackerTransfersRecipientTypeLocalContact,
    SGTrackerTransfersRecipientTypePhoneNumber,
    SGTrackerTransfersRecipientTypeSeatgeek,
    SGTrackerTransfersRecipientTypeNone,
} SGTrackerTransfersRecipientType;

typedef enum {
    SGTrackerTransfersStatusAvailable,
    SGTrackerTransfersStatusPending,
    SGTrackerTransfersStatusAccepted,
    SGTrackerTransfersStatusUnavailable,
    SGTrackerTransfersStatusNone,
} SGTrackerTransfersStatus;

typedef enum {
    SGTrackerTransfersIncomingTransferTypeFree,
    SGTrackerTransfersIncomingTransferTypePaid,
    SGTrackerTransfersIncomingTransferTypeUnverified,
    SGTrackerTransfersIncomingTransferTypeNone,
} SGTrackerTransfersIncomingTransferType;

typedef enum {
    SGTrackerTransfersIncomingUIOriginMyTickets,
    SGTrackerTransfersIncomingUIOriginStandalone,
    SGTrackerTransfersIncomingUIOriginGlobal,
    SGTrackerTransfersIncomingUIOriginNone,
} SGTrackerTransfersIncomingUIOrigin;

typedef enum {
    SGTrackerTransfersInitiationActivityTypeSkip,
    SGTrackerTransfersInitiationActivityTypeDone,
    SGTrackerTransfersInitiationActivityTypeNone,
} SGTrackerTransfersInitiationActivityType;

typedef enum {
    SGTrackerTransfersItemActivityTypeMore,
    SGTrackerTransfersItemActivityTypeQuestion,
    SGTrackerTransfersItemActivityTypeSend,
    SGTrackerTransfersItemActivityTypeNone,
} SGTrackerTransfersItemActivityType;

typedef enum {
    SGTrackerTransfersItemPageTypeEventTickets,
    SGTrackerTransfersItemPageTypeTransferInitiation,
    SGTrackerTransfersItemPageTypeNone,
} SGTrackerTransfersItemPageType;

typedef enum {
    SGTrackerTransfersTicketTypePass,
    SGTrackerTransfersTicketTypeTicket,
    SGTrackerTransfersTicketTypeNone,
} SGTrackerTransfersTicketType;

typedef enum {
    SGTrackerTransfersSummaryItemTypePrice,
    SGTrackerTransfersSummaryItemTypeQuantity,
    SGTrackerTransfersSummaryItemTypeRecipient,
    SGTrackerTransfersSummaryItemTypeNone,
} SGTrackerTransfersSummaryItemType;

typedef enum {
    SGTrackerUserAccountUpgradeItemTypeComplete,
    SGTrackerUserAccountUpgradeItemTypeEditEmail,
    SGTrackerUserAccountUpgradeItemTypeNeedHelp,
    SGTrackerUserAccountUpgradeItemTypeNone,
} SGTrackerUserAccountUpgradeItemType;

typedef enum {
    SGTrackerUserAccountTypeEmail,
    SGTrackerUserAccountTypeFacebook,
    SGTrackerUserAccountTypeLegacyUnknown,
    SGTrackerUserAccountTypeNone,
} SGTrackerUserAccountType;

typedef enum {
    SGTrackerUserAuthCredentialSourceGoogleSmartLock,
    SGTrackerUserAuthCredentialSourceManualInput,
    SGTrackerUserAuthCredentialSourceMagicLink,
    SGTrackerUserAuthCredentialSourceFacebookAccountUpgrade,
    SGTrackerUserAuthCredentialSourceNone,
} SGTrackerUserAuthCredentialSource;

typedef enum {
    SGTrackerUserAuthUIOriginBrowse,
    SGTrackerUserAuthUIOriginCategory,
    SGTrackerUserAuthUIOriginCheckout,
    SGTrackerUserAuthUIOriginCheckoutPromocode,
    SGTrackerUserAuthUIOriginDrawer,
    SGTrackerUserAuthUIOriginEvent,
    SGTrackerUserAuthUIOriginHome,
    SGTrackerUserAuthUIOriginHomeSidebar,
    SGTrackerUserAuthUIOriginList,
    SGTrackerUserAuthUIOriginMyTickets,
    SGTrackerUserAuthUIOriginNavBarButton,
    SGTrackerUserAuthUIOriginOnboarding,
    SGTrackerUserAuthUIOriginPerformer,
    SGTrackerUserAuthUIOriginSettings,
    SGTrackerUserAuthUIOriginSettingsPromocode,
    SGTrackerUserAuthUIOriginTracking,
    SGTrackerUserAuthUIOriginVenue,
    SGTrackerUserAuthUIOriginGlobal,
    SGTrackerUserAuthUIOriginNone,
} SGTrackerUserAuthUIOrigin;

typedef enum {
    SGTrackerUserContactVerificationContactTypeEmail,
    SGTrackerUserContactVerificationContactTypeMobilePhone,
    SGTrackerUserContactVerificationContactTypeNone,
} SGTrackerUserContactVerificationContactType;

typedef enum {
    SGTrackerUserContactContactTypeMobilePhone,
    SGTrackerUserContactContactTypeEmail,
    SGTrackerUserContactContactTypeNone,
} SGTrackerUserContactContactType;

typedef enum {
    SGTrackerUserContactUIOriginSettings,
    SGTrackerUserContactUIOriginTransfer,
    SGTrackerUserContactUIOriginPublicSale,
    SGTrackerUserContactUIOriginPaidTransfer,
    SGTrackerUserContactUIOriginGlobal,
    SGTrackerUserContactUIOriginNone,
} SGTrackerUserContactUIOrigin;

typedef enum {
    SGTrackerUserEventInteractionMethod3DTouchPeek,
    SGTrackerUserEventInteractionMethodNone,
} SGTrackerUserEventInteractionMethod;

typedef enum {
    SGTrackerUserEventUIOriginBrowse,
    SGTrackerUserEventUIOriginCategory,
    SGTrackerUserEventUIOriginEvent,
    SGTrackerUserEventUIOriginEventInfo,
    SGTrackerUserEventUIOriginHome,
    SGTrackerUserEventUIOriginHomeSidebar,
    SGTrackerUserEventUIOriginList,
    SGTrackerUserEventUIOriginMyTicketsTicket,
    SGTrackerUserEventUIOriginNotification,
    SGTrackerUserEventUIOriginPerformer,
    SGTrackerUserEventUIOriginTracking,
    SGTrackerUserEventUIOriginVenue,
    SGTrackerUserEventUIOriginGlobal,
    SGTrackerUserEventUIOriginNone,
} SGTrackerUserEventUIOrigin;

typedef enum {
    SGTrackerUserFeedbackFeedbackChoicesCallDismiss,
    SGTrackerUserFeedbackFeedbackChoicesEmailDismiss,
    SGTrackerUserFeedbackFeedbackChoicesEmailCallDismiss,
    SGTrackerUserFeedbackFeedbackChoicesEmailRateDismiss,
    SGTrackerUserFeedbackFeedbackChoicesRateDismiss,
    SGTrackerUserFeedbackFeedbackChoicesPositiveNegative,
    SGTrackerUserFeedbackFeedbackChoicesPositiveNegativeDismiss,
    SGTrackerUserFeedbackFeedbackChoicesPositiveNeutralNegativeDismiss,
    SGTrackerUserFeedbackFeedbackChoicesNone,
} SGTrackerUserFeedbackFeedbackChoices;

typedef enum {
    SGTrackerUserFeedbackUIOriginCheckout,
    SGTrackerUserFeedbackUIOriginDebug,
    SGTrackerUserFeedbackUIOriginNag,
    SGTrackerUserFeedbackUIOriginPublicSale,
    SGTrackerUserFeedbackUIOriginSettings,
    SGTrackerUserFeedbackUIOriginTransfer,
    SGTrackerUserFeedbackUIOriginMyTicketsTicket,
    SGTrackerUserFeedbackUIOriginGlobal,
    SGTrackerUserFeedbackUIOriginNone,
} SGTrackerUserFeedbackUIOrigin;

typedef enum {
    SGTrackerUserFeedbackFeedbackChoicePositive,
    SGTrackerUserFeedbackFeedbackChoiceNeutral,
    SGTrackerUserFeedbackFeedbackChoiceNegative,
    SGTrackerUserFeedbackFeedbackChoiceRate,
    SGTrackerUserFeedbackFeedbackChoiceEmail,
    SGTrackerUserFeedbackFeedbackChoiceCall,
    SGTrackerUserFeedbackFeedbackChoiceNone,
} SGTrackerUserFeedbackFeedbackChoice;

typedef enum {
    SGTrackerUserHelpUIOriginAccountSettings,
    SGTrackerUserHelpUIOriginCheckout,
    SGTrackerUserHelpUIOriginSellTickets,
    SGTrackerUserHelpUIOriginEventTickets,
    SGTrackerUserHelpUIOriginMyTickets,
    SGTrackerUserHelpUIOriginNone,
} SGTrackerUserHelpUIOrigin;

typedef enum {
    SGTrackerUserHelpContactTypeChat,
    SGTrackerUserHelpContactTypeCall,
    SGTrackerUserHelpContactTypeEmail,
    SGTrackerUserHelpContactTypeNone,
} SGTrackerUserHelpContactType;

typedef enum {
    SGTrackerUserIDInfoDataFieldEmail,
    SGTrackerUserIDInfoDataFieldPassword,
    SGTrackerUserIDInfoDataFieldFirstName,
    SGTrackerUserIDInfoDataFieldLastName,
    SGTrackerUserIDInfoDataFieldUsername,
    SGTrackerUserIDInfoDataFieldMobilePhone,
    SGTrackerUserIDInfoDataFieldPhoto,
    SGTrackerUserIDInfoDataFieldNone,
} SGTrackerUserIDInfoDataField;

typedef enum {
    SGTrackerUserIDInfoEditTypeAdd,
    SGTrackerUserIDInfoEditTypeUpdate,
    SGTrackerUserIDInfoEditTypeNone,
} SGTrackerUserIDInfoEditType;

typedef enum {
    SGTrackerUserIDInfoUIOriginSettings,
    SGTrackerUserIDInfoUIOriginTransfer,
    SGTrackerUserIDInfoUIOriginPaidTransfer,
    SGTrackerUserIDInfoUIOriginPublicSale,
    SGTrackerUserIDInfoUIOriginOnboarding,
    SGTrackerUserIDInfoUIOriginGlobal,
    SGTrackerUserIDInfoUIOriginNone,
} SGTrackerUserIDInfoUIOrigin;

typedef enum {
    SGTrackerUserLoginCredentialSourceGoogleSmartLock,
    SGTrackerUserLoginCredentialSourceManualInput,
    SGTrackerUserLoginCredentialSourceMagicLink,
    SGTrackerUserLoginCredentialSourceFacebookAccountUpgrade,
    SGTrackerUserLoginCredentialSourceNone,
} SGTrackerUserLoginCredentialSource;

typedef enum {
    SGTrackerUserTwoFAModeApp,
    SGTrackerUserTwoFAModeSms,
    SGTrackerUserTwoFAModeNone,
} SGTrackerUserTwoFAMode;

typedef enum {
    SGTrackerUserLoginUIOriginBrowse,
    SGTrackerUserLoginUIOriginCategory,
    SGTrackerUserLoginUIOriginCheckout,
    SGTrackerUserLoginUIOriginCheckoutPromocode,
    SGTrackerUserLoginUIOriginDrawer,
    SGTrackerUserLoginUIOriginEvent,
    SGTrackerUserLoginUIOriginForgotPassword,
    SGTrackerUserLoginUIOriginHome,
    SGTrackerUserLoginUIOriginHomeSidebar,
    SGTrackerUserLoginUIOriginList,
    SGTrackerUserLoginUIOriginMyTickets,
    SGTrackerUserLoginUIOriginNavBarButton,
    SGTrackerUserLoginUIOriginNavBarTrackTickets,
    SGTrackerUserLoginUIOriginOnboarding,
    SGTrackerUserLoginUIOriginPerformer,
    SGTrackerUserLoginUIOriginSettings,
    SGTrackerUserLoginUIOriginSettingsPromocode,
    SGTrackerUserLoginUIOriginTracking,
    SGTrackerUserLoginUIOriginTransfer,
    SGTrackerUserLoginUIOriginVenue,
    SGTrackerUserLoginUIOriginGlobal,
    SGTrackerUserLoginUIOriginNone,
} SGTrackerUserLoginUIOrigin;

typedef enum {
    SGTrackerUserLoginItemTypeForgotPassword,
    SGTrackerUserLoginItemTypeLogin,
    SGTrackerUserLoginItemTypeUseMagicLink,
    SGTrackerUserLoginItemTypeUsedToSignInWithFacebook,
    SGTrackerUserLoginItemTypeNone,
} SGTrackerUserLoginItemType;

typedef enum {
    SGTrackerUserLoginSplashLoginChoiceLoginFacebook,
    SGTrackerUserLoginSplashLoginChoiceLoginEmail,
    SGTrackerUserLoginSplashLoginChoiceRegisterEmail,
    SGTrackerUserLoginSplashLoginChoiceNone,
} SGTrackerUserLoginSplashLoginChoice;

typedef enum {
    SGTrackerUserLoginSplashUIOriginBrowse,
    SGTrackerUserLoginSplashUIOriginCategory,
    SGTrackerUserLoginSplashUIOriginCheckout,
    SGTrackerUserLoginSplashUIOriginCheckoutPromocode,
    SGTrackerUserLoginSplashUIOriginDrawer,
    SGTrackerUserLoginSplashUIOriginEvent,
    SGTrackerUserLoginSplashUIOriginHome,
    SGTrackerUserLoginSplashUIOriginHomeSidebar,
    SGTrackerUserLoginSplashUIOriginiMessage,
    SGTrackerUserLoginSplashUIOriginList,
    SGTrackerUserLoginSplashUIOriginMyTickets,
    SGTrackerUserLoginSplashUIOriginNavBarButton,
    SGTrackerUserLoginSplashUIOriginOnboarding,
    SGTrackerUserLoginSplashUIOriginPerformer,
    SGTrackerUserLoginSplashUIOriginSettings,
    SGTrackerUserLoginSplashUIOriginSettingsPromocode,
    SGTrackerUserLoginSplashUIOriginTracking,
    SGTrackerUserLoginSplashUIOriginVenue,
    SGTrackerUserLoginSplashUIOriginGlobal,
    SGTrackerUserLoginSplashUIOriginNone,
} SGTrackerUserLoginSplashUIOrigin;

typedef enum {
    SGTrackerUserLogoutUIOriginNavBarButton,
    SGTrackerUserLogoutUIOriginSettings,
    SGTrackerUserLogoutUIOriginGlobal,
    SGTrackerUserLogoutUIOriginNone,
} SGTrackerUserLogoutUIOrigin;

typedef enum {
    SGTrackerUserNoticeActivityTypeDismiss,
    SGTrackerUserNoticeActivityTypeLink,
    SGTrackerUserNoticeActivityTypeNone,
} SGTrackerUserNoticeActivityType;

typedef enum {
    SGTrackerUserNoticeUIOriginMyTickets,
    SGTrackerUserNoticeUIOriginNone,
} SGTrackerUserNoticeUIOrigin;

typedef enum {
    SGTrackerUserNotificationNagSettingsTypeAlertModal,
    SGTrackerUserNotificationNagSettingsTypeSettingsApp,
    SGTrackerUserNotificationNagSettingsTypeNone,
} SGTrackerUserNotificationNagSettingsType;

typedef enum {
    SGTrackerUserNotificationNagUIOriginOnboarding,
    SGTrackerUserNotificationNagUIOriginSettings,
    SGTrackerUserNotificationNagUIOriginPostPurchase,
    SGTrackerUserNotificationNagUIOriginAppForeground,
    SGTrackerUserNotificationNagUIOriginContextualPushPrompt,
    SGTrackerUserNotificationNagUIOriginPerformer,
    SGTrackerUserNotificationNagUIOriginTracking,
    SGTrackerUserNotificationNagUIOriginBrowse,
    SGTrackerUserNotificationNagUIOriginSearch,
    SGTrackerUserNotificationNagUIOriginGlobal,
    SGTrackerUserNotificationNagUIOriginNone,
} SGTrackerUserNotificationNagUIOrigin;

typedef enum {
    SGTrackerUserNotificationNagDismissalLengthForever,
    SGTrackerUserNotificationNagDismissalLengthForNow,
    SGTrackerUserNotificationNagDismissalLengthNone,
} SGTrackerUserNotificationNagDismissalLength;

typedef enum {
    SGTrackerUserNotificationNagModalTypeNativeiOS,
    SGTrackerUserNotificationNagModalTypeCustom,
    SGTrackerUserNotificationNagModalTypeContextualPushPrompt,
    SGTrackerUserNotificationNagModalTypeNone,
} SGTrackerUserNotificationNagModalType;

typedef enum {
    SGTrackerUserOnboardingOnboardingTypeConnectServices,
    SGTrackerUserOnboardingOnboardingTypeConnectServicesDetail,
    SGTrackerUserOnboardingOnboardingTypeDealScore,
    SGTrackerUserOnboardingOnboardingTypeInAppDelivery,
    SGTrackerUserOnboardingOnboardingTypeLocation,
    SGTrackerUserOnboardingOnboardingTypeMap,
    SGTrackerUserOnboardingOnboardingTypeMobileEntry,
    SGTrackerUserOnboardingOnboardingTypePush,
    SGTrackerUserOnboardingOnboardingTypeSell,
    SGTrackerUserOnboardingOnboardingTypeTransfer,
    SGTrackerUserOnboardingOnboardingTypeIntro,
    SGTrackerUserOnboardingOnboardingTypeSearch,
    SGTrackerUserOnboardingOnboardingTypeReferral,
    SGTrackerUserOnboardingOnboardingTypeTracking,
    SGTrackerUserOnboardingOnboardingTypeNone,
} SGTrackerUserOnboardingOnboardingType;

typedef enum {
    SGTrackerUserOnboardingUIOriginBrowse,
    SGTrackerUserOnboardingUIOriginEvent,
    SGTrackerUserOnboardingUIOriginHome,
    SGTrackerUserOnboardingUIOriginInitialOnboarding,
    SGTrackerUserOnboardingUIOriginTickets,
    SGTrackerUserOnboardingUIOriginGlobal,
    SGTrackerUserOnboardingUIOriginNone,
} SGTrackerUserOnboardingUIOrigin;

typedef enum {
    SGTrackerUserPaymentDataFieldCardCvv,
    SGTrackerUserPaymentDataFieldCardExpMonth,
    SGTrackerUserPaymentDataFieldCardExpYear,
    SGTrackerUserPaymentDataFieldCardExpCombined,
    SGTrackerUserPaymentDataFieldCardNumber,
    SGTrackerUserPaymentDataFieldBillFirst,
    SGTrackerUserPaymentDataFieldBillLast,
    SGTrackerUserPaymentDataFieldBillStreet1,
    SGTrackerUserPaymentDataFieldBillStreet2,
    SGTrackerUserPaymentDataFieldBillCity,
    SGTrackerUserPaymentDataFieldBillState,
    SGTrackerUserPaymentDataFieldBillCountry,
    SGTrackerUserPaymentDataFieldBillZip,
    SGTrackerUserPaymentDataFieldNone,
} SGTrackerUserPaymentDataField;

typedef enum {
    SGTrackerUserPaymentEditTypeAdd,
    SGTrackerUserPaymentEditTypeUpdate,
    SGTrackerUserPaymentEditTypeEntry,
    SGTrackerUserPaymentEditTypeNone,
} SGTrackerUserPaymentEditType;

typedef enum {
    SGTrackerUserPaymentUIOriginCheckout,
    SGTrackerUserPaymentUIOriginSettings,
    SGTrackerUserPaymentUIOriginPaidTransfer,
    SGTrackerUserPaymentUIOriginPublicSale,
    SGTrackerUserPaymentUIOriginVenuenext,
    SGTrackerUserPaymentUIOriginGlobal,
    SGTrackerUserPaymentUIOriginNone,
} SGTrackerUserPaymentUIOrigin;

typedef enum {
    SGTrackerUserPayoutEditTypeAdd,
    SGTrackerUserPayoutEditTypeUpdate,
    SGTrackerUserPayoutEditTypeNone,
} SGTrackerUserPayoutEditType;

typedef enum {
    SGTrackerUserPayoutUIOriginSettings,
    SGTrackerUserPayoutUIOriginPublicSale,
    SGTrackerUserPayoutUIOriginTransfer,
    SGTrackerUserPayoutUIOriginPaidTransfer,
    SGTrackerUserPayoutUIOriginGlobal,
    SGTrackerUserPayoutUIOriginNone,
} SGTrackerUserPayoutUIOrigin;

typedef enum {
    SGTrackerUserPayoutMethodBank,
    SGTrackerUserPayoutMethodSroCredit,
    SGTrackerUserPayoutMethodVenmo,
    SGTrackerUserPayoutMethodVenmoEmail,
    SGTrackerUserPayoutMethodVenmoPhone,
    SGTrackerUserPayoutMethodNone,
} SGTrackerUserPayoutMethod;

typedef enum {
    SGTrackerUserPerformerInteractionMethod3DTouchPeek,
    SGTrackerUserPerformerInteractionMethodNone,
} SGTrackerUserPerformerInteractionMethod;

typedef enum {
    SGTrackerUserPerformerUIOriginBrowse,
    SGTrackerUserPerformerUIOriginCategory,
    SGTrackerUserPerformerUIOriginHomeSidebar,
    SGTrackerUserPerformerUIOriginList,
    SGTrackerUserPerformerUIOriginMyTicketsTicket,
    SGTrackerUserPerformerUIOriginPerformer,
    SGTrackerUserPerformerUIOriginTracking,
    SGTrackerUserPerformerUIOriginGlobal,
    SGTrackerUserPerformerUIOriginNone,
} SGTrackerUserPerformerUIOrigin;

typedef enum {
    SGTrackerUserPreferencesPreferenceChoiceEnable,
    SGTrackerUserPreferencesPreferenceChoiceDisable,
    SGTrackerUserPreferencesPreferenceChoiceNone,
} SGTrackerUserPreferencesPreferenceChoice;

typedef enum {
    SGTrackerUserPreferencesPreferenceTypeAll,
    SGTrackerUserPreferencesPreferenceTypeEventReminder,
    SGTrackerUserPreferencesPreferenceTypeNewEvent,
    SGTrackerUserPreferencesPreferenceTypeNone,
} SGTrackerUserPreferencesPreferenceType;

typedef enum {
    SGTrackerUserPromocodePromocodeTypeDiscount,
    SGTrackerUserPromocodePromocodeTypeNone,
} SGTrackerUserPromocodePromocodeType;

typedef enum {
    SGTrackerUserPromocodeUIOriginCheckout,
    SGTrackerUserPromocodeUIOriginRegister,
    SGTrackerUserPromocodeUIOriginSettings,
    SGTrackerUserPromocodeUIOriginGlobal,
    SGTrackerUserPromocodeUIOriginNone,
} SGTrackerUserPromocodeUIOrigin;

typedef enum {
    SGTrackerUserPromptPromptTypeAppStoreRating,
    SGTrackerUserPromptPromptTypeBuzzfeed,
    SGTrackerUserPromptPromptTypeConnectServices,
    SGTrackerUserPromptPromptTypeContactPermission,
    SGTrackerUserPromptPromptTypeFacebookAccountUpgrade,
    SGTrackerUserPromptPromptTypeLocationPermission,
    SGTrackerUserPromptPromptTypeLocationPushPermission,
    SGTrackerUserPromptPromptTypePushPermission,
    SGTrackerUserPromptPromptTypeSpotify,
    SGTrackerUserPromptPromptTypeCreateAccount,
    SGTrackerUserPromptPromptTypeDownloadApp,
    SGTrackerUserPromptPromptTypePriceDrop,
    SGTrackerUserPromptPromptTypeAda,
    SGTrackerUserPromptPromptTypeMusicPlayerSpotify,
    SGTrackerUserPromptPromptTypeReturnPolicy,
    SGTrackerUserPromptPromptTypeNone,
} SGTrackerUserPromptPromptType;

typedef enum {
    SGTrackerUserPromptUIOriginAppForeground,
    SGTrackerUserPromptUIOriginBrowse,
    SGTrackerUserPromptUIOriginHomepage,
    SGTrackerUserPromptUIOriginInitialOnboarding,
    SGTrackerUserPromptUIOriginLogin,
    SGTrackerUserPromptUIOriginMyTickets,
    SGTrackerUserPromptUIOriginNavBarDropdown,
    SGTrackerUserPromptUIOriginPostPurchase,
    SGTrackerUserPromptUIOriginSettings,
    SGTrackerUserPromptUIOriginLocationSearch,
    SGTrackerUserPromptUIOriginReferralInvites,
    SGTrackerUserPromptUIOriginEvent,
    SGTrackerUserPromptUIOriginModal,
    SGTrackerUserPromptUIOriginCheckout,
    SGTrackerUserPromptUIOriginVerticalList,
    SGTrackerUserPromptUIOriginHorizontalList,
    SGTrackerUserPromptUIOriginGlobal,
    SGTrackerUserPromptUIOriginNone,
} SGTrackerUserPromptUIOrigin;

typedef enum {
    SGTrackerUserRecoupmentUIOriginPublicSale,
    SGTrackerUserRecoupmentUIOriginGlobal,
    SGTrackerUserRecoupmentUIOriginNone,
} SGTrackerUserRecoupmentUIOrigin;

typedef enum {
    SGTrackerUserReferralsDisplayTypeModal,
    SGTrackerUserReferralsDisplayTypePage,
    SGTrackerUserReferralsDisplayTypeNone,
} SGTrackerUserReferralsDisplayType;

typedef enum {
    SGTrackerUserReferralsDisplayValueCopy,
    SGTrackerUserReferralsDisplayValueEmail,
    SGTrackerUserReferralsDisplayValueFacebook,
    SGTrackerUserReferralsDisplayValueMore,
    SGTrackerUserReferralsDisplayValueSms,
    SGTrackerUserReferralsDisplayValueTwitter,
    SGTrackerUserReferralsDisplayValueNone,
} SGTrackerUserReferralsDisplayValue;

typedef enum {
    SGTrackerUserRegisterUIOriginBrowse,
    SGTrackerUserRegisterUIOriginCategory,
    SGTrackerUserRegisterUIOriginCheckout,
    SGTrackerUserRegisterUIOriginCheckoutPromocode,
    SGTrackerUserRegisterUIOriginDrawer,
    SGTrackerUserRegisterUIOriginEmailModal,
    SGTrackerUserRegisterUIOriginEvent,
    SGTrackerUserRegisterUIOriginForgotPassword,
    SGTrackerUserRegisterUIOriginHome,
    SGTrackerUserRegisterUIOriginHomeSidebar,
    SGTrackerUserRegisterUIOriginList,
    SGTrackerUserRegisterUIOriginMyTickets,
    SGTrackerUserRegisterUIOriginNavBarButton,
    SGTrackerUserRegisterUIOriginOnboarding,
    SGTrackerUserRegisterUIOriginPerformer,
    SGTrackerUserRegisterUIOriginSettings,
    SGTrackerUserRegisterUIOriginSettingsPromocode,
    SGTrackerUserRegisterUIOriginTracking,
    SGTrackerUserRegisterUIOriginTransfer,
    SGTrackerUserRegisterUIOriginVenue,
    SGTrackerUserRegisterUIOriginGlobal,
    SGTrackerUserRegisterUIOriginNone,
} SGTrackerUserRegisterUIOrigin;

typedef enum {
    SGTrackerUserUIOriginAccountSettings,
    SGTrackerUserUIOriginBrowse,
    SGTrackerUserUIOriginBrowseSearch,
    SGTrackerUserUIOriginCheckout,
    SGTrackerUserUIOriginEvent,
    SGTrackerUserUIOriginEventFilters,
    SGTrackerUserUIOriginEventInfo,
    SGTrackerUserUIOriginEventTickets,
    SGTrackerUserUIOriginInitialOnboarding,
    SGTrackerUserUIOriginListingDetail,
    SGTrackerUserUIOriginLogin,
    SGTrackerUserUIOriginLottery,
    SGTrackerUserUIOriginModal,
    SGTrackerUserUIOriginMyTickets,
    SGTrackerUserUIOriginMyTicketsTicket,
    SGTrackerUserUIOriginOnboarding,
    SGTrackerUserUIOriginPaidTransfer,
    SGTrackerUserUIOriginPerformer,
    SGTrackerUserUIOriginPostPurchase,
    SGTrackerUserUIOriginReferralInvites,
    SGTrackerUserUIOriginRegister,
    SGTrackerUserUIOriginResaleFlow,
    SGTrackerUserUIOriginSearch,
    SGTrackerUserUIOriginSellLanding,
    SGTrackerUserUIOriginSellTickets,
    SGTrackerUserUIOriginSettings,
    SGTrackerUserUIOriginSettingsPromocode,
    SGTrackerUserUIOriginTabSearch,
    SGTrackerUserUIOriginTickets,
    SGTrackerUserUIOriginTracking,
    SGTrackerUserUIOriginTrackingDashboard,
    SGTrackerUserUIOriginTransfer,
    SGTrackerUserUIOriginVenue,
    SGTrackerUserUIOriginGlobal,
    SGTrackerUserUIOriginNone,
} SGTrackerUserUIOrigin;

typedef enum {
    SGTrackerUserServiceServiceTypeFacebook,
    SGTrackerUserServiceServiceTypeLastFm,
    SGTrackerUserServiceServiceTypeMusicLibrary,
    SGTrackerUserServiceServiceTypeSpotify,
    SGTrackerUserServiceServiceTypeNone,
} SGTrackerUserServiceServiceType;

typedef enum {
    SGTrackerUserSettingsDisplayValueAbout,
    SGTrackerUserSettingsDisplayValueAccountSettings,
    SGTrackerUserSettingsDisplayValueAccountManager,
    SGTrackerUserSettingsDisplayValueConnectedServices,
    SGTrackerUserSettingsDisplayValueCreditCard,
    SGTrackerUserSettingsDisplayValueDeliveryAddress,
    SGTrackerUserSettingsDisplayValueFeedback,
    SGTrackerUserSettingsDisplayValueFaq,
    SGTrackerUserSettingsDisplayValueLocationServices,
    SGTrackerUserSettingsDisplayValueNotifications,
    SGTrackerUserSettingsDisplayValuePayoutMethod,
    SGTrackerUserSettingsDisplayValuePricesWithFees,
    SGTrackerUserSettingsDisplayValuePromoCodes,
    SGTrackerUserSettingsDisplayValueReferral,
    SGTrackerUserSettingsDisplayValueSetLocation,
    SGTrackerUserSettingsDisplayValueSortBy,
    SGTrackerUserSettingsDisplayValueSupport,
    SGTrackerUserSettingsDisplayValueTerms,
    SGTrackerUserSettingsDisplayValueNone,
} SGTrackerUserSettingsDisplayValue;

typedef enum {
    SGTrackerUserShareItemTypeEvent,
    SGTrackerUserShareItemTypeListing,
    SGTrackerUserShareItemTypePerformer,
    SGTrackerUserShareItemTypeVenue,
    SGTrackerUserShareItemTypeNone,
} SGTrackerUserShareItemType;

typedef enum {
    SGTrackerUserShareSourceShareButton,
    SGTrackerUserShareSourceScreenshot,
    SGTrackerUserShareSourceNone,
} SGTrackerUserShareSource;

typedef enum {
    SGTrackerUserShareUIOriginEvent,
    SGTrackerUserShareUIOriginEventInfo,
    SGTrackerUserShareUIOriginListingDetail,
    SGTrackerUserShareUIOriginPerformer,
    SGTrackerUserShareUIOriginVenue,
    SGTrackerUserShareUIOriginNone,
} SGTrackerUserShareUIOrigin;

typedef enum {
    SGTrackerUserShippingDataFieldShipFirst,
    SGTrackerUserShippingDataFieldShipLast,
    SGTrackerUserShippingDataFieldShipStreet1,
    SGTrackerUserShippingDataFieldShipStreet2,
    SGTrackerUserShippingDataFieldShipCity,
    SGTrackerUserShippingDataFieldShipState,
    SGTrackerUserShippingDataFieldShipCountry,
    SGTrackerUserShippingDataFieldShipZip,
    SGTrackerUserShippingDataFieldNone,
} SGTrackerUserShippingDataField;

typedef enum {
    SGTrackerUserShippingEditTypeAdd,
    SGTrackerUserShippingEditTypeUpdate,
    SGTrackerUserShippingEditTypeEntry,
    SGTrackerUserShippingEditTypeNone,
} SGTrackerUserShippingEditType;

typedef enum {
    SGTrackerUserShippingUIOriginCheckout,
    SGTrackerUserShippingUIOriginSettings,
    SGTrackerUserShippingUIOriginGlobal,
    SGTrackerUserShippingUIOriginNone,
} SGTrackerUserShippingUIOrigin;

typedef enum {
    SGTrackerUserSurveyItemTypeBack,
    SGTrackerUserSurveyItemTypeComment,
    SGTrackerUserSurveyItemTypeDismiss,
    SGTrackerUserSurveyItemTypeRating,
    SGTrackerUserSurveyItemTypeResearch,
    SGTrackerUserSurveyItemTypeSubmit,
    SGTrackerUserSurveyItemTypeTag,
    SGTrackerUserSurveyItemTypeNone,
} SGTrackerUserSurveyItemType;

typedef enum {
    SGTrackerUserSurveyPageTypeInitialRating,
    SGTrackerUserSurveyPageTypeDidAttend,
    SGTrackerUserSurveyPageTypeDidNotAttend,
    SGTrackerUserSurveyPageTypeNone,
} SGTrackerUserSurveyPageType;

typedef enum {
    SGTrackerUserTicketsActivityTypeAccept,
    SGTrackerUserTicketsActivityTypeAppInstallWidget,
    SGTrackerUserTicketsActivityTypeAppleWallet,
    SGTrackerUserTicketsActivityTypeCalendar,
    SGTrackerUserTicketsActivityTypeCall,
    SGTrackerUserTicketsActivityTypeCancel,
    SGTrackerUserTicketsActivityTypeChat,
    SGTrackerUserTicketsActivityTypeCopy,
    SGTrackerUserTicketsActivityTypeDecline,
    SGTrackerUserTicketsActivityTypeDelist,
    SGTrackerUserTicketsActivityTypeDirections,
    SGTrackerUserTicketsActivityTypeDismiss,
    SGTrackerUserTicketsActivityTypeEdit,
    SGTrackerUserTicketsActivityTypeEmail,
    SGTrackerUserTicketsActivityTypeEnableNotifications,
    SGTrackerUserTicketsActivityTypeFaq,
    SGTrackerUserTicketsActivityTypeGooglePayPass,
    SGTrackerUserTicketsActivityTypeLink,
    SGTrackerUserTicketsActivityTypeList,
    SGTrackerUserTicketsActivityTypeLyft,
    SGTrackerUserTicketsActivityTypeNext,
    SGTrackerUserTicketsActivityTypeOpenSpotify,
    SGTrackerUserTicketsActivityTypeOptions,
    SGTrackerUserTicketsActivityTypePause,
    SGTrackerUserTicketsActivityTypePlay,
    SGTrackerUserTicketsActivityTypePrevious,
    SGTrackerUserTicketsActivityTypeReturnTickets,
    SGTrackerUserTicketsActivityTypeRoute,
    SGTrackerUserTicketsActivityTypeSell,
    SGTrackerUserTicketsActivityTypeSend,
    SGTrackerUserTicketsActivityTypeShare,
    SGTrackerUserTicketsActivityTypeSnapchat,
    SGTrackerUserTicketsActivityTypeSupport,
    SGTrackerUserTicketsActivityTypeTrack,
    SGTrackerUserTicketsActivityTypeUntrack,
    SGTrackerUserTicketsActivityTypeVenueCommerceConcessions,
    SGTrackerUserTicketsActivityTypeVenueCommerceExperience,
    SGTrackerUserTicketsActivityTypeVenueCommerceFood,
    SGTrackerUserTicketsActivityTypeVenueCommerceMerchandise,
    SGTrackerUserTicketsActivityTypeVerifyEmail,
    SGTrackerUserTicketsActivityTypeVerifyPhone,
    SGTrackerUserTicketsActivityTypeViewMore,
    SGTrackerUserTicketsActivityTypeViewPDF,
    SGTrackerUserTicketsActivityTypeWebview,
    SGTrackerUserTicketsActivityTypeNone,
} SGTrackerUserTicketsActivityType;

typedef enum {
    SGTrackerUserTicketsItemTypeEvent,
    SGTrackerUserTicketsItemTypeIncomingTransfer,
    SGTrackerUserTicketsItemTypeIngestion,
    SGTrackerUserTicketsItemTypeListing,
    SGTrackerUserTicketsItemTypeLocationPermission,
    SGTrackerUserTicketsItemTypeLocationPushPermission,
    SGTrackerUserTicketsItemTypeNote,
    SGTrackerUserTicketsItemTypePushPermission,
    SGTrackerUserTicketsItemTypeOrderStatus,
    SGTrackerUserTicketsItemTypeOutgoingTransfer,
    SGTrackerUserTicketsItemTypeTicketGroup,
    SGTrackerUserTicketsItemTypeTransferManager,
    SGTrackerUserTicketsItemTypeWidget,
    SGTrackerUserTicketsItemTypeCard,
    SGTrackerUserTicketsItemTypeNone,
} SGTrackerUserTicketsItemType;

typedef enum {
    SGTrackerUserTicketsStyleTypeCardWithAdditionalNotes,
    SGTrackerUserTicketsStyleTypeNone,
} SGTrackerUserTicketsStyleType;

typedef enum {
    SGTrackerUserTicketsDisplayTypeBarcode,
    SGTrackerUserTicketsDisplayTypePDF,
    SGTrackerUserTicketsDisplayTypeScreenshot,
    SGTrackerUserTicketsDisplayTypePlaceholder,
    SGTrackerUserTicketsDisplayTypeDoeTakeover,
    SGTrackerUserTicketsDisplayTypePending,
    SGTrackerUserTicketsDisplayTypeNone,
} SGTrackerUserTicketsDisplayType;

typedef enum {
    SGTrackerUserTicketsBarcodeTypeQrcode,
    SGTrackerUserTicketsBarcodeTypePdf417,
    SGTrackerUserTicketsBarcodeTypeSecureEntry,
    SGTrackerUserTicketsBarcodeTypeNone,
} SGTrackerUserTicketsBarcodeType;

typedef enum {
    SGTrackerUserTicketsViewTypeEventTickets,
    SGTrackerUserTicketsViewTypeFullScreenTickets,
    SGTrackerUserTicketsViewTypeNone,
} SGTrackerUserTicketsViewType;

typedef enum {
    SGTrackerUserTwoFAUIOriginLogin,
    SGTrackerUserTwoFAUIOriginSettingsDisable,
    SGTrackerUserTwoFAUIOriginSettingsEnable,
    SGTrackerUserTwoFAUIOriginGlobal,
    SGTrackerUserTwoFAUIOriginNone,
} SGTrackerUserTwoFAUIOrigin;

typedef enum {
    SGTrackerUserUnverifiedContactAlertContactTypeEmail,
    SGTrackerUserUnverifiedContactAlertContactTypeMobilePhone,
    SGTrackerUserUnverifiedContactAlertContactTypeNone,
} SGTrackerUserUnverifiedContactAlertContactType;

typedef enum {
    SGTrackerUserVenueCommerceProductTypeExperience,
    SGTrackerUserVenueCommerceProductTypeFood,
    SGTrackerUserVenueCommerceProductTypeMerchandise,
    SGTrackerUserVenueCommerceProductTypeNone,
} SGTrackerUserVenueCommerceProductType;

typedef enum {
    SGTrackerUserVenueCommerceItemTypeConcessions,
    SGTrackerUserVenueCommerceItemTypeFood,
    SGTrackerUserVenueCommerceItemTypeWallet,
    SGTrackerUserVenueCommerceItemTypeNone,
} SGTrackerUserVenueCommerceItemType;

typedef enum {
    SGTrackerVenueCommerceUIOriginBrowse,
    SGTrackerVenueCommerceUIOriginEventTickets,
    SGTrackerVenueCommerceUIOriginMyTickets,
    SGTrackerVenueCommerceUIOriginNotification,
    SGTrackerVenueCommerceUIOriginNone,
} SGTrackerVenueCommerceUIOrigin;

typedef enum {
    SGTrackerUserVenueInteractionMethod3DTouchPeek,
    SGTrackerUserVenueInteractionMethodNone,
} SGTrackerUserVenueInteractionMethod;

typedef enum {
    SGTrackerUserVenueUIOriginList,
    SGTrackerUserVenueUIOriginMyTicketsTicket,
    SGTrackerUserVenueUIOriginTracking,
    SGTrackerUserVenueUIOriginVenue,
    SGTrackerUserVenueUIOriginGlobal,
    SGTrackerUserVenueUIOriginNone,
} SGTrackerUserVenueUIOrigin;

typedef enum {
    SGTrackerVenueUIOriginBrowseSearch,
    SGTrackerVenueUIOriginCategorySidebar,
    SGTrackerVenueUIOriginEventInfo,
    SGTrackerVenueUIOriginEventSidebar,
    SGTrackerVenueUIOriginHomeSearch,
    SGTrackerVenueUIOriginNavBarSearch,
    SGTrackerVenueUIOriginPerformer,
    SGTrackerVenueUIOriginTabSearch,
    SGTrackerVenueUIOriginTracking,
    SGTrackerVenueUIOriginTrackingDashboard,
    SGTrackerVenueUIOriginList,
    SGTrackerVenueUIOriginNone,
} SGTrackerVenueUIOrigin;

typedef enum {
    SGTrackerVenueDirectionsDirectionMethodDrive,
    SGTrackerVenueDirectionsDirectionMethodTransit,
    SGTrackerVenueDirectionsDirectionMethodWalk,
    SGTrackerVenueDirectionsDirectionMethodNone,
} SGTrackerVenueDirectionsDirectionMethod;

typedef enum {
    SGTrackerVenueDirectionsUIOriginEvent,
    SGTrackerVenueDirectionsUIOriginEventInfo,
    SGTrackerVenueDirectionsUIOriginTracking,
    SGTrackerVenueDirectionsUIOriginGlobal,
    SGTrackerVenueDirectionsUIOriginNone,
} SGTrackerVenueDirectionsUIOrigin;
