//
//  Created by matt on 20/07/15.
//

#import "SGPItem.h"

#define SGKTransferStatusPending  @"pending"
#define SGKTransferStatusAccepted @"accepted"
#define SGKTransferStatusCanceled @"canceled"
#define SGKTransferStatusDeclined @"declined"

@interface SGTransferStatus : SGItem

@property (nonatomic, strong) NSDate *utcDate;
@property (nonatomic, copy) NSString *type;

@end
