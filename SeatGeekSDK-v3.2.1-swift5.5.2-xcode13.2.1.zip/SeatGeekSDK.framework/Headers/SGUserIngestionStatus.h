//
//  SGUserIngestionStatus.h
//  Pods
//
//  Created by Steven Lehrburger on 11/20/15.
//
//

#import "SGPItem.h"

#define SGKUserIngestionStatusProcessing @"processing"
#define SGKUserIngestionStatusFailed     @"failed"
#define SGKUserIngestionStatusPurgatory  @"purgatory"
#define SGKUserIngestionStatusCondemned  @"condemned"
#define SGKUserIngestionStatusSuccess    @"success"


@interface SGUserIngestionStatus : SGItem

@property (nonatomic, copy) NSString *type;

- (NSString *)displayStatus;

@end
