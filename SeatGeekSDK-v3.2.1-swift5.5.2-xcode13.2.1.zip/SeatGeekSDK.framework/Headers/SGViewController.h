//
//  SGViewController.h
//  SeatGeek
//
//  Created by David McNerney on 4/29/16.
//  Copyright © 2016 SeatGeek. All rights reserved.
//

@import UIKit;
#import "SGSafeAreaInsetChangeBlockerProtocol.h"
#import "MGBlockWrapper.h"

@class SGTransitionHandler;

@interface SGViewController : UIViewController <SGSafeAreaInsetChangeBlocker>

@property (strong, nonatomic) SGTransitionHandler *transitionHandler;

@property (nonatomic) BOOL ignoreSafeAreaInsetChanges;

/// block to be called once on appear
@property (nonatomic, copy) MGBlock onAppear;

- (void)safeAreaInsetsChanged;  // called on safe area inset changes, backward compatible to pre ios 11

@end
