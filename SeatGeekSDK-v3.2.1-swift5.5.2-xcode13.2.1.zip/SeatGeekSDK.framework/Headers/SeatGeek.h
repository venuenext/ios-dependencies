//
//  SeatGeek.h
//  SeatGeekSDK
//
//  Created by Ed Paulosky on 10/10/17.
//  Copyright © 2017 SeatGeek. All rights reserved.
//

@import UIKit;

// A protocol defining the user properties that are available
@protocol SGKUserInfo

/// The user's SeatGeek ID
@property (nonatomic, copy, readonly, nullable) NSString *ID;

/// The account ID in the CRM management tool that the team is using
@property (nonatomic, copy, readonly, nullable) NSString *crmId;

/// The user's email address
@property (nonatomic, copy, readonly, nullable) NSString *email;

/// The user's mobile phone number
@property (nonatomic, copy, readonly, nullable) NSString *mobilePhone;

/// The user's first name
@property (nonatomic, copy, readonly, nullable) NSString *firstName;

/// The user's last name
@property (nonatomic, copy, readonly, nullable) NSString *lastName;

@end

@class SGKSDKTicketGroup;

@interface SeatGeek : NSObject


#pragma mark - Configuration

/**
 * Configures the SeatGeek client.
 * Call this at the start of your AppDelegate's didFinishLaunching...
 */
+ (void)configure;

+ (void)configureWithClientId:(nonnull NSString *)clientId
                 instanceName:(nonnull NSString *)instanceName
                  redirectURI:(nonnull NSString *)redirectURI;

#pragma mark - URL Handling

/**
 * Returns if the SeatGeek client can do something given the url.
 *
 * @param url SeatGeek will check this url to see if it can perform some action in response to it.
 *
 * @return Returns YES if SeatGeek can handle the given url
 */
+ (BOOL)canHandleURL:(nonnull NSURL *)url;

/**
 * Returns if the SeatGeek client did perform some action given the url.
 *
 * @param url The url to trigger some action by the SeatGeek client.
 *
 * @note Currently the only action SeatGeek will perform is processing the redirect callback from the authentication flow
 *
 * @return Returns YES if SeatGeek did handle the given url
 */
+ (BOOL)handleURL:(nonnull NSURL *)url;


#pragma mark - Authentication

/// The access token used to authenticate with SeatGeek
@property (class, nonatomic, readonly, nullable) NSString *accessToken;

/// Intiates an oAuth login flow from the provided view controller
+ (void)logInFromViewController:(nonnull UIViewController *)fromViewController;

/// A block that will be called every time the user logs in successfully
/// This will also get called when an existing user session is sucessfully resumed.
@property (class, nonatomic, copy, nullable) void (^onLoginSuccessful)(void);

/// A block that will be called every time the user log in attempt fails.
/// errorMessage is a user friendly error message
@property (class, nonatomic, copy, nullable) void (^onLoginFailed)(NSString * _Nullable errorMessage);

/**
 * Resumes an existing user's session.
 * This only needs to be called once per app launch and must be called before fetchAllTickets
 *
 * @note We will handle this automatically unless you opt out of this behavior by setting
 * SuppressAppBecameActiveRequests to YES under SeatGeek in your info.plist
 *
 */
+ (void)resumeSession;


/**
 * Resumes an existing user's session.
 * This allows a client to authenticate a user when the client already has the user's access token.
 *
 * @note If access token is nil this will trigger onLoginFailed
 * @note Upon success this will trigger onLoginSuccessful
 *
 */
+ (void)resumeSessionWithAccessToken:(nonnull NSString *)accessToken;

/**
 * Logs out the current user.
 */
+ (void)logOut;


#pragma mark - User

// The current logged in user. This will be nil if no user is logged in.
// This user object will be missing data upon app launch after termination, until resumeSession finishes.
@property (class, nonatomic, strong, readonly, nullable) id <SGKUserInfo> currentUserInfo;


#pragma mark - Customization

/// The primary color used throughout the SeatGeek UI.
/// Default value is SeatGeek's blue.
@property (class, nonatomic, strong, nullable) UIColor *primaryColor;


@end
