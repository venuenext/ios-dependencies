//
//  UIColor+InterpolateTo.h
//  Pods
//
//  Created by Brian Maci on 10/29/20.
//

@interface UIColor (InterpolateTo)

/// Returns a color interpolated towards end color with amount t [0,1]
- (nonnull UIColor *)interpolateTo:(nonnull UIColor *)endColor t:(float)t;

@end
