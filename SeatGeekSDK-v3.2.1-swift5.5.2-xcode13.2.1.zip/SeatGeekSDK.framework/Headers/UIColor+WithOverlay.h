//
//  UIColor+WithOverlay.h
//  Pods
//
//  Created by Brian Maci on 10/29/20.
//

@interface UIColor (WithOverlay)

/// Returns a solid color from overlaying another color on top with an alpha using standard source over blending
- (nonnull UIColor *)withOverlay:(nonnull UIColor *)overlayColor alpha:(CGFloat)a;

@end
