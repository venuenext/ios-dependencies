//
//  UIScrollView+SeatGeek.h
//  SeatGeek
//
//  Created by James Van-As on 1/08/13.
//  Copyright (c) 2013 SeatGeek. All rights reserved.
//

@import UIKit;

@interface UIScrollView (SeatGeek)

- (void)sgk_scrollToTopAnimated:(BOOL)animated;
- (void)sgk_scrollToBottomAnimated:(BOOL)animated;
- (CGFloat)sgk_heightWithoutInsets;
@property (readonly) BOOL sgk_isScrolledToTop;
@property (readonly) BOOL sgk_isScrolledToBottom;
- (CGFloat)sgk_distanceFromBottom;
/// the y component of contentOffset if the scrollview was to be scrolled to the bottom
@property (readonly) CGFloat sgk_bottomScrollYOffset;

/// True if scrolling is required to view all content.
@property (readonly) BOOL sgk_canScroll;

@end
