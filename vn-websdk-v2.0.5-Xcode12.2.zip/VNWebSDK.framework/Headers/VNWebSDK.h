//  Copyright © 2020 VenueNext. All rights reserved.

#import <Foundation/Foundation.h>

//! Project version number for VNWebSDK.
FOUNDATION_EXPORT double VNWebSDKVersionNumber;

//! Project version string for VNWebSDK.
FOUNDATION_EXPORT const unsigned char VNWebSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VNWebSDK/PublicHeader.h>

