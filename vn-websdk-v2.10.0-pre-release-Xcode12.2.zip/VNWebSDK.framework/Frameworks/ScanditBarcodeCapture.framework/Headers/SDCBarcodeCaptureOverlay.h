/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2018- Scandit AG. All rights reserved.
 */
#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureOverlay.h>

@class SDCBarcodeCapture;
@class SDCBrush;
@class SDCDataCaptureView;
@protocol SDCViewfinder;

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(BarcodeCaptureOverlay)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeCaptureOverlay : NSObject <SDCDataCaptureOverlay>

@property (class, nonatomic, nonnull, readonly) SDCBrush *defaultBrush;
@property (nonatomic, strong, nonnull) SDCBrush *brush;
@property (nonatomic, assign) BOOL shouldShowScanAreaGuides;
@property (nonatomic, strong, nullable) id<SDCViewfinder> viewfinder;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)overlayWithBarcodeCapture:(nonnull SDCBarcodeCapture *)barcodeCapture;
+ (instancetype)overlayWithBarcodeCapture:(nonnull SDCBarcodeCapture *)barcodeCapture
                       forDataCaptureView:(nullable SDCDataCaptureView *)view
    NS_SWIFT_NAME(init(barcodeCapture:view:));

+ (nullable instancetype)barcodeCaptureOverlayFromJSONString:(nonnull NSString *)JSONString
                                                        mode:(nonnull SDCBarcodeCapture *)mode
                                                       error:(NSError *_Nullable *_Nullable)error
    NS_SWIFT_NAME(init(jsonString:barcodeCapture:));

- (BOOL)updateFromJSONString:(nonnull NSString *)JSONString
                       error:(NSError *_Nullable *_Nullable)error;

- (void)setValue:(nullable id)value forProperty:(nonnull NSString *)property;

@end

NS_ASSUME_NONNULL_END
