/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2020- Scandit AG. All rights reserved.
 */

#import <UIKit/UIKit.h>
#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureOverlay.h>

@class SDCBarcodeSelection;
@class SDCBrush;
@class SDCBarcode;
@class SDCDataCaptureView;
@protocol SDCViewfinder;

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(BarcodeSelectionBasicOverlay)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeSelectionBasicOverlay : UIView <SDCDataCaptureOverlay>

@property (class, nonatomic, nonnull, readonly) SDCBrush *defaultTrackedBrush;
@property (class, nonatomic, nonnull, readonly) SDCBrush *defaultAimedBrush;
@property (class, nonatomic, nonnull, readonly) SDCBrush *defaultSelectingBrush;
@property (class, nonatomic, nonnull, readonly) SDCBrush *defaultSelectedBrush;

@property (nonatomic, strong, nonnull) SDCBrush *trackedBrush;
@property (nonatomic, strong, nonnull) SDCBrush *aimedBrush;
@property (nonatomic, strong, nonnull) SDCBrush *selectingBrush;
@property (nonatomic, strong, nonnull) SDCBrush *selectedBrush;

@property (nonatomic, assign) BOOL shouldShowHints;
@property (nonatomic, assign) BOOL shouldShowScanAreaGuides;
@property (nonatomic, strong, nonnull, readonly) id<SDCViewfinder> viewfinder;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)decoder NS_UNAVAILABLE;

+ (instancetype)overlayWithBarcodeSelection:(nonnull SDCBarcodeSelection *)barcodeSelection
    NS_SWIFT_NAME(init(barcodeSelection:));
+ (instancetype)overlayWithBarcodeSelection:(nonnull SDCBarcodeSelection *)barcodeSelection
                         forDataCaptureView:(nullable SDCDataCaptureView *)view
    NS_SWIFT_NAME(init(barcodeSelection:view:));

- (void)clearSelectedBarcodeBrushes;

@end

NS_ASSUME_NONNULL_END
