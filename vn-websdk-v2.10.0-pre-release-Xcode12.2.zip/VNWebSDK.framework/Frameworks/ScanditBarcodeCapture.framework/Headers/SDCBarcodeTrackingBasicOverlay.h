/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2018- Scandit AG. All rights reserved.
 */
#import <Foundation/Foundation.h>

#import <ScanditCaptureCore/SDCBase.h>
#import <ScanditCaptureCore/SDCDataCaptureOverlay.h>

@class SDCBarcodeTracking;
@class SDCBrush;
@class SDCTrackedBarcode;
@class SDCBarcodeTrackingBasicOverlay;
@class SDCDataCaptureView;

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(BarcodeTrackingBasicOverlayDelegate)
@protocol SDCBarcodeTrackingBasicOverlayDelegate <NSObject>

- (nullable SDCBrush *)barcodeTrackingBasicOverlay:(nonnull SDCBarcodeTrackingBasicOverlay *)overlay
                            brushForTrackedBarcode:(nonnull SDCTrackedBarcode *)trackedBarcode;

- (void)barcodeTrackingBasicOverlay:(nonnull SDCBarcodeTrackingBasicOverlay *)overlay
               didTapTrackedBarcode:(nonnull SDCTrackedBarcode *)trackedBarcode;

@end

NS_SWIFT_NAME(BarcodeTrackingBasicOverlay)
SDC_EXPORTED_SYMBOL
@interface SDCBarcodeTrackingBasicOverlay : NSObject <SDCDataCaptureOverlay>

@property (nonatomic, weak, nullable) id<SDCBarcodeTrackingBasicOverlayDelegate> delegate;
@property (class, nonatomic, nonnull, readonly) SDCBrush *defaultBrush;
@property (nonatomic, strong, nullable)
    SDCBrush *defaultBrush DEPRECATED_MSG_ATTRIBUTE("Use brush instead");
@property (nonatomic, strong, nullable) SDCBrush *brush;

@property (nonatomic, assign) BOOL shouldShowScanAreaGuides;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)overlayWithBarcodeTracking:(nonnull SDCBarcodeTracking *)barcodeTracking;
+ (instancetype)overlayWithBarcodeTracking:(nonnull SDCBarcodeTracking *)barcodeTracking
                        forDataCaptureView:(nullable SDCDataCaptureView *)view
    NS_SWIFT_NAME(init(barcodeTracking:view:));
;

+ (nullable instancetype)barcodeTrackingBasicOverlayFromJSONString:(nonnull NSString *)JSONString
                                                              mode:
                                                                  (nonnull SDCBarcodeTracking *)mode
                                                             error:(NSError **)error
    NS_SWIFT_NAME(init(jsonString:barcodeTracking:));

- (BOOL)updateFromJSONString:(nonnull NSString *)JSONString error:(NSError **)error;

- (void)setBrush:(nullable SDCBrush *)brush
    forTrackedBarcode:(nonnull SDCTrackedBarcode *)trackedBarcode;

- (void)clearTrackedBarcodeBrushes;

@end

NS_ASSUME_NONNULL_END
