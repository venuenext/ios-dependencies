/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2019- Scandit AG. All rights reserved.
 */
#import <Foundation/Foundation.h>

NS_SWIFT_NAME(Control)
@protocol SDCControl <NSObject>

@end
