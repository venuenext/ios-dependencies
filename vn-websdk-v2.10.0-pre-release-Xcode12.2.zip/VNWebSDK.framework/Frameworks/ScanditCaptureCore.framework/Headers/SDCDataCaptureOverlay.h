/*
 * This file is part of the Scandit Data Capture SDK
 *
 * Copyright (C) 2018- Scandit AG. All rights reserved.
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

NS_SWIFT_NAME(DataCaptureOverlay)
@protocol SDCDataCaptureOverlay <NSObject>

@end

NS_ASSUME_NONNULL_END
